//
//  HomePageVC.swift
//  UniOrient
//
//  Created by APPLE on 28/03/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit
import BetterSegmentedControl

class HomePageVC: UIViewController {
    
    //----------Flight-----------
    @IBOutlet weak var control1: BetterSegmentedControl!//
    @IBOutlet weak var segmentView: UIView!//
    @IBOutlet weak var multicityTableView: UITableView! //
    
    //    @IBOutlet weak var topView: UIView!
    @IBOutlet var multiCityBottomView: UIView!//
    @IBOutlet weak var bookingLbl: UILabel!
    @IBOutlet weak var bookingImg: UIImageView!
    @IBOutlet weak var myAccountLbl: UILabel!
    @IBOutlet weak var userImg: UIImageView!
    @IBOutlet weak var homeLbl: UILabel!
    @IBOutlet weak var homeImg: UIImageView!
    @IBOutlet weak var multiSTopImg: UIImageView!
    @IBOutlet weak var nonSTopImg: UIImageView!// //
    @IBOutlet weak var roundTripDateView: UIView!//
    @IBOutlet weak var onewayRoundTripView: UIView!//
    @IBOutlet weak var onewayBtn: UIButton! //
    @IBOutlet weak var multiCityBtn: UIButton!//
    @IBOutlet weak var roundTripbtn: UIButton!//
    
    @IBOutlet weak var stopBtn: UIButton!
    
    @IBOutlet weak var lblArrivalCity: UILabel!//
    @IBOutlet weak var lblDepartureCIty: UILabel!//
    @IBOutlet weak var txtDepartureCode: UITextField!//
    
    @IBOutlet weak var lblMultiTraveller: UILabel!//
    @IBOutlet weak var lblMultiClass: UILabel!//
    @IBOutlet weak var multiStopBtn: UIButton!
    @IBOutlet weak var txtArrivalCode: UITextField!//
    @IBOutlet weak var txtDepartureCity: UITextField!
    @IBOutlet weak var txtArrivalCity: UITextField!
    @IBOutlet weak var lblDepartureDate: UILabel!//
    @IBOutlet weak var lblArrivalDate: UILabel!//
 
    var module_SK : String = String()
    var arrMultiDCountry : [String] = [String]()
    var arrMultiACountry : [String] = [String]()
    var departureCountry : String = String()
    var arrivalCountry : String = String()
    var isOneTwoWayDateClicked : Bool!
    var isOneTwoWayCityDepartClicked : Bool!
    
    var strTem1, strTemp2 : String!
    let flightDateFormatter = DateFormatter()
    let flightFDateFormatter = DateFormatter()
    var departdate, arrivDate, departDate1, departDate2, departDate3 : String!
    var departday, arrivday : String!
    var isMultiSelected : String!
    var strAdult = "", strChild = "", strInfant : String = ""
    var index : Int = 0
    var multiChoose : String = String()
    var wayType : String = String()
    var dteBtnCliked : String = String()
    var DictInputs = Dictionary<String, String>()
    var arrMultiTitle : [String] = [String]()
    var arrMultiDepartCode : [String] = [String]()
    var arrMultiDepartCity : [String] = [String]()
    var arrMultiArriCode : [String] = [String]()
    var arrMultiArriCity : [String] = [String]()
    var arrMultiDate : [String] = [String]()
    var arrMultiDay : [String] = [String]()
    var arrMultiDate1 : [String] = [String]()
    var arrMultiDay1 : [String] = [String]()
    var selectedDepartDate1, selectedArrivalDate1, sDepartDate1, sDepartDate2, sDepartDate3 : String!
    
    @IBOutlet weak var onewayArrivalDateView: UIView!//
    @IBOutlet weak var onewayArrivDateLbl: UILabel!
    @IBOutlet weak var lblClass: UILabel!//
    @IBOutlet weak var lblTraveller: UILabel!//
    
    // ------------------Hotel---------------
    @IBOutlet weak var hotelView: UIView!
    var dateData = DateSelectedStruct()
    var flightDateData = FlightDateSelectedStruct()
    @IBOutlet weak var flightBtn: UIButton!
    @IBOutlet weak var hotelBtn: UIButton!
    
    @IBOutlet weak var cityTextField: UITextField!
    @IBOutlet weak var cityImgView: UIImageView!
    @IBOutlet weak var cityPlaceHolderLbl: UILabel!
    @IBOutlet weak var cityView: UIView!
    
    
    @IBOutlet weak var nationalityView: UIView!
    @IBOutlet weak var nationalityTextField: UITextField!
    @IBOutlet weak var nationalityImgView: UIImageView!
    @IBOutlet weak var nationalityPlaceHolderLbl: UILabel!
    
    //    var selectedOriginStructHotel : HotelCityStructNew!
    var selectedOriginStructHotel = HotelCityStructNew()
    var selectedNationalityStructHotel = HotelNationalityStruct()
    
    @IBOutlet weak var dateView: UIView!
    @IBOutlet weak var checkinDateView: UIView!
    @IBOutlet weak var checkinDateLbl: UILabel!
    @IBOutlet weak var checkoutDateView: UIView!
    @IBOutlet weak var checkoutDateLbl: UILabel!
    @IBOutlet weak var nightView: UIView!
    @IBOutlet weak var noOfNightsLbl: UILabel!
    
    @IBOutlet weak var GuestAndRoomView: UIView!
    @IBOutlet weak var guestLbl: UILabel!
    @IBOutlet weak var roomLbl: UILabel!
    
    var totalNoOfAdult : Int = 2
    var totalNoOfChildren : Int = 0
    //    var selectedArr1 = [RoomStruct1]()
    
    var selectedArr = [RoomStruct]()
    
    
    @IBOutlet weak var hotelSearchBtn: UIButton!
    
    var dateDisplayFormat = DateFormatter()
    var oneDay : Double!
    var nextDay : Date!
 
    var secondDay : Double!
    var thirdDay : Date!
    
    var inputParameterDateFormatterHotel = DateFormatter()
    var selectedCheckinStrToPass : String!
    var selectedCheckoutStrToPass : String!
    var defaults = UserDefaults.standard
    var noOfNight : Int!
    
    var selectedCheckinDate,selectedCheckoutDate : Date!
    
    @IBOutlet weak var flightView: UIView!
    @IBOutlet weak var flightSearchBtn: UIButton!//
    
    let flightWhiteImg = UIImage.init(named: "flightWhite")
    let hotelWhiteImg = UIImage.init(named: "hotelWhite")
    let flightGrayImg = UIImage.init(named: "flightGray")
    let hotelGrayImg  = UIImage.init(named: "hotelGray")
    
    let selectedImg = UIImage.init(named: "optionSelectedViolet")
    let unSelectedImg = UIImage.init(named: "optionUnselectedViolet")
    
    @IBOutlet weak var domesticBtn: UIButton!
    @IBOutlet weak var internationalBtn: UIButton!
    
    @IBAction func domesticBtnTapped(_ sender: UIButton) {
        if !(sender.isSelected){
            sender.isSelected = true
            internationalBtn.isSelected = false
            
            domesticBtn.setImage(self.selectedImg, for: .normal)
            internationalBtn.setImage(self.unSelectedImg, for: .normal)
            
            self.cityTextField.text = ""
//            self.cityTextField.placeholder = "Select"
            self.cityImgView.isHidden = false
            self.cityPlaceHolderLbl.text = "Select a City"
            
            self.selectedOriginStructHotel.CityName = ""
            self.selectedOriginStructHotel.CountryCode = ""
            self.selectedOriginStructHotel.CitySk = ""
            self.selectedOriginStructHotel.ctype = ""
            self.selectedOriginStructHotel.Country = ""
        }
    }
    
    @IBAction func internationalBtnTapped(_ sender: UIButton) {
        if !(sender.isSelected){
            sender.isSelected = true
            domesticBtn.isSelected = false
            
            domesticBtn.setImage(self.unSelectedImg, for: .normal)
            internationalBtn.setImage(self.selectedImg, for: .normal)
            
            self.cityTextField.text = ""
//            self.cityTextField.placeholder = "Select"
            self.cityImgView.isHidden = false
            self.cityPlaceHolderLbl.text = "Select a City"
            
            self.selectedOriginStructHotel.CityName = ""
            self.selectedOriginStructHotel.CountryCode = ""
            self.selectedOriginStructHotel.CitySk = ""
            self.selectedOriginStructHotel.ctype = ""
            self.selectedOriginStructHotel.Country = ""
            
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //-----------Flight -----------------
        
        flightDateFormatter.dateFormat = "E, d MMM, yyyy"
        flightFDateFormatter.dateFormat = "yyyy-MM-dd"
        
        isMultiSelected = "yes" // for Date SHow only
        defaults.set("two", forKey: "wayType")
        wayType="two"
        arrMultiDepartCode = ["Airport","Airport","Airport"]
        arrMultiDepartCity = ["City","City","City"]
        arrMultiArriCode = ["Airport","Airport","Airport"]//["Airport","Airport","Airport"]
        arrMultiArriCity = ["City","City","City"]
        arrMultiDate = ["Date","Date","Date"]
        arrMultiDate1 = ["Date","Date","Date"]
        arrMultiDay = ["Day","Day","Day"]
        multicityTableView .reloadData()
        self.hotelView.isHidden = true
        self.flightView.isHidden = false
        
        self.flightBtn.isSelected = true
        self.hotelBtn.isSelected = false
        self.multicityTableView.tableFooterView = self.multiCityBottomView
        self.multicityTableView.separatorColor = UIColor.clear
        
        strAdult = "1"
        strChild = "0"
        strInfant = "0"
        
        defaults.set("", forKey: "DselectedCityName")
        defaults.set("", forKey: "DselectedCityCode")
        defaults.set("", forKey: "AselectedCityName")
        defaults.set("", forKey: "AselectedCityCode")
        defaults.set("", forKey: "selectedDeptDate")
        defaults.set("", forKey: "selectedArrDate")
        defaults.set("", forKey: "selectedDeptDay")
        defaults.set("", forKey: "selectedArrDay")
        defaults.set("", forKey: "selectedDeptDate1")
        defaults.set("", forKey: "selectedDeptDate2")
        defaults.set("", forKey: "selectedDeptDate3")
        defaults.set("11", forKey: "DselectedCountryName")
        defaults.set("14", forKey: "AselectedCountryName")
        
        defaults.set("", forKey: "selectedDepartDate1")
        defaults.set("", forKey: "selectedArrivalDate1")
        defaults.set("", forKey: "sDepartDate1")
        defaults.set("", forKey: "sDepartDate2")
        defaults.set("", forKey: "sDepartDate3")
        
        arrMultiDCountry .append("Singapore")
        arrMultiDCountry .append("Malaysia")
        arrMultiDCountry .append("United States of America")
        arrMultiACountry .append("Malaysia")
        arrMultiACountry .append("United States of America")
        arrMultiACountry .append("Singapore")
        
        getCurrentDate()
        control1.setIndex(1)
        segmentView .addSubview(control1)
        
        
        //-----------Hotel -------------------
        self.cityImgView.isHidden = false
        self.nationalityImgView.isHidden = false
        
        self.domesticBtn.isSelected = true
        self.internationalBtn.isSelected = false
        
        self.hotelView.isHidden = true
        self.flightView.isHidden = false
        
        self.flightBtn.isSelected = true
        self.hotelBtn.isSelected = false
        
        
        self.oneDay = 60 * 60 * 24
        self.nextDay = Date().addingTimeInterval(oneDay)
        
        
        self.secondDay = 60 * 60 * 48
        self.thirdDay = Date().addingTimeInterval(self.secondDay)
        print("nextDay",self.nextDay)
        
        dateDisplayFormat.dateFormat = "E, d MMM"
        //        self.checkinDateLbl.text = dateDisplayFormat.string(from: Date())
        self.checkinDateLbl.attributedText = formatDate(dateString: dateDisplayFormat.string(from: Date()))
        //        self.checkoutDateLbl.text = dateDisplayFormat.string(from: nextDay)
        self.checkoutDateLbl.attributedText = formatDate(dateString: dateDisplayFormat.string(from: nextDay))
        
        self.noOfNightsLbl.text = "1 Night"
        self.noOfNight = 1
        
        inputParameterDateFormatterHotel.dateFormat = "dd-MM-yyyy"
        self.selectedCheckinStrToPass = inputParameterDateFormatterHotel.string(from: Date())
        self.selectedCheckoutStrToPass = inputParameterDateFormatterHotel.string(from: nextDay)
        self.selectedCheckinDate = Date()
        self.selectedCheckoutDate = nextDay
        
        self.dateData.checkInDateStr = self.checkinDateLbl.text!
        self.dateData.checkOutDateStr = self.checkoutDateLbl.text!
        self.dateData.noOfNightsStr = self.noOfNightsLbl.text!
        self.dateData.noOfNightsInt = self.noOfNight
        self.dateData.checkInDate = self.selectedCheckinDate
        self.dateData.checkOutDate = self.selectedCheckoutDate
        
        //----------------flight
        self.flightDateData.departDate = Date()
        self.flightDateData.arrivalDate = nextDay
        self.flightDateData.departDate1 = Date()
        self.flightDateData.departDate2 = nextDay
        self.flightDateData.departDate3 = thirdDay
        
      
        let cityTap = UITapGestureRecognizer.init(target: self, action: #selector(cityViewTapped(_:)))
        cityTap.numberOfTapsRequired = 1
        cityView.addGestureRecognizer(cityTap)
        
        self.cityTextField.delegate = self
        
        let nationalityTap = UITapGestureRecognizer.init(target: self, action: #selector(nationalityViewTapped(_:)))
        nationalityTap.numberOfTapsRequired = 1
        nationalityView.addGestureRecognizer(nationalityTap)
        
        self.nationalityTextField.delegate = self
        
        let checkinTap = UITapGestureRecognizer.init(target: self, action: #selector(checkinOrCheckoutDateViewTapped(_:)))
        checkinTap.numberOfTapsRequired = 1
        checkinDateView.addGestureRecognizer(checkinTap)
        
        let checkoutTap = UITapGestureRecognizer.init(target: self, action: #selector(checkinOrCheckoutDateViewTapped(_:)))
        checkoutTap.numberOfTapsRequired = 1
        checkoutDateView.addGestureRecognizer(checkoutTap)
        
        let guestAndRoomTap = UITapGestureRecognizer.init(target: self, action: #selector(guestAndRoomViewTapped(_:)))
        guestAndRoomTap.numberOfTapsRequired = 1
        GuestAndRoomView.addGestureRecognizer(guestAndRoomTap)
    
        
        var aRoomStruct = RoomStruct()
        aRoomStruct.roomNo = 1
        aRoomStruct.noOfAdult = 2
        aRoomStruct.noOfChildren = 0
        
        var child1Struct = ChildrenAgeStruct()
        child1Struct.childNo = 1
        child1Struct.age = 0
        
        var child2Struct = ChildrenAgeStruct()
        child2Struct.childNo = 2
        child2Struct.age = 0
        
        var child3Struct = ChildrenAgeStruct()
        child3Struct.childNo = 3
        child3Struct.age = 0
        
        aRoomStruct.ageArr = [child1Struct,child2Struct,child3Struct]
        self.selectedArr.append(aRoomStruct)
        
        //        self.guestLbl.text = "\(self.selectedArr[0].noOfAdult!) Adults"
        self.guestLbl.attributedText = formatAdultOrRoom(inputString:"\(self.selectedArr[0].noOfAdult!)|ADT" )
        
        //        self.roomLbl.text = "\(self.selectedArr[0].roomNo!) Room"
        self.roomLbl.attributedText = formatAdultOrRoom(inputString: "\(self.selectedArr[0].roomNo!)|Room")
        
        self.perform(#selector(self.showLogin), with: nil, afterDelay: 0.2)
    }
    @objc func showLogin() {
        
        if isLaunchedBefore{
            print("App already launched..So dont show login Page...")
        }else{
            /*     let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "LoginPageVCSBID") as! LoginPageVC
             ctrl.delegateVariable = self
             ctrl.loginFrom = "HomePage"
             self.present(ctrl, animated: true, completion: nil)
             */
            let userSK = defaults.value(forKey: "userSK")
            if userSK == nil
            {
                let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "LoginPageVCSBID") as! LoginPageVC
                ctrl.delegateVariable = self
                ctrl.loginFrom = "HomePage"
                let navController = UINavigationController(rootViewController: ctrl)
                self.present(navController, animated:true, completion: nil)
            }
        }
    }
    
    @objc func guestAndRoomViewTapped(_ responder : UITapGestureRecognizer){
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "HotelGuestAndRoomSelectionVCSBID") as! HotelGuestAndRoomSelectionVC
        //        ctrl.delegateVariable = self
        ctrl.delegateVariable = self
        ctrl.arrOfRoomStruct = self.selectedArr
        self.navigationController!.pushViewController(ctrl, animated: true)
    }
    
    @objc func checkinOrCheckoutDateViewTapped(_ responder : UITapGestureRecognizer){
        /*
         var aStruct = DateSelectedStruct()
         aStruct.checkInDateStr = self.checkinDateLbl.text!
         aStruct.checkOutDateStr = self.checkoutDateLbl.text!
         aStruct.noOfNightsStr = self.noOfNightsLbl.text!
         aStruct.noOfNightsInt = self.noOfNight
         aStruct.checkInDate = self.selectedCheckinDate
         aStruct.checkOutDate = self.selectedCheckoutDate */
        
        
        self.dateData.checkInDateStr = self.checkinDateLbl.text!
        self.dateData.checkOutDateStr = self.checkoutDateLbl.text!
        self.dateData.noOfNightsStr = self.noOfNightsLbl.text!
        self.dateData.noOfNightsInt = self.noOfNight
        self.dateData.checkInDate = self.selectedCheckinDate
        self.dateData.checkOutDate = self.selectedCheckoutDate
        
        //        aStruct.checkInDate = dateDisplayFormat.date(from: self.checkinDateLbl.text!)
        //
        //        dateDisplayFormat.date(from: self.checkoutDateLbl.text!)
        
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "HotelDateSelectionVCSBID") as! HotelDateSelectionVC
        ctrl.delegateVariable = self
        //        ctrl.theSelectedData = aStruct
        ctrl.theSelectedData = self.dateData
        //        inputParameterDateFormatterHotel.date(from: selectedCheckinStrToPass)
        //        inputParameterDateFormatterHotel.date(from: selectedCheckoutStrToPass)
        
        self.navigationController!.pushViewController(ctrl, animated: true)
    }
    
    @objc func nationalityViewTapped(_ responder : UITapGestureRecognizer){
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "HotelNationalityVCSBID") as! HotelNationalityVC
        ctrl.delegateVariable = self
        self.navigationController!.pushViewController(ctrl, animated: true)
        
    }
    @objc func cityViewTapped(_ responder : UITapGestureRecognizer){
        
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "HotelPlacesVCSBID") as! HotelPlacesVC
        ctrl.delegateVariable = self
        domesticBtn.isSelected ? (ctrl.countryType = "ph") : (ctrl.countryType = "")
        //        ctrl.countryType = "Domestic"
        print("ctrl.countryType from cityViewTapped= ",ctrl.countryType)
        self.navigationController!.pushViewController(ctrl, animated: true)
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        
        //----------Flight ------------
        
        onewayBtn.layer.cornerRadius = onewayBtn.bounds.size.height / 2.0
        onewayBtn.layer.masksToBounds = true
        onewayBtn.layer.borderWidth = 1
        
        roundTripbtn.layer.cornerRadius = roundTripbtn.frame.height / 2.0
        roundTripbtn.layer.masksToBounds = true
        roundTripbtn.layer.borderWidth = 1
        
        multiCityBtn.layer.cornerRadius = multiCityBtn.bounds.size.height / 2.0
        multiCityBtn.layer.masksToBounds = true
        multiCityBtn.layer.borderWidth = 1
        
        
        //------------Hotel--------
        flightBtn.layer.cornerRadius = flightBtn.bounds.size.height / 2.0
        flightBtn.layer.masksToBounds = true
        flightBtn.layer.borderWidth = 1
        
        hotelBtn.layer.cornerRadius = hotelBtn.frame.height / 2.0
        hotelBtn.layer.masksToBounds = true
        hotelBtn.layer.borderWidth = 1
        
        if flightBtn.isSelected {
            
            flightBtn.backgroundColor = hexStringToUIColor(hex: "#29266f")
            flightBtn.setTitleColor(UIColor.white, for: .normal)
            flightBtn.setImage(UIImage.init(named: "flightWhite"), for: .normal)
            flightBtn.layer.borderColor = hexStringToUIColor(hex:"#7C7C7C").cgColor
            
            
            hotelBtn.backgroundColor = hexStringToUIColor(hex: "#ffffff")
            hotelBtn.setTitleColor(UIColor.darkGray, for: .normal)
            hotelBtn.setImage(UIImage.init(named: "hotelGray"), for: .normal)
            hotelBtn.layer.borderColor = hexStringToUIColor(hex:"#7C7C7C").cgColor
        }else{
            
            hotelBtn.backgroundColor = hexStringToUIColor(hex: "#29266f")
            hotelBtn.setTitleColor(UIColor.white, for: .normal)
            hotelBtn.setImage(UIImage.init(named: "hotelWhite"), for: .normal)
            hotelBtn.layer.borderColor = hexStringToUIColor(hex:"#7C7C7C").cgColor
            
            flightBtn.backgroundColor = hexStringToUIColor(hex: "#ffffff")
            flightBtn.setTitleColor(UIColor.darkGray, for: .normal)
            flightBtn.setImage(UIImage.init(named: "flightGray"), for: .normal)
            flightBtn.layer.borderColor = hexStringToUIColor(hex:"#7C7C7C").cgColor
            
        }
        
        self.nightView.layer.cornerRadius = self.nightView.frame.height / 2.0
        //        self.nightView.clipsToBounds = true
        self.nightView.layer.masksToBounds = true
        self.nightView.backgroundColor = hexStringToUIColor(hex: "#100055")
        
        self.hotelSearchBtn.layer.cornerRadius = 5
        self.hotelSearchBtn.layer.masksToBounds = true
        
        self.flightSearchBtn.layer.cornerRadius = 5
        self.flightSearchBtn.layer.masksToBounds = true
        
        if domesticBtn.isSelected {
            domesticBtn.setImage(self.selectedImg, for: .normal)
            internationalBtn.setImage(self.unSelectedImg, for: .normal)
        }else{//not needed
            domesticBtn.setImage(self.unSelectedImg, for: .normal)
            internationalBtn.setImage(self.selectedImg, for: .normal)
        }
        
        
    }
    
    @IBAction func flightBtnTapped(_ sender: UIButton) {
        if !sender.isSelected {
            sender.isSelected = true
            hotelBtn.isSelected = false
            
            flightBtn.backgroundColor = hexStringToUIColor(hex: "#100055")
            flightBtn.setTitleColor(UIColor.white, for: .normal)
            flightBtn.setImage(UIImage.init(named: "flightWhite"), for: .normal)
            
            hotelBtn.backgroundColor = hexStringToUIColor(hex: "#ffffff")
            hotelBtn.setTitleColor(UIColor.darkGray, for: .normal)
            hotelBtn.setImage(UIImage.init(named: "hotelGray"), for: .normal)
            
            self.flightView.isHidden = false
            self.hotelView.isHidden = true
        }
    }
    
    @IBAction func hotelBtnTapped(_ sender: UIButton) {
        if !sender.isSelected {
            sender.isSelected = true
            flightBtn.isSelected = false
            
            hotelBtn.backgroundColor = hexStringToUIColor(hex: "#100055")
            hotelBtn.setTitleColor(UIColor.white, for: .normal)
            hotelBtn.setImage(UIImage.init(named: "hotelWhite"), for: .normal)
            
            flightBtn.backgroundColor = hexStringToUIColor(hex: "#ffffff")
            flightBtn.setTitleColor(UIColor.darkGray, for: .normal)
            flightBtn.setImage(UIImage.init(named: "flightGray"), for: .normal)
            
            self.flightView.isHidden = true
            self.hotelView.isHidden = false
            
        }
    }
    
    //----------- Flight -----------
    //    override func viewWillDisappear(_ animated: Bool) {
    //        super.viewWillDisappear(animated)
    //        navigationController?.setNavigationBarHidden(false, animated: false)
    //    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        //---------- Flight ---------
        
        navigationController?.setNavigationBarHidden(true, animated: false)
        print("View will appear")
        defaults .removeObject(forKey: "SavedTravellerArray")
        let departureCity = (defaults.value(forKey: "DselectedCityName") as! String)
        let departureCode = (defaults.value(forKey: "DselectedCityCode") as! String)
        let arrivalCity = (defaults.value(forKey: "AselectedCityName") as! String)
        let arrivalCode = (defaults.value(forKey: "AselectedCityCode") as! String)
        var selectedDeptDate = (defaults.value(forKey: "selectedDeptDate") as! String)
        let selectedArrDate = (defaults.value(forKey: "selectedArrDate") as! String)
        var selectedDeptDay = (defaults.value(forKey: "selectedDeptDay") as! String)
        let selectedArrDay = (defaults.value(forKey: "selectedArrDay") as! String)
        let selectedDeptDate1 = (defaults.value(forKey: "selectedDeptDate1") as! String)
        let selectedDeptDate2 = (defaults.value(forKey: "selectedDeptDate2") as! String)
        let selectedDeptDate3 = (defaults.value(forKey: "selectedDeptDate3") as! String)
        
        selectedDepartDate1 = (defaults.value(forKey: "selectedDepartDate1") as! String)
        selectedArrivalDate1 = (defaults.value(forKey: "selectedArrivalDate1") as! String)
        sDepartDate1 = (defaults.value(forKey: "sDepartDate1") as! String)
        sDepartDate2 = (defaults.value(forKey: "sDepartDate2") as! String)
        sDepartDate3 = (defaults.value(forKey: "sDepartDate3") as! String)
        
        print(selectedDepartDate1)
        print("selectedArrDate",selectedArrDate)
        print(sDepartDate1,sDepartDate2,sDepartDate3)
        
        self.departureCountry = (defaults.value(forKey: "DselectedCountryName") as! String)
        self.arrivalCountry = (defaults.value(forKey: "AselectedCountryName") as! String)
        if (lblDepartureDate.text?.isEmpty)! {
            lblDepartureDate .text = selectedDeptDate
        }
        if arrivalCity.isEmpty
        {
            
        }
        else{
            
            if((wayType == "one") || (wayType == "two") ) && isOneTwoWayCityDepartClicked == false
            {
                txtArrivalCode .text = arrivalCode
                let mySubstring = String(arrivalCity.dropLast(5))
                lblArrivalCity.text = String(mySubstring)
                var last4 = arrivalCity.suffix(4)
                last4 = last4.dropLast(1)
                txtArrivalCode .text = String(last4)
            }
                
            else
            {
                if(multiChoose == "arrive")
                {
                    let mySubstring = String(arrivalCity.dropLast(5))
                    var last4 = arrivalCity.suffix(4)
                    last4 = last4.dropLast(1)
                    print(last4)
                    if(index == 0)
                    {
                        arrMultiArriCity[0] = String(mySubstring)
                        arrMultiArriCode[0] = String(last4)
                        arrMultiDepartCity[1] = String(mySubstring)
                        arrMultiDepartCode[1] = String(last4)
                        arrMultiACountry [0] = self.arrivalCountry
                        arrMultiDCountry [1] = self.arrivalCountry
                        
                    }
                    else if(index == 1)
                    {
                        arrMultiArriCity[1] = String(mySubstring)
                        arrMultiArriCode[1] = String(last4)
                        arrMultiDepartCity[2] = String(mySubstring)
                        arrMultiDepartCode[2] = String(last4)
                        arrMultiACountry [1] = self.arrivalCountry
                        arrMultiDCountry [2] = self.arrivalCountry
                    }
                    else if(index == 2)
                    {
                        arrMultiArriCity[2] = String(mySubstring)
                        arrMultiArriCode[2] = String(last4)
                        arrMultiACountry [2] = self.arrivalCountry
                    }
                    multicityTableView .reloadData()
                }
                
            }
        }
        if departureCity.isEmpty
        {
            
        }
        else{
            
            if((wayType == "one") || (wayType == "two") ) && isOneTwoWayCityDepartClicked == true
            {
                txtDepartureCode .text = departureCode
                let mySubstring = String(departureCity.dropLast(5))
                lblDepartureCIty.text = String(mySubstring)
                var last4 = departureCity.suffix(4)
                last4 = last4.dropLast(1)
                txtDepartureCode .text = String(last4)
            }
                //            else if(wayType == "two"){
                //                RdepartureCity .text = departureCode
                //                let mySubstring = String(departureCity.dropLast(5))
                //                lblRdepartureCountry.text = String(mySubstring)
                //                var last4 = departureCity.suffix(4)
                //                last4 = last4.dropLast(1)
                //                RdepartureCity .text = String(last4)
                //            }
            else
            {
                if(multiChoose == "depart")
                {
                    let mySubstring = String(departureCity.dropLast(5))
                    var last4 = departureCity.suffix(4)
                    last4 = last4.dropLast(1)
                    if(index == 0)
                    {
                        arrMultiDepartCity[0] = String(mySubstring)
                        arrMultiDepartCode[0] = String(last4)
                        arrMultiDCountry [0] = self.departureCountry
                        
                    }
                    else if(index == 1)
                    {
                        arrMultiDepartCity[1] = String(mySubstring)
                        arrMultiDepartCode[1] = String(last4)
                        arrMultiDCountry [1] = self.departureCountry
                    }
                    else if(index == 2)
                    {
                        arrMultiDepartCity[2] = String(mySubstring)
                        arrMultiDepartCode[2] = String(last4)
                        arrMultiDCountry [2] = self.departureCountry
                    }
                    multicityTableView .reloadData()
                }
            }
            
        }
        print(arrMultiArriCode)
        print(arrMultiDepartCode)
        print(arrMultiDepartCity)
        print(arrMultiArriCity)
        print(selectedDeptDate1)
        if selectedDeptDate.isEmpty && (selectedDeptDate1.isEmpty)
        {
            if(wayType == "multi")
            {
                //  getCurrentDate()
            }
            
            // txtDeparture .text = "Source"
        }
        else{
            if  isOneTwoWayDateClicked == true && (wayType == "one")
            {
                lblDepartureDate .text = selectedDeptDate
                let date1 = flightDateFormatter.date(from: selectedDepartDate1 )
                self.flightDateData.departDate = date1
                departdate = selectedDepartDate1
            }
            else if isOneTwoWayDateClicked == true && (wayType == "two")
            {
                lblDepartureDate .text = selectedDeptDate
                lblArrivalDate .text = selectedArrDate
                
                let date1 = flightDateFormatter.date(from: selectedDepartDate1 )
                let date2 = flightDateFormatter.date(from: selectedArrivalDate1)
                
                self.flightDateData.departDate = date1
                self.flightDateData.arrivalDate = date2
                departdate = selectedDepartDate1
                arrivDate = selectedArrivalDate1
            }
            else{
                if  dteBtnCliked == "yes"
                {
                    
                    let date1 = flightDateFormatter.date(from: sDepartDate1 )
                    let date2 = flightDateFormatter.date(from: sDepartDate2 )
                    let date3 = flightDateFormatter.date(from: sDepartDate3 )
                    
                    departDate1 = sDepartDate1
                    departDate2 = sDepartDate2
                    departDate3 = sDepartDate3
                    
                    self.flightDateData.departDate1 = date1
                    self.flightDateData.departDate2 = date2
                    self.flightDateData.departDate3 = date3
                    
                    var arr1 : [String] = [String]()
                    var arr2 : [String] = [String]()
                    var arr3 : [String] = [String]()
                    var selectedMultiDay1 : String = String()
                    var selectedMultiDay2 : String = String()
                    var selectedMultiDay3 : String = String()
                    arr1 = selectedDeptDate1 .components(separatedBy: ",")
                    arr2 = selectedDeptDate2 .components(separatedBy: ",")
                    arr3 = selectedDeptDate3 .components(separatedBy: ",")
                    
                    arrMultiDate1 [0] = selectedDeptDate1
                    arrMultiDate1 [1] = selectedDeptDate2
                    arrMultiDate1 [2] = selectedDeptDate3
                    selectedMultiDay1 = convertDay(arr1[0])
                    selectedMultiDay2 = convertDay(arr2[0])
                    selectedMultiDay3 = convertDay(arr3[0])
                    
                    arrMultiDay [0] = selectedMultiDay1
                    arrMultiDay [1] = selectedMultiDay2
                    arrMultiDay [2] = selectedMultiDay3
                    arrMultiDate [0] = arr1[1]
                    arrMultiDate [1] = arr2[1]
                    arrMultiDate [2] = arr3[1]
                    
                    multicityTableView .reloadData()
                }
                
            }
            
        }
        
        //---------- Flight End---------
    }
    
    @IBAction func hotelSearchBtnTapped(_ sender: UIButton) {
        if !(self.cityTextField.text?.isEmpty)!{
            let DictInput = [
                /*
                 "HotelCity": "coimbatore", //selectedOriginStruct.cityName!,
                 "HotelCountry": "IN", //selectedOriginStruct.countryCode!,
                 "CheckIndate":"08-02-2019", //selectedCheckinDate!,
                 "CheckOutdate":"09-02-2019",
                 "Adult":"2",
                 "Child":"0",
                 "NoOfRooms":"1",
                 "AdultPerRoom1":"2",
                 "ChildrenPerRoom1":"0",
                 "ChildAge1":"0",
                 "ChildAge2":"0",
                 "ChildAge3":"0",
                 "AdultPerRoom2":"0",
                 "ChildrenPerRoom2":"0",
                 "ChildAge21":"0",
                 "ChildAge22":"0",
                 "ChildAge23":"0",
                 "AdultPerRoom3":"0",
                 "ChildrenPerRoom3":"0",
                 "ChildAge31":"0",
                 "ChildAge32":"0",
                 "ChildAge33":"0",
                 "AdultPerRoom4":"0",
                 "ChildrenPerRoom4":"0",
                 "ChildAge41":"0",
                 "ChildAge42":"0",
                 "ChildAge43":"0",
                 "nationality": "IN", //selectedOriginStruct.countryCode!,
                 "supplier":"HotelsPro",
                 "ReqType":"json" */
                
                //            i % 2 == 0 ? i % 3 == 0 ? "fizzbuzz" : "fizz" : i % 3 == 0 ? "buzz" : i.ToString();
                
                /*
                 "HotelCity":selectedOriginStructHotel.cityName!,
                 "HotelCountry":selectedOriginStructHotel.countryCode!,
                 "CheckIndate":selectedCheckinStrToPass!,
                 "CheckOutdate":selectedCheckoutStrToPass!,
                 "Adult":"\(self.totalNoOfAdult)",
                 "Child":"\(self.totalNoOfChildren)",
                 "NoOfRooms":"\(self.selectedArr.count)",
                 "AdultPerRoom1":(self.selectedArr.count > 0) ? "\(self.selectedArr[0].noOfAdult!)" : "0",
                 "ChildrenPerRoom1":(self.selectedArr.count > 0) ? "\(self.selectedArr[0].noOfChildren!)" : "0",
                 "ChildAge1":(self.selectedArr.count > 0) ? (self.selectedArr[0].ageArr.count > 0) ? "\(self.selectedArr[0].ageArr[0].age!)" : "0" : "0",
                 "ChildAge2":(self.selectedArr.count > 0) ? self.selectedArr[0].ageArr.count > 1 ? "\(self.selectedArr[0].ageArr[1].age!)" : "0" : "0",
                 "ChildAge3":(self.selectedArr.count > 0) ? self.selectedArr[0].ageArr.count > 2 ? "\(self.selectedArr[0].ageArr[2].age!)" : "0" : "0",
                 "AdultPerRoom2":(self.selectedArr.count > 1) ? "\(self.selectedArr[1].noOfAdult!)" : "0",
                 "ChildrenPerRoom2":(self.selectedArr.count > 1) ? "\(self.selectedArr[1].noOfChildren!)" : "0",
                 "ChildAge21":(self.selectedArr.count > 1) ? self.selectedArr[1].ageArr.count > 0 ? "\(self.selectedArr[1].ageArr[0].age!)" : "0" : "0",
                 "ChildAge22":(self.selectedArr.count > 1) ? self.selectedArr[1].ageArr.count > 1 ? "\(self.selectedArr[1].ageArr[1].age!)" : "0" : "0",
                 "ChildAge23":(self.selectedArr.count > 1) ? self.selectedArr[1].ageArr.count > 2 ? "\(self.selectedArr[1].ageArr[2].age!)" : "0" : "0",
                 "AdultPerRoom3":(self.selectedArr.count > 2) ? "\(self.selectedArr[2].noOfAdult!)" : "0",
                 "ChildrenPerRoom3":(self.selectedArr.count > 2) ? "\(self.selectedArr[2].noOfChildren!)" : "0",
                 "ChildAge31":(self.selectedArr.count > 2) ? (self.selectedArr[2].ageArr.count > 0) ? "\(self.selectedArr[2].ageArr[0].age!)" : "0" : "0",
                 "ChildAge32":(self.selectedArr.count > 2) ? (self.selectedArr[2].ageArr.count > 1) ? "\(self.selectedArr[2].ageArr[1].age!)" : "0" : "0",
                 "ChildAge33":(self.selectedArr.count > 2) ? (self.selectedArr[2].ageArr.count > 2) ? "\(self.selectedArr[2].ageArr[2].age!)" : "0" : "0",
                 "AdultPerRoom4":(self.selectedArr.count > 3) ? "\(self.selectedArr[3].noOfAdult!)" : "0",
                 "ChildrenPerRoom4":(self.selectedArr.count > 3) ? "\(self.selectedArr[3].noOfChildren!)" : "0",
                 "ChildAge41":(self.selectedArr.count > 3) ? (self.selectedArr[3].ageArr.count > 0) ? "\(self.selectedArr[3].ageArr[0].age!)" : "0" : "0",
                 "ChildAge42":(self.selectedArr.count > 3) ? (self.selectedArr[3].ageArr.count > 1) ? "\(self.selectedArr[3].ageArr[1].age!)" : "0" : "0",
                 "ChildAge43":(self.selectedArr.count > 3) ? (self.selectedArr[3].ageArr.count > 2) ? "\(self.selectedArr[3].ageArr[2].age!)" : "0" : "0",
                 "nationality": selectedOriginStructHotel.countryCode!,
                 "supplier":"HotelsPro|HotelBeds|JacTravel|MikiTravel|Restel|GTA",
                 "ReqType":"json" */
                
                "HotelCity":selectedOriginStructHotel.CityName ?? "Manila", //"Singapore",
                "CityCode":selectedOriginStructHotel.CitySk ?? "50694",//"54800",
                //                "ctype":selectedOriginStructHotel.ctype ?? "city", // should be empty string.Otherwise no output.for city also no input
                "ctype":selectedOriginStructHotel.ctype ?? "",
                "CheckIndate": selectedCheckinStrToPass!, //"08-04-2019",    //selectedCheckinStrToPass!,
                "CheckOutdate": selectedCheckoutStrToPass!,//"09-04-2019",                //selectedCheckoutStrToPass!,
                "Adult":"\(self.totalNoOfAdult)",
                "Child":"\(self.totalNoOfChildren)",
                "NoOfRooms":"\(self.selectedArr.count)",
                "AdultPerRoom1":(self.selectedArr.count > 0) ? "\(self.selectedArr[0].noOfAdult!)" : "0",
                "ChildrenPerRoom1":(self.selectedArr.count > 0) ? "\(self.selectedArr[0].noOfChildren!)" : "0",
                /*
                 "ChildAge1":(self.selectedArr.count > 0) ? (self.selectedArr[0].ageArr.count > 0) ? "\(self.selectedArr[0].ageArr[0].age!)" : "0" : "0",
                 "ChildAge2":(self.selectedArr.count > 0) ? self.selectedArr[0].ageArr.count > 1 ? "\(self.selectedArr[0].ageArr[1].age!)" : "0" : "0",
                 "ChildAge3":(self.selectedArr.count > 0) ? self.selectedArr[0].ageArr.count > 2 ? "\(self.selectedArr[0].ageArr[2].age!)" : "0" : "0", */
                
                /*
                 "ChildAge1":room1AgeArr[0].age, //"0",
                 "ChildAge2":room1AgeArr[1].age,//"0",
                 "ChildAge3":room1AgeArr[2].age,//"0", */
                
                /*
                 "ChildAge1":"0",
                 "ChildAge2":"0",
                 "ChildAge3":"0", */
                
                
                "ChildAge1": "\(self.selectedArr[0].ageArr[0].age!)",
                "ChildAge2":"\(self.selectedArr[0].ageArr[1].age!)",
                "ChildAge3": "\(self.selectedArr[0].ageArr[2].age!)",
                
                "AdultPerRoom2":(self.selectedArr.count > 1) ? "\(self.selectedArr[1].noOfAdult!)" : "0",
                "ChildrenPerRoom2":(self.selectedArr.count > 1) ? "\(self.selectedArr[1].noOfChildren!)" : "0",
                
                /*
                 "ChildAge21":(self.selectedArr.count > 1) ? self.selectedArr[1].ageArr.count > 0 ? "\(self.selectedArr[1].ageArr[0].age!)" : "0" : "0",
                 "ChildAge22":(self.selectedArr.count > 1) ? self.selectedArr[1].ageArr.count > 1 ? "\(self.selectedArr[1].ageArr[1].age!)" : "0" : "0",
                 "ChildAge23":(self.selectedArr.count > 1) ? self.selectedArr[1].ageArr.count > 2 ? "\(self.selectedArr[1].ageArr[2].age!)" : "0" : "0", */
                
                "ChildAge21": (self.selectedArr.count > 1) ? "\(self.selectedArr[1].ageArr[0].age!)" : "0",
                "ChildAge22": (self.selectedArr.count > 1) ? "\(self.selectedArr[1].ageArr[1].age!)" : "0",
                "ChildAge23": (self.selectedArr.count > 1) ? "\(self.selectedArr[1].ageArr[2].age!)" : "0",
                
                /*
                 "ChildAge21":"\(self.selectedArr[1].ageArr[0].age!)",
                 "ChildAge22":"\(self.selectedArr[1].ageArr[1].age!)",
                 "ChildAge23":"\(self.selectedArr[1].ageArr[2].age!)", */
                /*
                 "ChildAge21":"0",
                 "ChildAge22":"0",
                 "ChildAge23":"0", */
                
                "AdultPerRoom3":(self.selectedArr.count > 2) ? "\(self.selectedArr[2].noOfAdult!)" : "0",
                "ChildrenPerRoom3":(self.selectedArr.count > 2) ? "\(self.selectedArr[2].noOfChildren!)" : "0",
                /*
                 "ChildAge31":(self.selectedArr.count > 2) ? (self.selectedArr[2].ageArr.count > 0) ? "\(self.selectedArr[2].ageArr[0].age!)" : "0" : "0",
                 "ChildAge32":(self.selectedArr.count > 2) ? (self.selectedArr[2].ageArr.count > 1) ? "\(self.selectedArr[2].ageArr[1].age!)" : "0" : "0",
                 "ChildAge33":(self.selectedArr.count > 2) ? (self.selectedArr[2].ageArr.count > 2) ? "\(self.selectedArr[2].ageArr[2].age!)" : "0" : "0", */
                
                "ChildAge31": (self.selectedArr.count > 2) ? "\(self.selectedArr[2].ageArr[0].age!)" : "0",
                "ChildAge32": (self.selectedArr.count > 2) ? "\(self.selectedArr[2].ageArr[1].age!)" : "0",
                "ChildAge33": (self.selectedArr.count > 2) ? "\(self.selectedArr[2].ageArr[2].age!)" : "0",
                
                /*
                 "ChildAge31":"0",
                 "ChildAge32":"0",
                 "ChildAge33":"0",*/
                
                "AdultPerRoom4":(self.selectedArr.count > 3) ? "\(self.selectedArr[3].noOfAdult!)" : "0",
                "ChildrenPerRoom4":(self.selectedArr.count > 3) ? "\(self.selectedArr[3].noOfChildren!)" : "0",
                /*
                 "ChildAge41":(self.selectedArr.count > 3) ? (self.selectedArr[3].ageArr.count > 0) ? "\(self.selectedArr[3].ageArr[0].age!)" : "0" : "0",
                 "ChildAge42":(self.selectedArr.count > 3) ? (self.selectedArr[3].ageArr.count > 1) ? "\(self.selectedArr[3].ageArr[1].age!)" : "0" : "0",
                 "ChildAge43":(self.selectedArr.count > 3) ? (self.selectedArr[3].ageArr.count > 2) ? "\(self.selectedArr[3].ageArr[2].age!)" : "0" : "0", */
                
                "ChildAge41": (self.selectedArr.count > 3) ? "\(self.selectedArr[3].ageArr[0].age!)" : "0",
                "ChildAge42": (self.selectedArr.count > 3) ? "\(self.selectedArr[3].ageArr[1].age!)" : "0",
                "ChildAge43": (self.selectedArr.count > 3) ? "\(self.selectedArr[3].ageArr[2].age!)" : "0",
                
                /*
                 "ChildAge41":"0",
                 "ChildAge42":"0",
                 "ChildAge43":"0", */
                
                "nationality": selectedNationalityStructHotel.CountryName ?? "India", //selectedOriginStructHotel.Country ?? "India",
                "supplier": self.domesticBtn.isSelected ? "HotelExtranet" : "HotelBeds|MikiTravel",  // "HotelBeds|MikiTravel|HotelExtranet",
                "ReqType":"json"
            ]
            //            HotelsPro",@"HotelBeds",@"JacTravel",@"MikiTravel",@"Restel",@“GTA"
            
            let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "HotelResultVCSBID") as! HotelResultVC
            ctrl.inputDict = DictInput
            ctrl.theDateData = self.dateData
            ctrl.guestAndRoomDetailsArr = self.selectedArr
            //            ctrl.noOfNights = self.noOfNightLbl.text!
            self.navigationController?.pushViewController(ctrl, animated: true)
        }else{
            self.view.ShowBlackTostWithText(message: "Please select city", Interval: 3)
            
        }
    }
    @IBAction func flightSearchBtnTapped(_ sender: UIButton) {
        //          let DictInput = ["Origin":self.originToPass!,"Destination":self.destinationToPass!,"DepartureDate":selectedDepartOnStrToPass!,"Returndate":selectedReturnOnStrToPass!,"WayType":self.onewayBtn.isSelected ? "one":"two","CabinClass":self.classSelectedItem,"AdultCount":self.adultSelectedItem,"ChildCount":self.childrenSelectedItem,"InfantCount":self.infantSelectedItem,"SeniorCount":"0","PreferredCarrier":"1","PromotionalPlanType":"0","SearchSessionid":"0","ModuleId":"14","ParentAccountId":"IXCRAJ042","ChildAccountId":"IXCRAJ042","ApiName":"TBO","NonStop":"","ReqType":"JSON"]
        isOneTwoWayDateClicked = false
        var DictInput = Dictionary<String, String>()
        if(wayType == "one")
        {
            if (self.txtDepartureCode.text == "" )
            {
                String().alert(view: self, title: "UniOrient Info", message: "Choose Source Airport/City")
                // self.view.ShowBlackTostWithText(message: "Source and Destination city should not be same.", Interval: 3)
            }
            else if (self.txtDepartureCode.text == "" )
            {
                String().alert(view: self, title: "UniOrient Info", message: "Choose Destination Airport/City")
                // self.view.ShowBlackTostWithText(message: "Source and Destination city should not be same.", Interval: 3)
            }
                
            else if (self.txtDepartureCode.text == self.txtArrivalCode.text )
            {
                String().alert(view: self, title: "UniOrient Info", message: "Source and Destination city should not be same.")
                // self.view.ShowBlackTostWithText(message: "Source and Destination city should not be same.", Interval: 3)
            }
            else{
                var strNonStop : String = String()
                //  var departDate : String = String()
                
                print(departdate, selectedDepartDate1)
                let dateformatter = DateFormatter()
                dateformatter.dateFormat = "yyyy-MM-dd"
                let today = dateformatter.string(from: Date())
                print(departdate!, arrivDate!, today)
                
                if !departdate .contains("2019-")
                {
                    departdate = convertDateFormater(departdate)
                }
                
                //              if departdate != today
                //                {
                //                    departdate = convertDateFormater(departdate)
                //                }
                
                print(departdate)
                // departDate = convertDateFormater(self.lblDepartureDate.text!)
                //  print("date",departDate)
                if stopBtn.isSelected == true
                {
                    strNonStop = "0"
                }
                else
                {
                    strNonStop = "1"
                }
                if self.departureCountry == self.arrivalCountry
                {
                    self.module_SK = "11"
                }
                else
                {
                    self.module_SK = "14"
                }
                DictInput = ["Origin":self.txtDepartureCode.text!,"Destination":self.txtArrivalCode.text! ,"DepartureDate":departdate,"Returndate":"","WayType":"one","CabinClass":self.lblClass.text!,"AdultCount":strAdult,"ChildCount":strChild,"InfantCount":strInfant,"SeniorCount":"0","PreferredCarrier":"1","PromotionalPlanType":"0","SearchSessionid":"0","ModuleId":self.module_SK,"ParentAccountId":"IXCRAJ042","ChildAccountId":"IXCRAJ042","ApiName":"TBO","NonStop":strNonStop,"ReqType":"JSON"]
                print(DictInput)
                let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "FlightResultVC") as! FlightResultVCGoomo
                ctrl.inputDict = DictInput
                self.navigationController?.pushViewController(ctrl, animated: true)
            }
            
        }
        else if(wayType == "two")
        {
            if (self.txtDepartureCode.text == "" )
            {
                String().alert(view: self, title: "UniOrient Info", message: "Choose Source Airport/City")
                // self.view.ShowBlackTostWithText(message: "Source and Destination city should not be same.", Interval: 3)
            }
            else if (self.txtDepartureCode.text == "" )
            {
                String().alert(view: self, title: "UniOrient Info", message: "Choose Destination Airport/City")
                // self.view.ShowBlackTostWithText(message: "Source and Destination city should not be same.", Interval: 3)
            }
            else if (self.txtDepartureCode.text == self.txtArrivalCode.text )
            {
                self.view.ShowBlackTostWithText(message: "Source and Destination city should not be same.", Interval: 3)
            }
            else
            {
                var strNonStop : String = String()
                //  var departDate : String = String()
                
                let dateformatter = DateFormatter()
                dateformatter.dateFormat = "yyyy-MM-dd"
                let today = dateformatter.string(from: Date())
                print(departdate!, arrivDate!, today)
                
                if arrivDate .contains("2019-")
                {
                    // arrivDate = convertDateFormater1(arrivDate)
                }
                else
                {
                    arrivDate = convertDateFormater(arrivDate)
                }
                if departdate != today
                {
                    departdate = convertDateFormater(departdate)
                    
                }
                
                //                if !departdate .contains("2019-") || !departdate .contains("2020-")
                //                {
                //                    departdate = convertDateFormater(departdate)
                //                }
                //                else if !arrivDate .contains("2019-") || !arrivDate .contains("2020-")
                //                {
                //                    arrivDate = convertDateFormater(arrivDate)
                //
                //                }
                print(departdate, arrivDate)
                if stopBtn.isSelected == true
                {
                    strNonStop = "0"
                }
                else
                {
                    strNonStop = "1"
                }
                
                if self.departureCountry == self.arrivalCountry
                {
                    self.module_SK = "11"
                }
                else
                {
                    self.module_SK = "14"
                }
                DictInput = ["Origin":self.txtDepartureCode.text!,"Destination":self.txtArrivalCode.text!,"DepartureDate":departdate,"Returndate":arrivDate,"WayType":"two","CabinClass":self.lblClass.text!,"AdultCount":strAdult,"ChildCount":strChild,"InfantCount":strInfant,"SeniorCount":"0","PreferredCarrier":"1","PromotionalPlanType":"0","SearchSessionid":"0","ModuleId":self.module_SK,"ParentAccountId":"IXCRAJ042","ChildAccountId":"IXCRAJ042","ApiName":"TBO","NonStop":strNonStop,"ReqType":"JSON"]
                let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "FlightResultVC") as! FlightResultVCGoomo
                ctrl.inputDict = DictInput
                self.navigationController?.pushViewController(ctrl, animated: true)
            }
            
        }
        else{
            
            if (arrMultiDepartCode[0] == "Airport" )
            {
                String().alert(view: self, title: "UniOrient Info", message: "Choose Source1 Airport/City")
                // self.view.ShowBlackTostWithText(message: "Source and Destination city should not be same.", Interval: 3)
            }
            else if (arrMultiArriCode[0] == "Airport" )
            {
                String().alert(view: self, title: "UniOrient Info", message: "Choose Destination1 Airport/City")
                // self.view.ShowBlackTostWithText(message: "Source and Destination city should not be same.", Interval: 3)
            }
            else if (arrMultiArriCode[1] == "Airport" )
            {
                String().alert(view: self, title: "UniOrient Info", message: "Choose Destination2 Airport/City")
                // self.view.ShowBlackTostWithText(message: "Source and Destination city should not be same.", Interval: 3)
            }
            else if (arrMultiArriCode[2] == "Airport" )
            {
                String().alert(view: self, title: "UniOrient Info", message: "Choose Destination3 Airport/City")
                // self.view.ShowBlackTostWithText(message: "Source and Destination city should not be same.", Interval: 3)
            }
            else{
                var strNonStop : String = String()
                print(arrMultiDate1)
                
                let dateformatter = DateFormatter()
                dateformatter.dateFormat = "yyyy-MM-dd"
                let today = dateformatter.string(from: Date())
                print(departDate1!,departDate2!,departDate3!, arrivDate!, today)
                if !departDate1 .contains("2019-")
                {
                    departDate1 = convertDateFormater(departDate1)
                }
                if !departDate2 .contains("2019-")
                {
                    departDate2 = convertDateFormater(departDate2)
                }
                if !departDate3 .contains("2019-")
                {
                    departDate3 = convertDateFormater(departDate3)
                }
                
                //                if departDate1 != today
                //                {
                //                    departDate1 = convertDateFormater(departDate1)
                //                    print("date1",departDate1)
                //                    departDate2 = convertDateFormater(departDate2)
                //                    print("date2",departDate2)
                //                    departDate3 = convertDateFormater(departDate3)
                //                    print("date3",departDate3)
                //                }
                
                
                if multiStopBtn.isSelected == true
                {
                    strNonStop = "0"
                }
                else
                {
                    strNonStop = "1"
                }
                print ("departCountry",self.arrMultiDCountry)
                print("arrivCountry",self.arrMultiACountry)
                if self.arrMultiDCountry[0] == self.arrMultiACountry[0] && self.arrMultiDCountry[0] == self.arrMultiACountry[1] && self.arrMultiDCountry[0] == self.arrMultiACountry[2] && self.arrMultiDCountry[1] == self.arrMultiACountry[0] &&
                    self.arrMultiDCountry[1] == self.arrMultiACountry[1] &&
                    self.arrMultiDCountry[1] == self.arrMultiACountry[2] &&
                    self.arrMultiDCountry[2] == self.arrMultiACountry[0] &&
                    self.arrMultiDCountry[2] == self.arrMultiACountry[1] &&
                    self.arrMultiDCountry[2] == self.arrMultiACountry[2]
                {
                    self.module_SK = "11"
                }
                else
                {
                    self.module_SK = "14"
                }
                DictInput = ["Origin1":arrMultiDepartCode[0],"Destination1":arrMultiArriCode[0],"DepartureDate1":departDate1,"Origin2":arrMultiDepartCode[1],"Destination2":arrMultiArriCode[1],"DepartureDate2":departDate2,"Origin3":arrMultiDepartCode[2],"Destination3":arrMultiArriCode[2],"DepartureDate3":departDate3,"WayType":"multi","CabinClass":self.lblMultiClass.text!,"AdultCount":strAdult,"ChildCount":strChild,"InfantCount":strInfant,"SeniorCount":"0","PreferredCarrier":"1","PromotionalPlanType":"0","SearchSessionid":"0","ModuleId":self.module_SK,"ParentAccountId":"IXCRAJ042","ChildAccountId":"IXCRAJ042","ApiName":"TBO","NonStop":strNonStop,"ReqType":"JSON","WayCount":"3"]
                
                let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "FlightResultVC") as! FlightResultVCGoomo
                ctrl.inputDict = DictInput
                self.navigationController?.pushViewController(ctrl, animated: true)
            }
            
        }
        
        
    }
    //----------Flight------------
    @IBAction func segmentedControl1ValueChanged(_ sender: BetterSegmentedControl) {
        print("The selected index is \(sender.index)")
        if sender.index == 0
        {
            wayType = "one"
            defaults .set("one", forKey: "wayType")
            self.onewayArrivalDateView.isHidden = false
            self.onewayRoundTripView.isHidden = false
            self.roundTripDateView.isHidden = true
            self.multicityTableView.isHidden = true
            
        }
        else if sender.index == 1
        {
            wayType = "two"
            defaults .set("two", forKey: "wayType")
            self.onewayArrivalDateView.isHidden = true
            self.roundTripDateView.isHidden = false
            self.multicityTableView.isHidden = true
            self.onewayRoundTripView.isHidden = false
            isMultiSelected = "no"
            print(departdate)
            let dateformatter = DateFormatter()
            dateformatter.dateFormat = "yyyy-MM-dd"
            let today = dateformatter.string(from: Date())
            print(departdate!, arrivDate!, today)
            
            if departdate == today
            {
                departdate = convertDateFormater1(departdate)
                convertNextDate(dateString: departdate)
            }
            else
            {
                if departdate .contains("2019-")
                {
                    departdate = convertDateFormater1(departdate)
                }
                convertNextDate(dateString: departdate)
            }
            
        }
        else if sender.index == 2
        {
            wayType = "multi"
            defaults .set("multi", forKey: "wayType")
            self.onewayArrivalDateView.isHidden = true
            self.roundTripDateView.isHidden = true
            self.onewayRoundTripView.isHidden = true
            self.multicityTableView.isHidden = false
            
        }
    }
    
    
    
    @IBAction func nonStopBtn(_ sender: UIButton)// //
    {
        if(wayType == "one") || (wayType == "two")
        {
            if stopBtn.isSelected == true {
                stopBtn.isSelected = false
                nonSTopImg.image = UIImage (named: "square.png")
                
            }else {
                stopBtn.isSelected = true
                nonSTopImg.image = UIImage (named: "black-check-box-with-white-check.png")
            }
        }
            
        else
        {
            if multiStopBtn.isSelected == true {
                multiStopBtn.isSelected = false
                multiSTopImg.image = UIImage (named: "square.png")
                
            }else {
                multiStopBtn.isSelected = true
                multiSTopImg.image = UIImage (named: "black-check-box-with-white-check.png")
            }
        }
        
    }
    
    @IBAction func departCityChoseBtn(_ sender: Any) //
    {
        isOneTwoWayCityDepartClicked = true
        isOneTwoWayDateClicked = false
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "searchCityVC") as? SearchCityViewController
        vc?.selectableCity = "departure"
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    @IBAction func arrivalCityChoseBtn(_ sender: Any)//
    {
        isOneTwoWayCityDepartClicked = false
        isOneTwoWayDateClicked = false
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "searchCityVC") as? SearchCityViewController
        vc?.selectableCity = "arrival"
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    @IBAction func departDateChoseBtn(_ sender: Any)//
    {
        isOneTwoWayDateClicked = true
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "CustomCalenderVC") as? CustomCalenderViewController
        vc?.selectableDate = "departureDate"
        vc?.flightSelectedData = self.flightDateData
        vc?.selectedDepartDate = self.lblDepartureDate.text!
        vc?.selectedArrivDate = self.lblArrivalDate.text!
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    @IBAction func arrivalDateChoseBtn(_ sender: Any)//
    {
        isOneTwoWayDateClicked = true
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "CustomCalenderVC") as? CustomCalenderViewController
        vc?.selectableDate = "arrivalDate"
        vc?.flightSelectedData = self.flightDateData
        vc?.selectedDepartDate = self.lblDepartureDate.text!
        vc?.selectedArrivDate = self.lblArrivalDate.text!
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    @IBAction func classChoseBtn(_ sender: Any)// //
    {
        isOneTwoWayDateClicked = false
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "passengerVC") as? PassengerViewController
        vc?.selectableTraveller = wayType
        vc?.delegateVariable = self
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    @objc func departBtnClicked(sender: UIButton){
        wayType = "multi"
        dteBtnCliked = "no"
        multiChoose = "depart"
        isOneTwoWayDateClicked = false
        let buttonPosition:CGPoint = sender.convert(CGPoint.zero, to:self.multicityTableView)
        let indexPath = self.multicityTableView.indexPathForRow(at: buttonPosition)
        index = indexPath!.row
        print("index",index)
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "searchCityVC") as? SearchCityViewController
        vc?.selectableCity = "departure"
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    @objc func arriBtnClicked(sender: UIButton)
    {
        wayType = "multi"
        dteBtnCliked = "no"
        multiChoose = "arrive"
        isOneTwoWayDateClicked = false
        let buttonPosition:CGPoint = sender.convert(CGPoint.zero, to:self.multicityTableView)
        let indexPath = self.multicityTableView.indexPathForRow(at: buttonPosition)
        index = indexPath!.row
        print("index",index)
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "searchCityVC") as? SearchCityViewController
        vc?.selectableCity = "arrival"
        self.navigationController?.pushViewController(vc!, animated: true)
        
    }
    @objc func dateBtnClicked(sender: UIButton)
    {
        wayType = "multi"
        dteBtnCliked = "yes"
        multiChoose = "multiDate"
        isOneTwoWayDateClicked = false
        let buttonPosition:CGPoint = sender.convert(CGPoint.zero, to:self.multicityTableView)
        let indexPath = self.multicityTableView.indexPathForRow(at: buttonPosition)
        index = indexPath!.row
        print("index",index)
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "CustomCalenderVC") as? CustomCalenderViewController
        vc?.selectableDate = "departureDate"
        vc?.flightSelectedData = self.flightDateData
        vc?.selectdDate1 = arrMultiDate[0] + "+" + arrMultiDay[0]
        vc?.selectdDate2 = arrMultiDate[1] + "+" + arrMultiDay[1]
        vc?.selectdDate3 = arrMultiDate[2] + "+" + arrMultiDay[2]
        vc?.selectedIndex = "\(index)"
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    
    
    //////Get current date
    func getCurrentDate()
    {
        let date1 = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "E, d MMM, yyyy"//"dd MMMM,yyyy"//"YYYY-MM-dd"//"dd MMM yy"//2019-05-15
        let result = formatter.string(from: date1)
        print(result)
        
        /////getDay
        let date = Date()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "EEEE"
        let dayInWeek = dateFormatter.string(from: date)
        print(dayInWeek)
        
        /////////get nextdate
        
        print(convertNextDate(dateString: result))
        departdate = convertDateFormater(result)
        departDate1 = convertDateFormater(result)
        
        var arrDate = result .components(separatedBy: ",")
        print(arrDate)
        lblDepartureDate . text = arrDate[0] + ", " + arrDate[1]
        //   lblDepartureDay.text = dayInWeek
        
        arrMultiDay [0] = dayInWeek
        arrMultiDate [0] =  arrDate[1]
        arrMultiDate1 [0] = arrDate[0] + ", " + arrDate[1]
        
    }
    
    func convertNextDate(dateString : String)
    {
        print(dateString)
        let myDate = flightDateFormatter.date(from: dateString)!
        let tomorrow = Calendar.current.date(byAdding: .day, value: 1, to: myDate)
        let somedateString = flightDateFormatter.string(from: tomorrow!)
        print("your next Date is2 \(somedateString)")
        
        arrivDate = convertDateFormater(somedateString)
        departDate2 = convertDateFormater(somedateString)
        
        var arrDate = somedateString .components(separatedBy: ",")
        print(arrDate)
        lblArrivalDate . text = arrDate[0] + ", " + arrDate[1]
     
        //--------
        
        print(somedateString)
        print(arrivDate)
        
        let date1 : Date!
       
        if selectedDepartDate1 == nil || selectedDepartDate1 == ""
        {
           date1 = flightFDateFormatter.date(from: arrivDate)
            self.flightDateData.arrivalDate = date1
        }
        else{
            date1 = flightFDateFormatter.date(from: arrivDate)
            self.flightDateData.arrivalDate = date1
        }
        
      print(date1!)
        
        ///Get next day
        let isoDate = somedateString
    
        let date2 = flightDateFormatter.date(from:isoDate)!
        print(date2)
        let dayInWeek1 = flightDateFormatter.string(from: date2)
        
        let date = date2
        let dateFormatter2 = DateFormatter()
        dateFormatter2.dateFormat = "EEEE"
        let dayInWeek = dateFormatter2.string(from: date)
        print(dayInWeek)
        
        if(isMultiSelected == "yes"){
            arrMultiDay [1] = dayInWeek
            arrMultiDate [1] = arrDate[1]
            arrMultiDate1 [1] = arrDate[0] + ", " + arrDate[1]
        }
        print(convertNextDate1(dateString: somedateString))
        
    }
    
    func convertNextDate1(dateString : String){
     
        let myDate = flightDateFormatter.date(from: dateString)!
        let tomorrow = Calendar.current.date(byAdding: .day, value: 1, to: myDate)
        let somedateString = flightDateFormatter.string(from: tomorrow!)
        print("your next Date is3 \(somedateString)")
        
        departDate3 = convertDateFormater(somedateString)
        ///Get next day
        let isoDate = somedateString
  
        let date2 = flightDateFormatter.date(from:isoDate)!
        print(date2)
        let dayInWeek1 = flightDateFormatter.string(from: date2)
        
        let date = date2
        let dateFormatter2 = DateFormatter()
        dateFormatter2.dateFormat = "EEEE"
        let dayInWeek = dateFormatter2.string(from: date)
        print(dayInWeek)
        
        var arrDate = somedateString .components(separatedBy: ",")
        print(arrDate)
        
        print("your next day is \(dayInWeek)")
        if(isMultiSelected == "yes"){
            arrMultiDay [2] = dayInWeek
            arrMultiDate [2] = arrDate[1]
            arrMultiDate1 [2] =  arrDate[0] + ", " + arrDate[1]
            multicityTableView .reloadData()
        }
        
        
    }
    func convertDateFormater(_ date: String) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "E, d MMM, yyyy"
        let date = dateFormatter.date(from: date)
        dateFormatter.dateFormat = "yyyy-MM-dd"
        return  dateFormatter.string(from: date!)
        
    }
    func convertDateFormater1(_ date: String) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let date = dateFormatter.date(from: date)
        dateFormatter.dateFormat = "E, d MMM, yyyy"
        return  dateFormatter.string(from: date!)
        
    }
    func convertDateFormater2(_ date: String) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "E, d MMM, yyyy"
        let date = dateFormatter.date(from: date)
        dateFormatter.dateFormat = "E, d MMM, yyyy"
        return  dateFormatter.string(from: date!)
        
    }
    func convertDay(_ day: String) -> String
    {
        var selectedDay : String = String()
        if (day == "Sun")
        {
            selectedDay = "Sunday"
        }
        else if (day == "Mon")
        {
            selectedDay = "Monday"
        }
        else if (day == "Tue")
        {
            selectedDay = "Tuesday"
        }
        else if (day == "Wed")
        {
            selectedDay = "Wednesday"
        }
        else if (day == "Thu")
        {
            selectedDay = "Thursday"
        }
        else if (day == "Fri")
        {
            selectedDay = "Friday"
        }
        else if (day == "Sat")
        {
            selectedDay = "Saturday"
        }
        return selectedDay
    }
    
    @IBAction func swapIcon(_ sender: Any)
    {
        let button = sender as! UIButton
        button.isSelected = !button.isSelected
        UIButton.animate(withDuration: 0.2,
                         animations: {
                            button.transform = CGAffineTransform(scaleX: 0.975, y: 0.96)
        },
                         completion: { finish in
                            UIButton.animate(withDuration: 0.2, animations: {
                                button.transform = CGAffineTransform.identity
                            })
        })
        
       // UIView.beginAnimations(nil, context: nil)
     
        strTem1 = txtDepartureCode.text
        strTemp2 = lblDepartureCIty.text
        
        txtDepartureCode.text = txtArrivalCode.text
        txtArrivalCode.text = strTem1
        lblDepartureCIty.text = lblArrivalCity.text
        lblArrivalCity.text = strTemp2
        
        //self.view.layer.removeAllAnimations()
    }
    // -----------Flight End ----------------
}
extension HomePageVC : UITextFieldDelegate {
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.resignFirstResponder()
        if textField == cityTextField  {
            let ctrl = self.storyboard?.instantiateViewController(withIdentifier:"HotelPlacesVCSBID") as! HotelPlacesVC
            ctrl.delegateVariable = self
            domesticBtn.isSelected ? (ctrl.countryType = "ph") : (ctrl.countryType = "")
            print("ctrl.countryType from textFieldDidBeginEditing = ",ctrl.countryType)
            self.navigationController!.pushViewController(ctrl, animated: true)
            //    self.present(ctrl, animated: true, completion: nil)
        }
        if textField == nationalityTextField {
            let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "HotelNationalityVCSBID") as! HotelNationalityVC
            ctrl.delegateVariable = self
            self.navigationController!.pushViewController(ctrl, animated: true)
        }
    }
}
extension HomePageVC : HotelPlacesDelegate{
    //    func didSelectCity(selectedHotelCityStruct: HotelCityStructNew, controller: HotelPlacesVC) {
    //
    //    }
    func didSelectCity(selectedHotelCityStruct: HotelCityStructNew, controller: HotelPlacesVC) {
        //        controller.dismiss(animated: true, completion: nil)
        self.navigationController?.popViewController(animated: true)
        self.cityTextField.text = selectedHotelCityStruct.CityName!
        self.cityImgView.isHidden = true
        self.cityPlaceHolderLbl.text = "City"
        self.selectedOriginStructHotel = selectedHotelCityStruct
        
    }
    
}
extension HomePageVC : HotelNationalityDelegate {
    
    /*
     func didSelectCity(selectedHotelCityStruct: HotelCityStructNew, controller: HotelPlacesVC) {
     //        controller.dismiss(animated: true, completion: nil)
     self.navigationController?.popViewController(animated: true)
     self.cityTextField.text = selectedHotelCityStruct.CityName!
     self.selectedOriginStructHotel = selectedHotelCityStruct */
    
    func didSelectNation(selectedHotelNationalityStruct: HotelNationalityStruct, controller: HotelNationalityVC) {
        self.navigationController?.popViewController(animated: true)
        self.nationalityTextField.text = selectedHotelNationalityStruct.CountryName!
        self.nationalityImgView.isHidden = true
        self.nationalityPlaceHolderLbl.text = "Nationality"
        //        self.selectedOriginStructHotel = selectedHotelCityStruct
        self.selectedNationalityStructHotel = selectedHotelNationalityStruct
    }
}
extension HomePageVC : HotelGuestAndRoomSelectionProtocol {
    func didRoomAndGuestDetailDoneBtnTapped(selectedArrayOfRoomStruct: [RoomStruct], controller: HotelGuestAndRoomSelectionVC) {
        print("From RoomAndGuestDetailProtocol")
        
        self.selectedArr = selectedArrayOfRoomStruct
        //        self.roomTxtField.text = "\(self.selectedArr.count) Room"
        
        self.totalNoOfAdult = 0
        self.totalNoOfChildren = 0
        for aStruct in self.selectedArr {
            self.totalNoOfAdult += aStruct.noOfAdult
            self.totalNoOfChildren += aStruct.noOfChildren
        }
        
        //        self.guestTxtField.text = "\(self.totalNoOfAdult) Adults"
        print("Total No Of Children = \(self.totalNoOfChildren)")
        
        //        self.roomAndGuestTxtField.text = "\(self.selectedArr.count) Room \(self.totalNoOfAdult) Adults"
        
        
        
        /*  var strTemp : String!
         if "\(self.totalNoOfChildren)" == "0" {
         strTemp = "\(self.totalNoOfAdult)|ADT"
         }else{
         strTemp = "\(self.totalNoOfAdult)|ADT|\(self.totalNoOfChildren)|CHD"
         }
         self.guestLbl.attributedText = formatAdultOrRoom(inputString: strTemp) */
        
        //        self.guestLbl.text = "\(self.totalNoOfAdult) ADT,\(self.totalNoOfChildren) CHD"
        self.guestLbl.attributedText = ("\(self.totalNoOfChildren)" == "0") ? formatAdultOrRoom(inputString: "\(self.totalNoOfAdult)|ADT") : formatAdultOrRoom(inputString: "\(self.totalNoOfAdult)|ADT|\(self.totalNoOfChildren)|CHD")
        
        //        self.roomLbl.text = "\(self.selectedArr.count) Room"
        self.roomLbl.attributedText = ("\(self.selectedArr.count)" == "1") ? formatAdultOrRoom(inputString: "\(self.selectedArr.count)|Room") : formatAdultOrRoom(inputString: "\(self.selectedArr.count)|Rooms")
        
        
    }
}
extension HomePageVC : DateSelectionProcol {
    func didConfirmBtnTapped(selectedDateDict: [String? : Date?], noOfNightsStr: String?, noOfNightsInt: Int?, controller: HotelDateSelectionVC) {
        
        //        self.checkinDateLbl.text = dateDisplayFormat.string(from: selectedDateDict["checkInDate"]!!)
        self.checkinDateLbl.attributedText = formatDate(dateString: dateDisplayFormat.string(from: selectedDateDict["checkInDate"]!!))
        //        self.checkoutDateLbl.text = dateDisplayFormat.string(from: selectedDateDict["checkOutDate"]!!)
        self.checkoutDateLbl.attributedText = formatDate(dateString: dateDisplayFormat.string(from: selectedDateDict["checkOutDate"]!!))
        
        self.selectedCheckinStrToPass = inputParameterDateFormatterHotel.string(from: selectedDateDict["checkInDate"]!!)
        self.selectedCheckoutStrToPass = inputParameterDateFormatterHotel.string(from: selectedDateDict["checkOutDate"]!!)
        
        self.noOfNightsLbl.text = noOfNightsStr
        self.noOfNight = noOfNightsInt
        
        self.selectedCheckinDate = selectedDateDict["checkInDate"]!
        self.selectedCheckoutDate = selectedDateDict["checkOutDate"]!
        
        
        self.dateData.checkInDateStr = self.checkinDateLbl.text!
        self.dateData.checkOutDateStr = self.checkoutDateLbl.text!
        self.dateData.noOfNightsStr = self.noOfNightsLbl.text!
        self.dateData.noOfNightsInt = self.noOfNight
        self.dateData.checkInDate = self.selectedCheckinDate
        self.dateData.checkOutDate = self.selectedCheckoutDate
        self.navigationController?.popViewController(animated: true)
    }
    
    
    //    func didConfirmBtnTapped(selectedDateStringsDict: [String? : String?], controller: HotelDateSelectionVC) {
    //
    //        self.checkinDateLbl.text = selectedDateStringsDict["checkInStr"]!
    //        self.checkoutDateLbl.text = selectedDateStringsDict["checkOutStr"]!
    //        self.navigationController?.popViewController(animated: true)
    //    }
    
    
    
}
extension HomePageVC : LoginProtocol {
    func didLoggedIn(controller: LoginPageVC) {
        controller.dismiss(animated: true, completion: nil)
    }
}

// -------------Flight -----------
extension HomePageVC : savePassengerDetailsDelegate{
    func saveFightPassenger(passengerStruct: passengerDetailsStruct, viewController: PassengerViewController)
    {
        print(passengerStruct)
        self.navigationController?.popViewController(animated: true)
        strAdult = passengerStruct.Adult
        strChild = passengerStruct.Child
        strInfant = passengerStruct.Infant
        
        print(strAdult)
        print(strChild)
        if(wayType == "one") || (wayType == "two")
        {
            self.lblTraveller . text = "\(strAdult) ADT, \(strChild) CHD, \(strInfant) INF"
            self.lblClass.text = passengerStruct.cabinClass
        }
        else
        {
            self.lblMultiTraveller . text = "\(strAdult) Adult, \(strChild) Child, \(strInfant) Infant"
            self.lblMultiClass.text = passengerStruct.cabinClass
        }
    }
}
extension HomePageVC : UITableViewDelegate, UITableViewDataSource
{
    ///////////// tableView DataSource - Delegate Method
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView,
                   numberOfRowsInSection section: Int) -> Int
    {
        return arrMultiArriCode.count
    }
    func tableView(_ tableView: UITableView,
                   cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath as IndexPath) as UITableViewCell
        
        //    let title = cell.viewWithTag(1) as! UILabel
        let departCode = cell.viewWithTag(4) as! UITextField
        let departCity = cell.viewWithTag(5) as! UILabel
        let arriCode = cell.viewWithTag(6) as! UITextField
        let arriCity = cell.viewWithTag(7) as! UILabel
        let departDate = cell.viewWithTag(8) as! UILabel
        let departDay = cell.viewWithTag(9) as! UILabel
        let departBtn = cell.viewWithTag(11) as! UIButton
        let ArriBtn = cell.viewWithTag(22) as! UIButton
        let DateBtn = cell.viewWithTag(33) as! UIButton
        
        //  title.text = arrMultiTitle[indexPath.row]
        departCode.text = arrMultiDepartCode[indexPath.row]
        departCity.text = arrMultiDepartCity[indexPath.row]
        arriCode.text = arrMultiArriCode[indexPath.row]
        arriCity.text = arrMultiArriCity[indexPath.row]
        departDate.text = arrMultiDate[indexPath.row]
        departDay.text = arrMultiDay[indexPath.row]
        
        departBtn.addTarget(self, action: #selector(departBtnClicked(sender:)), for: .touchUpInside)
        ArriBtn.addTarget(self, action:#selector(arriBtnClicked(sender:)), for: .touchUpInside)
        DateBtn.addTarget(self, action:#selector(dateBtnClicked(sender:)), for: .touchUpInside)
        //  departBtn.tag = indexPath.row
        return cell
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 110.0
    }
}
extension Date
{
    func toString( dateFormat format  : String ) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        return dateFormatter.string(from: self)
    }
    
}
