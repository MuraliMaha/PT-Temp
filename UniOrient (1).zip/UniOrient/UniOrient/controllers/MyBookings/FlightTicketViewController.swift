//
//  FlightTicketViewController.swift
//  UniOrient
//
//  Created by Pranas on 27/05/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit
import SDWebImage
class FlightTicketViewController: UIViewController {

    
    //--------New Controls
    
    @IBOutlet weak var lblPNRNo: UILabel!
    
    @IBOutlet weak var lblFlightImg: UIImageView!
    @IBOutlet weak var lblFlightName: UILabel!
    
    @IBOutlet weak var lblDepartCode: UILabel!
    
    @IBOutlet weak var lblBookingDate: UILabel!
    @IBOutlet weak var lblCabonClass: UILabel!
    @IBOutlet weak var lblFlightNo: UILabel!
    @IBOutlet weak var lblArrivalCity: UILabel!
    @IBOutlet weak var lblArrivalCode: UILabel!
    @IBOutlet weak var lblDepartCity: UILabel!
    
    //--------
    @IBOutlet weak var activityIndView: UIActivityIndicatorView!
    @IBOutlet weak var loadingView: UIView!
    @IBOutlet weak var flightDetailsTableView: UITableView!
    @IBOutlet var bottomView: UIView!
    @IBOutlet var transactionView: UIView!
    
    @IBOutlet weak var lblPassName: UILabel!
    @IBOutlet weak var lblTransId: UILabel!
    

    
    @IBOutlet weak var lblContactName: UILabel!
    @IBOutlet weak var lblContactEmail: UILabel!
    @IBOutlet weak var lblContactMobile: UILabel!
    @IBOutlet weak var passengerTableview: UITableView!
    
    @IBOutlet weak var lblTotalFare: UILabel!
    @IBOutlet weak var lblOtherCharge: UILabel!
    @IBOutlet weak var lblTaxFare: UILabel!
    @IBOutlet weak var lblBaseFare: UILabel!
    var TripId : String!
    var PNRNo : String!
    
    var inputDict = [String:String]()
    var myTempArr : [[String:AnyObject]]!
     var myTempArr1 : [[String:AnyObject]]!
     var myTempArr2 : [[String:AnyObject]]!
     var myTempArr3 : [[String:AnyObject]]!
     var myTempArr4 : [[String:AnyObject]]!
    var myTicketArr = [MyFlightTicketsStruct]()
    var myPaasengerArr = [MyFlightTicketsPassengerStruct]()
    var myContactArr = [MyFlightTicketsContactStruct]()
    var myFareDetailsArr = [MyFlightTicketsFareDetailsStruct]()
    
    var loginDetail : LoginDetails!
    var loginResponse : LoginResponse!
    var arrName : [String:String] = [String:String]()
    var arrGender : [String:String] = [String:String]()
    var arrAge : [String:String] = [String:String]()
    var Table1 : [String:AnyObject]!
    var Waytype : [String]!
    var AirlineName : [String]!
    var cabinclass : [String]!
    var DepartTime : [String]!
    var ArrivesTime : [String]!
    var Duration : [String]!
    var Stop : [String]!
    var DepartDate : [String]!
    var FromAirportCode : [String]!
    var ToAirportCode : [String]!
    var Logo : [String]!
    var mobileNo : String!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.flightDetailsTableView .tableHeaderView = self.transactionView
        self.flightDetailsTableView.tableFooterView = self.bottomView
        
        if let LoginDetal = FetchLoginDetails() {
            loginResponse = FetchLoginResponse()
            self.mobileNo = loginResponse.PhoneNo
        }
        
        callMyBookingsService()
    }
    

    func callMyBookingsService(){
        if (Reachability()?.isReachable)! {
         //   showLoading()
         self.loadingView.isHidden = false
            self.activityIndView.startAnimating()
            inputDict = ["TripID":self.TripId,
                         "PNRNO":"",
                         "Mobileno":self.mobileNo,
                         "RequestType":"JSON"]
            
            print("InputDict = ",inputDict)
            
            WebService().HTTP_POST_WebServiceMethod_Flight(mainURL: WebServicesUrl.MyTicketsURL, suffix: "GetBookingList", parameterDict: inputDict) { (ResponseDict, ResponseStatus) in
                
                self.loadingView.isHidden = true
                self.activityIndView.stopAnimating()
                if ResponseStatus {
                    print("Service call success ..........")
                    
                    let responce = ResponseDict as! [String:AnyObject]
                  
                    print("Ticket Response",responce)
                    
                    self.myTempArr = responce["Table1"] as? [[String : AnyObject]]
                     self.myTempArr1 = responce["Table4"] as? [[String : AnyObject]]
                     self.myTempArr2 = responce["Table5"] as? [[String : AnyObject]]
                     self.myTempArr3 = responce["Table"] as? [[String : AnyObject]]
                    self.myTempArr4 = responce["Table2"] as? [[String : AnyObject]]
                    for aResultDict in self.myTempArr{
                        var aResultAndDetailStruct = MyFlightTicketsStruct()
                       aResultAndDetailStruct.Waytype = "\(aResultDict["cabinclass"]!)"
                        aResultAndDetailStruct.AirlineName = "\(aResultDict["AirlineName"]!)"
                        aResultAndDetailStruct.cabinclass = "\(aResultDict["cabinclass"]!)"
                        aResultAndDetailStruct.DepartTime = "\(aResultDict["DepartDate"]!)"
                        aResultAndDetailStruct.ArrivesTime = "\(aResultDict["ArrivesDate"]!)"
                        aResultAndDetailStruct.Duration = "\(aResultDict["Duration"]!)"
                        aResultAndDetailStruct.Stop = "\(aResultDict["Stop"]!)"
                        aResultAndDetailStruct.DepartDate = "\(aResultDict["Waytype"]!)"
                        aResultAndDetailStruct.FromAirportCode = "\(aResultDict["FromAirportName"]!)"
                        aResultAndDetailStruct.ToAirportCode = "\(aResultDict["ToAirportName"]!)"
                        aResultAndDetailStruct.Logo = "\(aResultDict["Logo"]!)"
                      aResultAndDetailStruct.FlightNo = "\(aResultDict["FlightNo"]!)"
                        aResultAndDetailStruct.FromCode = "\(aResultDict["FromAirportCode"]!)"
                        aResultAndDetailStruct.ToCode = "\(aResultDict["ToAirportCode"]!)"
                     print(aResultAndDetailStruct)
                    self.myTicketArr.append(aResultAndDetailStruct)
                        self.flightDetailsTableView .reloadData()
     //----------
                self.lblDepartCode.text = self.myTicketArr[0].FromCode
                self.lblArrivalCode.text = self.myTicketArr.last!.ToCode
                self.lblDepartCity.text = self.myTicketArr[0].FromAirportCode
                self.lblArrivalCity.text = self.myTicketArr[0].ToAirportCode
                self.lblFlightNo.text = self.myTicketArr[0].FlightNo
                self.lblCabonClass.text = self.myTicketArr[0].cabinclass
                self.lblBookingDate.text = self.myTicketArr[0].DepartTime
                        
                self.lblFlightName . text = self.myTicketArr[0].AirlineName + " ( " + self.myTicketArr[0].FromAirportCode + " ) "
                     
                        let imgArr = self.myTicketArr [0].Logo
                        var imgarr = imgArr?.components(separatedBy: "/")
                        
                        let flightImgURL = WebServicesUrl.FlightImgURL + (imgarr?[2])!
                        self.lblFlightImg.sd_setImage(with: URL(string: flightImgURL), placeholderImage: UIImage(named: "placeholder.png"),options: SDWebImageOptions(rawValue: 0), completed: { downloadedImage, error, cacheType, imageURL in
                            if error == nil{
                                print("Image downloaded without error......")
                            }else{
                                print("Error from SBWebImage Block = ",error!)
                            }
                        })
                    
                    }
                    for aResultDict in self.myTempArr1{
                        var aResultAndDetailStruct = MyFlightTicketsPassengerStruct()
                
                        aResultAndDetailStruct.FirstName = "\(aResultDict["FirstName"]!)"
                        aResultAndDetailStruct.LastName = "\(aResultDict["LastName"]!)"
                        aResultAndDetailStruct.PassportNo = "\(aResultDict["PassportNo"]!)"
                        aResultAndDetailStruct.Title = "\(aResultDict["Title"]!)"
                        aResultAndDetailStruct.TicketNo = "\(aResultDict["TicketNo"]!)"
                    self.myPaasengerArr.append(aResultAndDetailStruct)
                    self.passengerTableview .reloadData()
                        
                    }
                    for aResultDict in self.myTempArr2{
                        var aResultAndDetailStruct = MyFlightTicketsContactStruct()
                        
                        aResultAndDetailStruct.ContactName = "\(aResultDict["ContactName"]!)"
                        aResultAndDetailStruct.Email = "\(aResultDict["Email"]!)"
                        aResultAndDetailStruct.Mobile = "\(aResultDict["Mobile"]!)"
                   self.myContactArr.append(aResultAndDetailStruct)
                        
//                        self.lblContactName.text = self.myContactArr[0].ContactName
//                         self.lblContactEmail.text = self.myContactArr[0].Email
//                         self.lblContactMobile.text = self.myContactArr[0].Mobile
                    }
                  
                    for aResultDict in self.myTempArr3{
                        var aResultAndDetailStruct = MyFlightTicketsContactStruct()
                       self.myContactArr .removeAll()
                        aResultAndDetailStruct.FirstName = "\(aResultDict["FirstName"]!)"
                        aResultAndDetailStruct.LastName = "\(aResultDict["LastName"]!)"
                        aResultAndDetailStruct.TripId = "\(aResultDict["TripId"]!)"
                        aResultAndDetailStruct.BookingDate = "\(aResultDict["TransactionDate"]!)"
                         aResultAndDetailStruct.PNRNo = "\(aResultDict["PNRNo"]!)"
                    self.myContactArr.append(aResultAndDetailStruct)
                  
                        self.lblPNRNo . text =  "PNR No - " + self.myContactArr[0].PNRNo
                        self.lblTransId.text = self.myContactArr[0].TripId
                        self.lblPassName.text = self.myContactArr[0].FirstName + " " + self.myContactArr[0].LastName
                        self.lblBookingDate.text = self.myContactArr[0].BookingDate
                        // self.lblPNRNo.text = self.myContactArr[0].PNRNo
                    }
                    for aResultDict in self.myTempArr4{
                        var aResultAndDetailStruct = MyFlightTicketsFareDetailsStruct()
                        
                        aResultAndDetailStruct.BaseFare = "\(aResultDict["BaseFare"]!)"
                        aResultAndDetailStruct.TaxAmt = "\(aResultDict["TaxAmt"]!)"
                        aResultAndDetailStruct.ServiceFee = "\(aResultDict["ServiceFee"]!)"
                        aResultAndDetailStruct.TotalAmount = "\(aResultDict["TotalAmount"]!)"
                  self.myFareDetailsArr.append(aResultAndDetailStruct)
                        
                        self.lblBaseFare.text = "PHP " + self.myFareDetailsArr[0].BaseFare
                        self.lblTaxFare.text = "PHP " + self.myFareDetailsArr[0].TaxAmt
                        self.lblOtherCharge.text = "PHP " + self.myFareDetailsArr[0].ServiceFee
                        self.lblTotalFare.text = "PHP " + self.myFareDetailsArr[0].TotalAmount
                    }
                    print(self.myTicketArr)
                }else{
                    print("Service call failure ..........")
                    print("Try after sometimes.......")
                    self.view.ShowBlackTostWithText(message: "Try after sometimes...Server Problem....", Interval: 2)
                }
                
            }
        }else{
            print("No Internet......")
        }
    }
    
    @IBAction func backBtnTapped(_ sender: Any)
    {
        self.navigationController?.popViewController(animated:true)
    }
    
    
    @IBAction func pdfBtnTapped(_ sender: Any)
    {
        pdfDataWithTableView (tableView: self.flightDetailsTableView)
    }
    func pdfDataWithTableView(tableView: UITableView) {
        let priorBounds = tableView.bounds
        let fittedSize = tableView.sizeThatFits(CGSize(width:priorBounds.size.width, height:tableView.contentSize.height))
        tableView.bounds = CGRect(x:0, y:0, width:fittedSize.width, height:fittedSize.height)
        let pdfPageBounds = CGRect(x:0, y:0, width:tableView.frame.width, height:self.view.frame.height)
        let pdfData = NSMutableData()
        UIGraphicsBeginPDFContextToData(pdfData, pdfPageBounds,nil)
        var pageOriginY: CGFloat = 0
        while pageOriginY < fittedSize.height {
            UIGraphicsBeginPDFPageWithInfo(pdfPageBounds, nil)
            UIGraphicsGetCurrentContext()!.saveGState()
            UIGraphicsGetCurrentContext()!.translateBy(x: 0, y: -pageOriginY)
            tableView.layer.render(in: UIGraphicsGetCurrentContext()!)
            UIGraphicsGetCurrentContext()!.restoreGState()
            pageOriginY += pdfPageBounds.size.height
        }
        UIGraphicsEndPDFContext()
        tableView.bounds = priorBounds
     
        if let documentDirectories = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first {
            let documentsFileName = documentDirectories + "/" + "TestPDF-Flight"
            debugPrint(documentsFileName)
            pdfData.write(toFile: documentsFileName, atomically: true)
            let activityViewController = UIActivityViewController(activityItems: ["Flight Tickets", pdfData], applicationActivities: nil)
            present(activityViewController, animated: true, completion: nil)
            print("saved successfully")
        }
    }
}

extension FlightTicketViewController : UITableViewDelegate, UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == self.passengerTableview
        {
            return self.myPaasengerArr.count
        }
        else
        {
            return self.myTicketArr.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == self.passengerTableview
        {
            let result = tableView.dequeueReusableCell(withIdentifier: "cell") as! UITableViewCell
            let label = result.viewWithTag(1) as! UILabel
            let label1 = result.viewWithTag(3) as! UILabel
            let label2 = result.viewWithTag(4) as! UILabel
            label.text =  self.myPaasengerArr[indexPath.row].FirstName + self.myPaasengerArr[indexPath.row].LastName
            label1.text = self.myPaasengerArr[indexPath.row].Title
            label2.text = self.myPaasengerArr[indexPath.row].TicketNo
            return result
        }
        else
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "FlightTicketCellClass", for: indexPath) as! FlightTicketCellClass
      
            cell.flightNameLbl.text = self.myTicketArr[indexPath.row].AirlineName
            cell.flightRefundableType .text = self.myTicketArr[indexPath.row].Waytype
            cell.depAirportCodeLbl .text = self.myTicketArr[indexPath.row].FromAirportCode
            cell.arrivalAirportCodeLbl .text = self.myTicketArr[indexPath.row].ToAirportCode
            cell.durationLbl .text = self.myTicketArr[indexPath.row].Duration
            cell.departureDateLbl .text = self.myTicketArr[indexPath.row].DepartTime
            cell.arrivalDateLbl .text = self.myTicketArr[indexPath.row].ArrivesTime
            cell.stopDetailsLbl .text = self.myTicketArr[indexPath.row].Stop + " Stop"
            cell.lblDate .setTitle(self.myTicketArr[indexPath.row].DepartDate, for: UIControl.State.normal)
            let imgArr = self.myTicketArr [indexPath.row].Logo
            var imgarr = imgArr?.components(separatedBy: "/")
            
            
            let flightImgURL = WebServicesUrl.FlightImgURL + (imgarr?[2])!
            cell.flightImgView.sd_setImage(with: URL(string: flightImgURL), placeholderImage: UIImage(named: "placeholder.png"),options: SDWebImageOptions(rawValue: 0), completed: { downloadedImage, error, cacheType, imageURL in
                if error == nil{
                    print("Image downloaded without error......")
                }else{
                    print("Error from SBWebImage Block = ",error!)
                }
            })
            return cell
        }
       return UITableViewCell()
}
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        if tableView == self.passengerTableview
        {
             return 40.0
        }
        else{
             return 120.0
        }
       
    }
}
class FlightTicketMainCellClass : UITableViewCell
{
    @IBOutlet weak var flightNameLbl: UILabel!
    @IBOutlet weak var depAirportCodeLbl: UILabel!
    @IBOutlet weak var stopDetailsLbl: UILabel!
    @IBOutlet weak var departureDateLbl: UILabel!
}

class FlightTicketCellClass : UITableViewCell{
    @IBOutlet weak var flightImgView: UIImageView!
    @IBOutlet weak var flightRefundableType: UILabel!
    @IBOutlet weak var flightNameLbl: UILabel!
    @IBOutlet weak var depTimeLbl: UILabel!
    @IBOutlet weak var depAirportCodeLbl: UILabel!
    @IBOutlet weak var durationLbl: UILabel!
    @IBOutlet weak var stopDetailsLbl: UILabel!
    @IBOutlet weak var arrivalTimeLbl: UILabel!
    @IBOutlet weak var arrivalAirportCodeLbl: UILabel!
    @IBOutlet weak var refundOrNonRefundLbl: UILabel!
    @IBOutlet weak var departureDateLbl: UILabel!
    @IBOutlet weak var arrivalDateLbl: UILabel!
    @IBOutlet weak var lblDate: UIButton!
}
