//
//  HotelTicketViewController.swift
//  UniOrient
//
//  Created by Pranas on 29/05/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

class HotelTicketViewController: UIViewController {
    
    @IBOutlet weak var loadingView: UIView!
    
    @IBOutlet weak var ratingView: EDStarRating!
    @IBOutlet weak var activityIndView: UIActivityIndicatorView!
    var TripId : String!
    var PNRNo : String!
   var inputDict = [String:String]()
    var myTempArr : [[String:AnyObject]]!
    var myTempArr1 : [[String:AnyObject]]!
    var myTempArr2 : [[String:AnyObject]]!
    var myTempArr3 : [[String:AnyObject]]!
    var myTempArr4 : [[String:AnyObject]]!
    var myTicketArr = [MyHotelTicketsStruct]()
    var myPaasengerArr = [MyHotelTicketsPassengerStruct]()
    var myContactArr = [MyHotelTicketsContactStruct]()
    var myFareDetailsArr = [MyFlightTicketsFareDetailsStruct]()
    var loginDetail : LoginDetails!
    var loginResponse : LoginResponse!
     var mobileNo : String!
    @IBOutlet weak var lblHotelName: UILabel!
    
    @IBOutlet weak var guestTableView: UITableView!
    @IBOutlet var headerView: UIView!
    @IBOutlet var footerView: UIView!
    @IBOutlet weak var lblTotalAmount: UILabel!
    @IBOutlet weak var lblHDiscount: UILabel!
    @IBOutlet weak var lblHOtherAmount: UILabel!
    @IBOutlet weak var lblHTaxAmount: UILabel!
    @IBOutlet weak var lblHBaseFare: UILabel!
    @IBOutlet weak var lblHContactMobileNo: UILabel!
    @IBOutlet weak var lblHContactEmail: UILabel!
    @IBOutlet weak var lblHCOntactName: UILabel!
    @IBOutlet weak var lblRoomCount: UILabel!
    @IBOutlet weak var lbloomType: UILabel!
    @IBOutlet weak var lblNoOfPass: UILabel!
    @IBOutlet weak var lblHotelpNRNo: UILabel!
    @IBOutlet weak var lblHotelTripId: UILabel!
    @IBOutlet weak var lblNoOfNights: UILabel!
    @IBOutlet weak var lblCheckout: UILabel!
    @IBOutlet weak var lblCheckIn: UILabel!
    @IBOutlet weak var lblHotelAddress: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

       self.guestTableView .tableHeaderView = self.headerView
        self.guestTableView.tableFooterView = self.footerView
        if let LoginDetal = FetchLoginDetails() {
            loginResponse = FetchLoginResponse()
            self.mobileNo = loginResponse.PhoneNo
        }
        callMyTicketService ()
        
    }
 
    @IBAction func backBtnTapped(_ sender: UIButton)
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    func callMyTicketService(){
        if (Reachability()?.isReachable)! {
            self.loadingView.isHidden = false
            self.activityIndView.startAnimating()
            
            inputDict = ["TripID":self.TripId,
                         "PNRNO":"",
                         "Mobileno":self.mobileNo,
                         "RequestType":"JSON"]
            
            print("InputDict = ",inputDict)
            
            WebService().HTTP_POST_WebServiceMethod_Flight(mainURL: WebServicesUrl.MyTicketsURL, suffix: "GetBookingList", parameterDict: inputDict) { (ResponseDict, ResponseStatus) in
                
                self.loadingView.isHidden = true
                self.activityIndView.stopAnimating()
                if ResponseStatus {
                    print("Service call success ..........")
                    
                    let responce = ResponseDict as! [String:AnyObject]
                    print(responce)
                    self.myTempArr = responce["Table1"] as? [[String : AnyObject]]
                    self.myTempArr1 = responce["Table4"] as? [[String : AnyObject]]
                    self.myTempArr2 = responce["Table5"] as? [[String : AnyObject]]
                    self.myTempArr3 = responce["Table"] as? [[String : AnyObject]]
                    self.myTempArr4 = responce["Table2"] as? [[String : AnyObject]]
                    
                    for aResultDict in self.myTempArr4{
                        var aResultAndDetailStruct = MyHotelTicketsPassengerStruct()
                        
                        aResultAndDetailStruct.FirstName = "\(aResultDict["FirstName"]!)"
                        aResultAndDetailStruct.LastName = "\(aResultDict["LastName"]!)"
                        aResultAndDetailStruct.TravType = "\(aResultDict["TravType"]!)"
                          aResultAndDetailStruct.roomno = "\(aResultDict["roomno"]!)"
                        self.myPaasengerArr.append(aResultAndDetailStruct)
                        self.guestTableView .reloadData()
                        
                    }
                    for aResultDict in self.myTempArr1{
                        var aResultAndDetailStruct = MyHotelTicketsContactStruct()
                        
                        aResultAndDetailStruct.ContactName = "\(aResultDict["ContactName"]!)"
                        aResultAndDetailStruct.Email = "\(aResultDict["Email"]!)"
                        aResultAndDetailStruct.Mobile = "\(aResultDict["Mobile"]!)"
                    self.myContactArr.append(aResultAndDetailStruct)
                        
//                        self.lblHCOntactName.text = self.myContactArr[0].ContactName
//                        self.lblHContactEmail.text = self.myContactArr[0].Email
//                        self.lblHContactMobileNo.text = self.myContactArr[0].Mobile
                    }
                    
                    
                    for aResultDict in self.myTempArr
                    {
                        var aResultAndDetailStruct = MyHotelTicketsStruct()
                        aResultAndDetailStruct.HotelName = "\(aResultDict["HotelName"]!)"
                        aResultAndDetailStruct.HotelAddress = "\(aResultDict["HotelAddress"]!)"
                        aResultAndDetailStruct.Rating = "\(aResultDict["Rating"]!)"
                        aResultAndDetailStruct.ArrivesDate = "\(aResultDict["ArrivesDate"]!)"
                        aResultAndDetailStruct.DepartDate = "\(aResultDict["DepartDate"]!)"
                        aResultAndDetailStruct.TripID = "\(aResultDict["TripID"]!)"
                        aResultAndDetailStruct.PNRNo = "\(aResultDict["PNRNo"]!)"
                        aResultAndDetailStruct.NoofAdult = "\(aResultDict["NoofAdult"]!)"
                        
                        aResultAndDetailStruct.RoomName = "\(aResultDict["RoomName"]!)"
                        aResultAndDetailStruct.RoomNo = "\(aResultDict["RoomNo"]!)"
                        aResultAndDetailStruct.BaseFare = "\(aResultDict["BaseFare"]!)"
                        aResultAndDetailStruct.TaxAmt = "\(aResultDict["TaxAmt"]!)"
                        aResultAndDetailStruct.ServiceFee = "\(aResultDict["Markup"]!)"
                        aResultAndDetailStruct.Discount = "\(aResultDict["Discount"]!)"
                        aResultAndDetailStruct.totalamt = "\(aResultDict["totalamt"]!)"
                    
                    self.myTicketArr.append(aResultAndDetailStruct)
  //--------- Star Rating ---------------//
                       self.ratingView.starHighlightedImage = UIImage.init(named: "starFilled")
                       self.ratingView.maxRating = 5
                       self.ratingView.horizontalMargin = 2
                      self.ratingView.displayMode = UInt(EDStarRatingDisplayFull)
                        let ratingStr = self.myTicketArr[0].Rating!
                        
                        if !ratingStr.isEmpty{
                            self.ratingView.rating = Float(self.myTicketArr[0].Rating!)!
                        }
 //---------ENd Star Rating ---------------//
                        self.lblHotelName.text = self.myTicketArr[0].HotelName
                        self.lblHotelAddress.text = self.myTicketArr[0].HotelAddress
                        self.lblCheckIn.text = self.myTicketArr[0].DepartDate
                        self.lblCheckout.text = self.myTicketArr[0].ArrivesDate
  //--------- No of Nights Calculation ---------------//
                        
                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "dd/mm/yyyy"
                        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
                        let firstDate = dateFormatter.date(from:self.lblCheckIn.text!)!
                        let secondDate = dateFormatter.date(from:self.lblCheckout.text!)!
                       let calendar = Calendar.current
                        let date1 = calendar.startOfDay(for: firstDate)
                        let date2 = calendar.startOfDay(for: secondDate)
                        let components = calendar.dateComponents([.day], from: date1, to: date2)
                        
                        self.lblNoOfNights.text = "\(components.day!)"
                        
//---------End No of Nights Calculation ---------------//
                        
                        self.lblHotelTripId.text = self.myTicketArr[0].TripID
                        self.lblHotelpNRNo.text = self.myTicketArr[0].PNRNo
                        self.lblNoOfPass.text = self.myTicketArr[0].NoofAdult
                        self.lbloomType.text = self.myTicketArr[0].RoomName
                        self.lblRoomCount.text = self.myTicketArr[0].RoomNo
                        
                        self.lblHBaseFare.text = "PHP " +  self.myTicketArr[0].BaseFare
                        self.lblHTaxAmount.text = "PHP " +  self.myTicketArr[0].TaxAmt
                        self.lblHOtherAmount.text = "PHP " + self.myTicketArr[0].ServiceFee
                        self.lblHDiscount.text = "- PHP " + self.myTicketArr[0].Discount
                        self.lblTotalAmount.text = "PHP " + self.myTicketArr[0].totalamt
                }
            }
        }
    }
    }
    
    @IBAction func pdfBtnTapped(_ sender: UIButton)
    {
        pdfDataWithTableView (tableView: self.guestTableView)
    }
    func pdfDataWithTableView(tableView: UITableView) {
        let priorBounds = tableView.bounds
        let fittedSize = tableView.sizeThatFits(CGSize(width:priorBounds.size.width, height:tableView.contentSize.height))
        tableView.bounds = CGRect(x:0, y:0, width:fittedSize.width, height:fittedSize.height)
        let pdfPageBounds = CGRect(x:0, y:0, width:tableView.frame.width, height:self.view.frame.height)
        let pdfData = NSMutableData()
        UIGraphicsBeginPDFContextToData(pdfData, pdfPageBounds,nil)
        var pageOriginY: CGFloat = 0
        while pageOriginY < fittedSize.height {
            UIGraphicsBeginPDFPageWithInfo(pdfPageBounds, nil)
            UIGraphicsGetCurrentContext()!.saveGState()
            UIGraphicsGetCurrentContext()!.translateBy(x: 0, y: -pageOriginY)
            tableView.layer.render(in: UIGraphicsGetCurrentContext()!)
            UIGraphicsGetCurrentContext()!.restoreGState()
            pageOriginY += pdfPageBounds.size.height
        }
        UIGraphicsEndPDFContext()
        tableView.bounds = priorBounds
        
        if let documentDirectories = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first {
            let documentsFileName = documentDirectories + "/" + "TestPDF-Hotel"
            debugPrint(documentsFileName)
            pdfData.write(toFile: documentsFileName, atomically: true)
            let activityViewController = UIActivityViewController(activityItems: ["Hotel Tickets", pdfData], applicationActivities: nil)
            present(activityViewController, animated: true, completion: nil)
            print("saved successfully")
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
}
extension HotelTicketViewController : UITableViewDelegate, UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    
        return self.myPaasengerArr.count
    
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
   
            let result = tableView.dequeueReusableCell(withIdentifier: "cell") as! UITableViewCell
            let label = result.viewWithTag(2) as! UILabel
            let label1 = result.viewWithTag(3) as! UILabel
            let label2 = result.viewWithTag(4) as! UILabel
            label.text =  self.myPaasengerArr[indexPath.row].FirstName + " " + self.myPaasengerArr[indexPath.row].LastName
            label1.text = self.myPaasengerArr[indexPath.row].TravType
            label2.text = "Room " + self.myPaasengerArr[indexPath.row].roomno
            return result
}
}
