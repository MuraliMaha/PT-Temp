//
//  MyBookingListVC.swift
//  UniOrient
//
//  Created by APPLE on 17/06/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

class MyBookingListVC: UIViewController {

    @IBOutlet weak var noTripsView: UIView!
    @IBOutlet weak var backBtn: UIButton!
    @IBOutlet weak var segmentViewController: UISegmentedControl!
    
    var myTripsArr = [[String:AnyObject]]()
    var upcomingTripsArr = [MyTripsStruct]()
    var completedTripsArr = [MyTripsStruct]()
//    var tempArr : [MyTripsStruct]!
    var tempArr1 : [MyTripsStruct]!
    
    @IBOutlet weak var TVContainerView: UIView!
    @IBOutlet weak var tripsTV: UITableView!
    
    var strBackBtnDisplay : String = String()
    var loginDetail : LoginDetails!
    var loginResponse : LoginResponse!
    var dateFormatter = DateFormatter()
    var currentDateStr : String!
    var tripMode : String = "CurrentTrips" //CurrentTrips means Upcoming Trips
    var bookingType = "1" //2 means UpcomingTrips ,1 means past trips
    var inputDict = [String:String]()
    var isUpcomingSelected : Bool!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if self.strBackBtnDisplay == "myProfile"
        {
            self.backBtn.isHidden = false
        }
        else{
            self.backBtn.isHidden = true
        }
        
        self.tripsTV.dataSource = self
        self.tripsTV.delegate = self
        
        dateFormatter.dateFormat = "dd-MM-yyyy"
        self.currentDateStr = dateFormatter.string(from: Date())
        print("Current Date Str =",self.currentDateStr)
        loginDetail = FetchLoginDetails()
        loginResponse = FetchLoginResponse()
        
        isUpcomingSelected  = true
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
      let userSK = UserDefaults.standard.value(forKey: "userSK")
        if userSK == nil
        {
            self.TVContainerView.isHidden = true
//            self.loadingView.isHidden = true
//            self.activityIndView.stopAnimating()
           
        }
        else{
            callMyBookingsService()
        }
        navigationController?.setNavigationBarHidden(true, animated: false)
    }

    @IBAction func backBtnTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func segmentControlAction(_ sender: Any)
    {
        let userSK = UserDefaults.standard.value(forKey: "userSK")
        switch segmentViewController.selectedSegmentIndex
        {
        case 0:
            // self.completedTableView .reloadData()
            //            self.completedView.isHidden = true
            //            self.upcomingView.isHidden = false
            isUpcomingSelected  = true
            self.tripMode = "CurrentTrips"
            self.bookingType = "1"
            if userSK != nil
            {
                callMyBookingsService()
            }
            
        case 1:
          
            //             self.tripsTV .reloadData()
            //            self.completedView.isHidden = false
            //            self.upcomingView.isHidden = true
            isUpcomingSelected  = false
            self.tripMode = "PastTrips"
            self.bookingType = "1"
            if userSK != nil
            {
                callMyBookingsService()
            }
            
        default:
            break
        }
    }
    
    func callMyBookingsService(){
        if (Reachability()?.isReachable)! {
//            self.loadingView.isHidden = false
//            self.activityIndView.startAnimating()
            inputDict = ["API_SK":"", "Module":"", "PNRO":"",
                         "Mode":self.tripMode,//"CurrentTrips",
                "Fromdate":self.currentDateStr,
                "ToDate":"",
                "User_Sk":"\(UserDefaults.standard.value(forKey: "userSK")!)",//self.loginResponse.UserSK,,
                "BookingType":self.bookingType,
                "RequestType":"JSON"]
            
            print("InputDict = ",inputDict)
            
            showLoading()
            WebService().HTTP_POST_WebServiceMethod_Flight(mainURL: WebServicesUrl.MyBookingURL, suffix: WebServicesUrl.MyTrips, parameterDict: inputDict) { (ResponseDict, ResponseStatus) in
                
                hideLoading()
                
                if ResponseStatus {
//                    self.loadingView.isHidden = true
//                    self.activityIndView.stopAnimating()
//                    print("CurrentTRips Service call success ..........")
//                    self.upcomingView.isHidden = false
                    
                    let responce = ResponseDict as! [String:AnyObject]
                    self.myTripsArr = responce["Table"] as! [[String:AnyObject]]
                    print("My Trips =",self.myTripsArr)
                    
                    if self.isUpcomingSelected! {
                        self.upcomingTripsArr.removeAll()
                    }else{
                        self.completedTripsArr.removeAll()
                    }
                    
                    for aResultDict in self.myTripsArr{
                        var aResultAndDetailStruct = MyTripsStruct()
                        aResultAndDetailStruct.Rownumber = "\(aResultDict["Rownumber"]!)"
                        aResultAndDetailStruct.Booking_sk = "\(aResultDict["Booking_sk"]!)"
                        aResultAndDetailStruct.BookingNo = "\(aResultDict["BookingNo"]!)"
                        aResultAndDetailStruct.Booking_Date = "\(aResultDict["Booking_Date"]!)"
                        aResultAndDetailStruct.Arrival = "\(aResultDict["Arrival"]!)"
                        aResultAndDetailStruct.Departure = "\(aResultDict["Departure"]!)"
                        aResultAndDetailStruct.PNRNo = "\(aResultDict["PNRNo"]!)"
                        aResultAndDetailStruct.Module_sk = "\(aResultDict["Module_sk"]!)"
                        aResultAndDetailStruct.TotalAmt = "\(aResultDict["TotalAmt"]!)"
                        aResultAndDetailStruct.BookingStatus = "\(aResultDict["ProviderName"]!)"
                        aResultAndDetailStruct.ProviderName = "\(aResultDict["BookingStatus"]!)"
                        aResultAndDetailStruct.Module = "\(aResultDict["Module"]!)"
                        aResultAndDetailStruct.From_AirportCode = "\(aResultDict["From_AirportCode"]!)"
                        aResultAndDetailStruct.To_AirportCode = "\(aResultDict["To_AirportCode"]!)"
                        aResultAndDetailStruct.AirlineNo = "\(aResultDict["AirlineNo"]!)"
                        aResultAndDetailStruct.HotelName = "\(aResultDict["HotelName"]!)"
                        aResultAndDetailStruct.DepartsDate = "\(aResultDict["DepartsDate"]!)"
                        aResultAndDetailStruct.ArrivesDate = "\(aResultDict["ArrivesDate"]!)"
                        
//                        aResultAndDetailStruct.HotelCity = "\(aResultDict["Arrival"]!)"
                        
                        if self.isUpcomingSelected! {
                            self.upcomingTripsArr.append(aResultAndDetailStruct)
                        }else{
                            self.completedTripsArr.append(aResultAndDetailStruct)
                        }
                    }
//                    self.noTripsView.isHidden = true
                    self.TVContainerView.isHidden = false
//                    self.tripsTV.isHidden = false
                    self.tripsTV.reloadData()
                    
                }else{
//                    self.noTripsView.isHidden = false
                    print("Service call failure ..........")
                    print("Try after sometimes.......")
                    //  self.view.ShowBlackTostWithText(message: "Try after sometimes...Server Problem....", Interval: 2)
                    
                    self.TVContainerView.isHidden = true
                    
                }
                
            }
        }else{
            print("No Internet......")
            self.TVContainerView.isHidden = true
        }
    }
}
extension  MyBookingListVC : UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 115.0
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if self.isUpcomingSelected! {
            return self.upcomingTripsArr.count
        }else{
            return self.completedTripsArr.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TripCellClass
        
        if self.isUpcomingSelected! {
            tempArr1 = self.upcomingTripsArr
        }else{
            tempArr1 = self.completedTripsArr
        }
        
        if self.tempArr1[indexPath.row].Module == "Flights"
        {
            /*
            cell.flightView.isHidden = false
            cell.hotelView.isHidden = true */
            cell.flightView.isHidden = true
            cell.hotelView.isHidden = true
            cell.newflightView.isHidden = false
            cell.newhotelView.isHidden = true
            
            
            
            /*
            //                cell.fModule.text = self.tempArr1[indexPath.row].Module
            //  cell.fTransId .text = self.tempArr1[indexPath.row].BookingNo
            let arrDate = self.tempArr1[indexPath.row].Booking_Date .components(separatedBy: "T")
            cell.fTransDate .text = arrDate[0]// + " " + arrDate[1] //
            
            //  cell.fTransDate .text = self.tempArr1[indexPath.row].Booking_Date
            cell.fDepartureCity .text = self.tempArr1[indexPath.row].Departure
            cell.fArrivalCity .text = self.tempArr1[indexPath.row].Arrival
            cell.fPNRNo .text = self.tempArr1[indexPath.row].PNRNo
            //   cell.fTotalAmount .text = self.tempArr1[indexPath.row].TotalAmt */
            
            
            let abc = self.tempArr1[indexPath.row].From_AirportCode.components(separatedBy: "~")
            cell.fDepartureCityCode.text = abc[1]
            cell.fSourceAirport.text = abc[0]
            cell.fDepartureCity.text = self.tempArr1[indexPath.row].Departure
            let dDate = self.tempArr1[indexPath.row].DepartsDate.components(separatedBy: "T")
            cell.fDepartsDate.text = dDate[0]
            
            let xyz = self.tempArr1[indexPath.row].To_AirportCode.components(separatedBy: "~")
            cell.fArrivalCityCode.text = xyz[1]
            cell.fDestinationAirport.text = xyz[0]
            cell.fArrivalCity.text = self.tempArr1[indexPath.row].Arrival
            let aDate = self.tempArr1[indexPath.row].ArrivesDate.components(separatedBy: "T")
            cell.fArrivalDate.text = aDate[0]
            
            cell.airlineNo.text = self.tempArr1[indexPath.row].AirlineNo
            cell.fBookingNo.text = "Booking ID : " + self.tempArr1[indexPath.row].BookingNo
            
            
            //newFlightView
            let newabc = self.tempArr1[indexPath.row].From_AirportCode.components(separatedBy: "~")
            let newxyz = self.tempArr1[indexPath.row].To_AirportCode.components(separatedBy: "~")
            cell.newfDepartureCityCode.text = newabc[1] + " - " + newxyz[1]
            cell.newfSourceAirport.text = newabc[0]
            
            cell.newfDepartureCity.text = self.tempArr1[indexPath.row].Departure + " - " + self.tempArr1[indexPath.row].Arrival
            
            cell.newfDepartsDate.text = dDate[0]
            cell.newairlineNo.text = self.tempArr1[indexPath.row].AirlineNo
            cell.newfBookingNo.text = "Booking ID : " + self.tempArr1[indexPath.row].BookingNo
            
            
            
        }else{
            /*
            cell.flightView.isHidden = true
            cell.hotelView.isHidden = false */
            
            cell.flightView.isHidden = true
            cell.hotelView.isHidden = true
            cell.newflightView.isHidden = true
            cell.newhotelView.isHidden = false
            
            /*
            //                cell.hModule.text = self.tempArr1[indexPath.row].Module
            //   cell.hTransId .text = self.tempArr1[indexPath.row].BookingNo
            let arrDate = self.tempArr1[indexPath.row].Booking_Date .components(separatedBy: "T")
            cell.hTransDate .text = arrDate[0]// + " " + arrDate[1] //
            
            // cell.hTransDate .text = self.tempArr1[indexPath.row].Booking_Date
            cell.hHotelCity .text = self.tempArr1[indexPath.row].Arrival //Arrival is HotelCity
            cell.hPNRNo .text = self.tempArr1[indexPath.row].PNRNo
            //  cell.hTotalAmount .text = self.tempArr1[indexPath.row].TotalAmt */
            
            
            cell.hHotelName.text = self.tempArr1[indexPath.row].HotelName
            cell.hHotelCity.text = self.tempArr1[indexPath.row].Arrival
            let abc = self.tempArr1[indexPath.row].DepartsDate.components(separatedBy: "T")
            cell.checkInDate.text = abc[0]
            
            let xyz = self.tempArr1[indexPath.row].ArrivesDate.components(separatedBy: "T")
            cell.checkInDate.text = xyz[0]
            
            cell.hBookingNo.text = "Booking ID : " + self.tempArr1[indexPath.row].BookingNo
            
            
            //newHotel
            cell.newhHotelCity.text = self.tempArr1[indexPath.row].Arrival
            cell.newhHotelName.text = self.tempArr1[indexPath.row].HotelName
            cell.newcheckInDate.text = xyz[0]
            cell.newhBookingNo.text = "Booking ID : " + self.tempArr1[indexPath.row].BookingNo
            
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        
        if self.tempArr1[indexPath.row].Module == "Flights" {
            let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "flightTicketVC") as! FlightTicketViewController
            ctrl.TripId = self.tempArr1[indexPath.row].BookingNo
            ctrl.PNRNo = self.tempArr1[indexPath.row].PNRNo
            self.navigationController?.pushViewController(ctrl, animated: true)
        }else{
            let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "hotelTicketVC") as! HotelTicketViewController
            ctrl.TripId = self.tempArr1[indexPath.row].BookingNo
            ctrl.PNRNo = self.tempArr1[indexPath.row].PNRNo
            self.navigationController?.pushViewController(ctrl, animated: true)
        }
    }
}

class TripCellClass :  UITableViewCell
{
    
    @IBOutlet weak var flightView: UIView!

    @IBOutlet weak var fDepartureCityCode: UILabel!
    @IBOutlet weak var fDepartureCity: UILabel!
    @IBOutlet weak var fSourceAirport: UILabel!
    @IBOutlet weak var fDepartsDate: UILabel!
    
    @IBOutlet weak var fArrivalCityCode: UILabel!
    @IBOutlet weak var fArrivalCity: UILabel!
    @IBOutlet weak var fDestinationAirport: UILabel!
    @IBOutlet weak var fArrivalDate: UILabel!
    
    @IBOutlet weak var fBookingNo: UILabel!
    @IBOutlet weak var airlineNo: UILabel!
    
    @IBOutlet weak var newflightView: UIView!
    @IBOutlet weak var newfDepartureCityCode: UILabel!
    @IBOutlet weak var newfDepartureCity: UILabel!
    @IBOutlet weak var newfDepartsDate: UILabel!
    @IBOutlet weak var newfSourceAirport: UILabel!
    @IBOutlet weak var newfBookingNo: UILabel!
    @IBOutlet weak var newairlineNo: UILabel!
    
    
    /*
    @IBOutlet weak var fPNRNo: UILabel!
    @IBOutlet weak var fTransDate: UILabel!
    //    @IBOutlet weak var fModule: UILabel!
    @IBOutlet weak var fTransId: UILabel!
    @IBOutlet weak var fTotalAmount: UILabel! */
   
   
    @IBOutlet weak var hotelView: UIView!
    
    @IBOutlet weak var hHotelName: UILabel!
    @IBOutlet weak var hHotelCity: UILabel!
    @IBOutlet weak var checkInDate: UILabel!
    @IBOutlet weak var checkOutDate: UILabel!
    @IBOutlet weak var hBookingNo: UILabel!
    
    @IBOutlet weak var newhotelView: UIView!
    @IBOutlet weak var newhHotelName: UILabel!
    @IBOutlet weak var newhHotelCity: UILabel!
    @IBOutlet weak var newcheckInDate: UILabel!
    @IBOutlet weak var newhBookingNo: UILabel!
}

