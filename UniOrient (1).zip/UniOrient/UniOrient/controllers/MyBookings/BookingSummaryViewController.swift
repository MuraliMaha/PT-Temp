//
//  BookingSummaryViewController.swift
//  UniOrient
//
//  Created by Pranas on 23/05/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit
import SDWebImage

class BookingSummaryViewController: UIViewController {
    @IBOutlet weak var lblPaymentStatus: UILabel!
    
    @IBOutlet weak var passTableViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet var transactionView: UIView!
    @IBOutlet var bottomView: UIView!
    @IBOutlet weak var lblEmailId: UILabel!
    @IBOutlet weak var lblMobileNo: UILabel!
    @IBOutlet weak var transactionId: UILabel!
    @IBOutlet weak var PNRNo: UILabel!
    
    @IBOutlet weak var passengerTableView: UITableView!
    @IBOutlet weak var cabbinBaggage: UILabel!
    @IBOutlet weak var checkinBaggage: UILabel!
    
    @IBOutlet weak var flightTableview: UITableView!
    @IBOutlet weak var totalAmount: UILabel!
    @IBOutlet weak var otherCharge: UILabel!
    @IBOutlet weak var convenienceFee: UILabel!
    @IBOutlet weak var taxAmount: UILabel!
    @IBOutlet weak var basefare: UILabel!
   
    var strPaymentStatus : String!
    var loginDetail : LoginDetails!
    var loginResponse : LoginResponse!
    var arrName : [String:String] = [String:String]()
    var arrGender : [String:String] = [String:String]()
    var arrAge : [String:String] = [String:String]()
    
    var selectedStruct : FlightResultAndDetailStruct!
    var providedInputDict = [String:String]()
    var detailsArr = [FlightDetailStruct]()
    var returnDetailsArr = [FlightDetailStruct]()
    var multiDetailsArr = [FlightDetailStruct]()
  
    var myArray : [FinalStruct?]?
    var myArray1 : [FinalStruct?]?
    var myArray2 : [FinalStruct?]?
 
    var PassengerArr = [TravellerDetailStruct]()
   
    override func viewDidLoad() {
        super.viewDidLoad()
        print(PassengerArr)
       self.lblPaymentStatus . text = self.strPaymentStatus
       self.flightTableview.tableFooterView = self.bottomView
        self.flightTableview.tableHeaderView = self.transactionView
        
        self.detailsArr = selectedStruct.detailArrWithFlightDetailStruct
        let detailStructFinal =  FinalStruct.init(CabinBaggage: selectedStruct.CabinBaggage, CheckInBaggage: selectedStruct.CheckInBaggage, departureDate: selectedStruct.departureDate, arrivalDate: selectedStruct.arrivalDate,flightImgName:selectedStruct.flightImgName,flightImgData:selectedStruct.flightImgData, flightName: selectedStruct.flightName, departureTime: selectedStruct.departureTime, departureAirportCode: selectedStruct.departureAirportCode, duration: selectedStruct.duration, stop: selectedStruct.noOfStops, arrivalTime: selectedStruct.arrivalTime, arrivalAirportCode: selectedStruct.arrivalAirportCode,TripDetailsArr: detailsArr)
        
        self.myArray = [detailStructFinal]
        if selectedStruct.wayType == "two" {
            
            self.returnDetailsArr = selectedStruct.returnDetailArrWithFlightDetailStruct
            let returnDetailStructFinal = FinalStruct.init(CabinBaggage: "Nothing from DB", CheckInBaggage: "Nothing from DB",departureDate:selectedStruct.returnDepartureDate,arrivalDate:selectedStruct.returnArrivalDate,flightImgName:selectedStruct.returnFlightImgName,flightImgData:nil, flightName: selectedStruct.returnFlightName, departureTime: selectedStruct.returnDepartureTime, departureAirportCode: selectedStruct.returnDepartureAirportCode, duration: selectedStruct.returnDuration, stop: selectedStruct.returnNoofStops, arrivalTime: selectedStruct.returnArrivalTime, arrivalAirportCode: selectedStruct.returnArrivalAirportCode,TripDetailsArr: returnDetailsArr)
            
            //  self.myArray?.append(returnDetailStructFinal)
            self.myArray1 = [returnDetailStructFinal]
        }
        if selectedStruct.wayType == "multi" {
            
            ////Return Details
            self.returnDetailsArr = selectedStruct.returnDetailArrWithFlightDetailStruct
            let returnDetailStructFinal = FinalStruct.init(CabinBaggage: "Nothing from DB", CheckInBaggage: "Nothing from DB",departureDate:selectedStruct.returnDepartureDate,arrivalDate:selectedStruct.returnArrivalDate,flightImgName:selectedStruct.returnFlightImgName,flightImgData:nil, flightName: selectedStruct.returnFlightName, departureTime: selectedStruct.returnDepartureTime, departureAirportCode: selectedStruct.returnDepartureAirportCode, duration: selectedStruct.returnDuration, stop: selectedStruct.returnNoofStops, arrivalTime: selectedStruct.returnArrivalTime, arrivalAirportCode: selectedStruct.returnArrivalAirportCode,TripDetailsArr: returnDetailsArr)
            
            //  self.myArray?.append(returnDetailStructFinal)
            self.myArray1 = [returnDetailStructFinal]
            
            ////Multi Details
            self.multiDetailsArr = selectedStruct.multiDetailArrWithFlightDetailStruct
            let multiDetailStructFinal = FinalStruct.init(CabinBaggage: "Nothing from DB", CheckInBaggage: "Nothing from DB",departureDate:selectedStruct.multiDepartureDate,arrivalDate:selectedStruct.multiArrivalDate,flightImgName:selectedStruct.multiFlightImgName,flightImgData:nil, flightName: selectedStruct.multiFlightName, departureTime: selectedStruct.multiDepartureTime, departureAirportCode: selectedStruct.multiDepartureAirportCode, duration: selectedStruct.multiDuration, stop: selectedStruct.multiNoofStops, arrivalTime: selectedStruct.multiArrivalTime, arrivalAirportCode: selectedStruct.multiArrivalAirportCode,TripDetailsArr: multiDetailsArr)
            
            //  self.myArray?.append(returnDetailStructFinal)
            self.myArray2 = [multiDetailStructFinal]
        }

        print("detailC",self.detailsArr)
        print("ReturndetailC",self.returnDetailsArr)
        
        self.passTableViewHeightConstraint.constant = self.passengerTableView.contentSize.height
        self.passengerTableView .reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
     
        let convenienceFee : String!
        self.basefare.text = "PHP " + self.selectedStruct.BaseFare!
        self.taxAmount.text = "PHP " + self.selectedStruct.TaxAmt!
        convenienceFee = UserDefaults.standard.value(forKey: "ConvenienceFee") as? String
        self.convenienceFee.text = "PHP " +  convenienceFee
     
        self.otherCharge.text = "PHP " + self.selectedStruct.Markup!
        self.totalAmount.text = "PHP " + self.selectedStruct.TotalFare!
        
        let myString = self.selectedStruct!.BaseFare!
        let myFloat = (myString as NSString).floatValue
        let formatted = String(format: "%.2f", myFloat)
        self.basefare.text = "PHP " + formatted
        
        let myString1 = self.selectedStruct.TaxAmt!
        let myFloat1 = (myString1 as NSString).floatValue
        let formatted1 = String(format: "%.2f", myFloat1)
        self.taxAmount.text = "PHP " + formatted1
        
        let myString2 = self.selectedStruct.Markup!
        let myFloat2 = (myString2 as NSString).floatValue
        let formatted2 = String(format: "%.2f", myFloat2)
        self.otherCharge.text = "PHP " + formatted2
        
        let myString3 = self.selectedStruct.TotalFare!
        let myFloat3 = (myString3 as NSString).floatValue
        let formatted3 = String(format: "%.2f", myFloat3)
        self.totalAmount.text = "PHP " + formatted3
        
        self.PNRNo.text = UserDefaults.standard.value(forKey: "Booking_SK") as? String
        self.transactionId.text = UserDefaults.standard.value(forKey: "Trip_ID") as? String
      
        //Booking_SK Trip_ID ConvenienceFee
        
        if let LoginDetal = FetchLoginDetails() {
            loginResponse = FetchLoginResponse()
            self.lblEmailId.text = loginResponse.PhoneNo
            self.lblMobileNo.text = LoginDetal.Email
        }
    }
    
    @IBAction func homePageBtnTapped(_ sender: Any)
    {
        self.navigationController?.popToRootViewController(animated: true)
     /*   let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "HomePageVC") as! HomePageVC
        self.navigationController?.pushViewController(ctrl, animated: true)*/
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

//MARK
extension BookingSummaryViewController : UITableViewDelegate , UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int
    {
        if tableView == self.passengerTableView
        {
            return 1
        }
        else{
            if selectedStruct.wayType == "one" {
                return 1
            }
            else if selectedStruct.wayType == "two" {
                return 2
            }
            else
            {
                return  3
            }
        }
       
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        if tableView == self.passengerTableView
        {
            return 0.0
        }
        else{
            return 65.0
        }
       
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
            let result = tableView.dequeueReusableCell(withIdentifier: "MainCellIDGoomo") as! SummaryMainCellClass
            if(section == 0)
            {
                if let rowData = myArray?[0] {
                    result.flightNameLbl.text = rowData.departureAirportCode + " - " + rowData.arrivalAirportCode//departureAirportCode
                   // result.toAIrportName.text = rowData.arrivalAirportCode
                    result.depAirportCodeLbl.text = rowData.flightName
                    result.stopDetailsLbl.text = rowData.stop
                    result.departureDateLbl.text = rowData.departureDate + " - " + rowData.arrivalDate
                    
                    print(rowData.CabinBaggage)
                    print(rowData.CheckInBaggage)
                    
                    //  result.cabbinBaggage.text = rowData.CabinBaggage + " Cabbin Baggage, " + rowData.CheckInBaggage + " CheckIn Baggage"
                    return result
                }
            }
            else if(section == 1){
                if let rowData = myArray1?[0]
                {
                    result.flightNameLbl.text = rowData.departureAirportCode + " - " + rowData.arrivalAirportCode
                 //   result.toAIrportName.text = rowData.arrivalAirportCode
                    result.stopDetailsLbl.text = rowData.stop
                    result.depAirportCodeLbl.text = rowData.flightName
                    result.departureDateLbl.text = rowData.departureDate + " - " + rowData.arrivalDate
                    
                    print(rowData.CabinBaggage)
                    print(rowData.CheckInBaggage)
                    
                    //    result.cabbinBaggage.text = rowData.CabinBaggage + " Cabbin Baggage" + rowData.CheckInBaggage + " CheckIn Baggage"
                    return result
                }
            }
            else if(section == 2){
                if let rowData = myArray2?[0]
                {
                    print(rowData)
                    result.flightNameLbl.text = rowData.departureAirportCode + " - " + rowData.arrivalAirportCode
                   // result.toAIrportName.text = rowData.arrivalAirportCode
                    result.stopDetailsLbl.text = rowData.stop
                    result.depAirportCodeLbl.text = rowData.flightName
                    result.departureDateLbl.text = rowData.departureDate + " - " + rowData.arrivalDate
                    //   result.cabbinBaggage.text = rowData.CabinBaggage + " Cabbin Baggage" + rowData.CheckInBaggage + " CheckIn Baggage"
                    return result
                }
            }
            return result
    }
  
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == self.passengerTableView
        {
            return self.PassengerArr.count
        }
        else{
            if(section == 0)
            {
                return self.detailsArr.count
            }
            else if(section == 1)
            {
                return self.returnDetailsArr.count
            }
            else
            {
                return self.multiDetailsArr.count
            }
        }
       
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if (tableView == self.passengerTableView)
        {
            return 40.0;
        }
        else{
            return 110;
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if tableView == self.passengerTableView
        {
            let result = tableView.dequeueReusableCell(withIdentifier: "cell") as! UITableViewCell
            let label = result.viewWithTag(1) as! UILabel
            let label1 = result.viewWithTag(3) as! UILabel
            let label2 = result.viewWithTag(4) as! UILabel
            label.text = self.PassengerArr[indexPath.row].travellerTitle + self.PassengerArr[indexPath.row].firstName + self.PassengerArr[indexPath.row].lastName
            
          if self.PassengerArr[indexPath.row].travellerTitle == "Mr"
          {
            label1.text = "Male"
            label2.text = "Adult"
        }
          else if self.PassengerArr[indexPath.row].travellerTitle == "Mrs"
          {
            label1.text = "Female"
            label2.text = "Adult"
            }
            else if self.PassengerArr[indexPath.row].travellerTitle == "Ms"
          {
            label1.text = "Female"
            label2.text = "Child"
            }
          else if self.PassengerArr[indexPath.row].travellerTitle == "Miss"
          {
            label1.text = "Female"
            label2.text = "Child"
            }
          else if self.PassengerArr[indexPath.row].travellerTitle == "Master"
          {
            label1.text = "Male"
            label2.text = "Child"
            }
            return result
        }else{
            let result = tableView.dequeueReusableCell(withIdentifier: "SummarySubCellClass", for: indexPath) as! SummarySubCellClass
            if (indexPath.section == 0)
            {
                result.flightNameLbl.text = self.detailsArr [indexPath.row].operating
                result.depAirportCodeLbl.text = self.detailsArr [indexPath.row].fromAirportName
                // result.stopDetailsLbl.text = self.detailsArr [indexPath.row].marketing
                result.arrivalAirportCodeLbl.text = self.detailsArr [indexPath.row].toAirportName
                result.departureDateLbl.text = self.detailsArr [indexPath.row].departureDate //+ " - " + self.detailsArr [indexPath.row].arrivalDate
                result.arrivalDateLbl.text = self.detailsArr [indexPath.row].arrivalDate
                
                
               // result.depTimeLbl.text = self.detailsArr [indexPath.row].departureTime
                let tempfromAirportCodeStr = self.detailsArr [indexPath.row].fromAirportName
                let startInd = tempfromAirportCodeStr?.index(after: (tempfromAirportCodeStr?.lastIndex(of: "("))!)
                let endInd = tempfromAirportCodeStr?.lastIndex(of: ")")
                let formattedFromStr = tempfromAirportCodeStr![startInd!..<endInd!]
                result.depAirportCodeLbl.text = self.detailsArr [indexPath.row].fromAirportName//String(formattedFromStr)
                
                result.durationLbl.text = self.detailsArr [indexPath.row].duration
                //  result.stopDetailsLbl.text = self.detailsArr [indexPath.row].stop
             //   result.arrivalTimeLbl.text = self.detailsArr [indexPath.row].arrivalTime
                
                let tempToAirportCodeStr = self.detailsArr [indexPath.row].toAirportName
                let startInde = tempToAirportCodeStr?.index(after: (tempToAirportCodeStr?.lastIndex(of: "("))!)
                let endInde = tempToAirportCodeStr?.lastIndex(of: ")")
                let formattedToStr = tempToAirportCodeStr![startInde!..<endInde!]
                result.arrivalAirportCodeLbl.text = self.detailsArr [indexPath.row].toAirportName//String(formattedToStr)
                
                let tempDepDateArr = self.detailsArr [indexPath.row].departureDate.components(separatedBy: ",")
                
                let tempArrivalDateArr = self.detailsArr [indexPath.row].arrivalDate.components(separatedBy: ",")
                result.arrivalDateLbl.text = tempArrivalDateArr[1]
                
                result.departureDateLbl.text = tempDepDateArr[1]
                //Image
                let flightImgURL = WebServicesUrl.FlightImgURL + self.detailsArr [indexPath.row].marketing + ".gif"
                result.flightImgView.sd_setImage(with: URL(string: flightImgURL), placeholderImage: UIImage(named: "placeholder.png"),options: SDWebImageOptions(rawValue: 0), completed: { downloadedImage, error, cacheType, imageURL in
                    if error == nil{
                        print("Image downloaded without error......")
                    }else{
                        print("Error from SBWebImage Block = ",error!)
                    }
                    
                })
                
                return result
            }
            else if (indexPath.section == 1)
            {
                result.flightNameLbl.text = self.returnDetailsArr [indexPath.row].operating
                result.depAirportCodeLbl.text = self.returnDetailsArr [indexPath.row].fromAirportName
                //    result.stopDetailsLbl.text = self.returnDetailsArr [indexPath.row].marketing
                result.arrivalAirportCodeLbl.text = self.returnDetailsArr [indexPath.row].toAirportName
                result.departureDateLbl.text = self.returnDetailsArr [indexPath.row].departureDate
                result.arrivalDateLbl.text = self.returnDetailsArr [indexPath.row].arrivalDate
                
              //  result.depTimeLbl.text = self.returnDetailsArr [indexPath.row].departureTime
                let tempfromAirportCodeStr = self.returnDetailsArr [indexPath.row].fromAirportName
                let startInd = tempfromAirportCodeStr?.index(after: (tempfromAirportCodeStr?.lastIndex(of: "("))!)
                let endInd = tempfromAirportCodeStr?.lastIndex(of: ")")
                let formattedFromStr = tempfromAirportCodeStr![startInd!..<endInd!]
                result.depAirportCodeLbl.text = self.returnDetailsArr [indexPath.row].fromAirportName//String(formattedFromStr)
                
                result.durationLbl.text = self.returnDetailsArr [indexPath.row].duration
                // result.stopDetailsLbl.text = self.returnDetailsArr [indexPath.row].stop
               // result.arrivalTimeLbl.text = self.returnDetailsArr [indexPath.row].arrivalTime
                
                let tempToAirportCodeStr = self.returnDetailsArr [indexPath.row].toAirportName
                let startInde = tempToAirportCodeStr?.index(after: (tempToAirportCodeStr?.lastIndex(of: "("))!)
                let endInde = tempToAirportCodeStr?.lastIndex(of: ")")
                let formattedToStr = tempToAirportCodeStr![startInde!..<endInde!]
                result.arrivalAirportCodeLbl.text = self.returnDetailsArr [indexPath.row].toAirportName//String(formattedToStr)
                
                let tempDepDateArr = self.returnDetailsArr [indexPath.row].departureDate.components(separatedBy: ",")
                result.departureDateLbl.text = tempDepDateArr[1]
                let tempArrivalDateArr = self.returnDetailsArr [indexPath.row].arrivalDate.components(separatedBy: ",")
                 result.arrivalDateLbl.text = tempArrivalDateArr[1]
                
                //Image
                let flightImgURL = WebServicesUrl.FlightImgURL + self.returnDetailsArr [indexPath.row].marketing + ".gif"
                result.flightImgView.sd_setImage(with: URL(string: flightImgURL), placeholderImage: UIImage(named: "placeholder.png"),options: SDWebImageOptions(rawValue: 0), completed: { downloadedImage, error, cacheType, imageURL in
                    if error == nil{
                        print("Image downloaded without error......")
                    }else{
                        print("Error from SBWebImage Block = ",error!)
                    }
                    
                })
                
                return result
            }
            else if (indexPath.section == 2)
            {
                result.flightNameLbl.text = self.multiDetailsArr [indexPath.row].operating
                result.depAirportCodeLbl.text = self.multiDetailsArr [indexPath.row].fromAirportName
                //    result.stopDetailsLbl.text = self.returnDetailsArr [indexPath.row].marketing
                result.arrivalAirportCodeLbl.text = self.multiDetailsArr [indexPath.row].toAirportName
                result.departureDateLbl.text = self.multiDetailsArr [indexPath.row].departureDate
                result.arrivalDateLbl.text = self.multiDetailsArr [indexPath.row].arrivalDate
                
              //  result.depTimeLbl.text = self.multiDetailsArr [indexPath.row].departureTime
                let tempfromAirportCodeStr = self.multiDetailsArr [indexPath.row].fromAirportName
                let startInd = tempfromAirportCodeStr?.index(after: (tempfromAirportCodeStr?.lastIndex(of: "("))!)
                let endInd = tempfromAirportCodeStr?.lastIndex(of: ")")
                let formattedFromStr = tempfromAirportCodeStr![startInd!..<endInd!]
                result.depAirportCodeLbl.text = self.multiDetailsArr [indexPath.row].fromAirportName//String(formattedFromStr)
                
                result.durationLbl.text = self.multiDetailsArr [indexPath.row].duration
                // result.stopDetailsLbl.text = self.returnDetailsArr [indexPath.row].stop
              //  result.arrivalTimeLbl.text = self.multiDetailsArr [indexPath.row].arrivalTime
                
                let tempToAirportCodeStr = self.multiDetailsArr [indexPath.row].toAirportName
                let startInde = tempToAirportCodeStr?.index(after: (tempToAirportCodeStr?.lastIndex(of: "("))!)
                let endInde = tempToAirportCodeStr?.lastIndex(of: ")")
                let formattedToStr = tempToAirportCodeStr![startInde!..<endInde!]
                result.arrivalAirportCodeLbl.text = self.multiDetailsArr [indexPath.row].toAirportName//String(formattedToStr)
                
                let tempDepDateArr = self.multiDetailsArr [indexPath.row].departureDate.components(separatedBy: ",")
                result.departureDateLbl.text = tempDepDateArr[1]
                let tempArrivalDateArr = self.multiDetailsArr [indexPath.row].arrivalDate.components(separatedBy: ",")
                 result.arrivalDateLbl.text = tempArrivalDateArr[1]
                
                
                //Image
                let flightImgURL = WebServicesUrl.FlightImgURL + self.multiDetailsArr [indexPath.row].marketing + ".gif"
                result.flightImgView.sd_setImage(with: URL(string: flightImgURL), placeholderImage: UIImage(named: "placeholder.png"),options: SDWebImageOptions(rawValue: 0), completed: { downloadedImage, error, cacheType, imageURL in
                    if error == nil{
                        print("Image downloaded without error......")
                    }else{
                        print("Error from SBWebImage Block = ",error!)
                    }
                    
                })
                
                return result
            }
            
        }
          return UITableViewCell()
    }
}
class SummaryMainCellClass : UITableViewCell{
  
    @IBOutlet weak var flightNameLbl: UILabel!
    @IBOutlet weak var depAirportCodeLbl: UILabel!
    @IBOutlet weak var stopDetailsLbl: UILabel!
    @IBOutlet weak var departureDateLbl: UILabel!
  
}

class SummarySubCellClass : UITableViewCell{
    @IBOutlet weak var flightImgView: UIImageView!
    @IBOutlet weak var flightNameLbl: UILabel!
    @IBOutlet weak var depTimeLbl: UILabel!
    @IBOutlet weak var depAirportCodeLbl: UILabel!
    @IBOutlet weak var durationLbl: UILabel!
    @IBOutlet weak var stopDetailsLbl: UILabel!
    @IBOutlet weak var arrivalTimeLbl: UILabel!
    @IBOutlet weak var arrivalAirportCodeLbl: UILabel!
    @IBOutlet weak var refundOrNonRefundLbl: UILabel!
    @IBOutlet weak var departureDateLbl: UILabel!
    @IBOutlet weak var arrivalDateLbl: UILabel!
}
