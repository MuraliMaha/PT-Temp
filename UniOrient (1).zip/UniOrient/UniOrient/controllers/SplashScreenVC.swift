//
//  ViewController.swift
//  UniOrient
//
//  Created by APPLE on 27/03/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

class SplashScreenVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
//        self.perform(#selector(self.Call), with: nil, afterDelay: 0.2)
        self.perform(#selector(self.Call), with: nil, afterDelay: 1)
        
    }
    
    @objc func Call(){
        
        if !(Reachability()!.isReachable) {
            print("No Internet from Splash..................")
            self.view.ShowBlackTostWithText(message: "Check Your internet Connection", Interval: 3)
            Timer.scheduledTimer(timeInterval: 3, target: self, selector: #selector(Call), userInfo: nil, repeats: false)
        }
        else {
            
            goToHomePage()
            /*
            if isLaunchedBefore {
                callService()
            }else{
                //This is the first time of launching App
                goToHomePage()
            } */
            
            
        }
    }
    func goToHomePage(){
        let navCtrl = self.storyboard?.instantiateViewController(withIdentifier: "NavigationControllerSBID")
        self.present(navCtrl!, animated: true, completion: nil)
    }
    
    
    
    /*
    func callService()  {
        
        if let LoginDetal = FetchLoginDetails() {
            
            //            showLoading()
            let RequestDict = ["UserName":LoginDetal.Email!,"Password":LoginDetal.Password!]
            
            print("Login Input = ",RequestDict)
            
            WebService().HTTP_POST_WebServiceMethod_Profile(mainURL: WebServicesUrl.MainURL, suffix: WebServicesUrl.Login, parameterDict: RequestDict) { (ResponseDict, ResponseStatus) in
                print("Login Response from Splash = ",ResponseDict)
                
                if ResponseStatus {
                    print("Service call success ..........")
                    let fullResponse = ResponseDict as! [String:String]
                    print("fullReponse from Splash =",fullResponse)
                    //  ["Result": "483~2536~mks kalai~123456"]
                    
                    if (fullResponse["Result"]?.contains("~"))! {
                        print("Contains tilt")
                        self.GoToHomePage()
                        
                    }else{
                        print("No tilt")
                        self.GoToHomePage()
                        //                        self.GoToLoginOrRegisterPage()
                        
                        //                        self.view.ShowBlackTostWithText(message: "\(fullResponse["Result"]!)", Interval: 2)
                    }
                }
                else{
                    print("Service call failure ..........")
                    print("Try after sometimes.......")
                    self.view.ShowBlackTostWithText(message: "Try after sometimes...Server Problem....", Interval: 2)
                }
                
            }
            
        }else {
            //            self.GoToLoginOrRegisterPage()
            self.GoToHomePage()
        }
    } */
    
    /*
    func goToLoginPage(){
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "LoginPageVCSBID") as! LoginPageVC
        //        ctrl.loginFrom = "HomePage"
        //        self.navigationController?.pushViewController(ctrl, animated: false)
        self.present(ctrl, animated: true, completion: nil)
    }
    
    func GoToHomePage(){
        
        let navCtrl = self.storyboard?.instantiateViewController(withIdentifier: "NavigationControllerSBID")
        self.present(navCtrl!, animated: true, completion: nil)
        
    } */
    
  
}

