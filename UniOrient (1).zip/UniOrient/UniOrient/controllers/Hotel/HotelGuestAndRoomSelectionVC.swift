//
//  HotelGuestAndRoomSelectionVC.swift
//  UniOrient
//
//  Created by APPLE on 02/04/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

protocol HotelGuestAndRoomSelectionProtocol {
    func didRoomAndGuestDetailDoneBtnTapped(selectedArrayOfRoomStruct : [RoomStruct],controller : HotelGuestAndRoomSelectionVC)
}

class HotelGuestAndRoomSelectionVC: UIViewController {

    let basicRowHeight : CGFloat = 190
    
//    var childIncrementSelectedIndexPath : IndexPath! = nil
    
    /*
    var deleteIndexPath : IndexPath! = nil
    var adultIncrementIndexPath : IndexPath! = nil
    var adultDecrementIndexPath : IndexPath! = nil
    var childrenIncrementIndexPath : IndexPath! = nil
    var childrenDecrementIndexPath : IndexPath! = nil */
    
    @IBOutlet weak var tvContainerView: UIView!
    @IBOutlet weak var roomTV: UITableView!
    @IBOutlet weak var addRoomView: UIView!
    
//    @IBOutlet weak var guestDetailContainerView: UIView!
//    @IBOutlet weak var roomNoTitleLbl: UILabel!
    
//    @IBOutlet weak var ageTV: UITableView!
    
    var delegateVariable : HotelGuestAndRoomSelectionProtocol!
    var arrOfRoomStruct = [RoomStruct]()
    var selectedRowNo : Int = 0
    
    
    @IBOutlet weak var ageSelectionContainerView: UIView!
    @IBOutlet weak var ageSelectionContentView: UIView!
    @IBOutlet weak var agePickerView: UIPickerView!
    
    
    var ageInputArr = ["1","2","3","4","5","6","7","8","9","10","11","12"]
    
    
    
    @IBAction func ageSelectionDoneBtnTapped(_ sender: UIButton) {
        ageSelectionContainerView.isHidden = true
        
        print("Row is :",self.ageSelectionContainerView.tag)
        
        let selectedIndexPath = IndexPath(row: self.ageSelectionContainerView!.tag, section: 0)
        let cell = self.roomTV.cellForRow(at: selectedIndexPath) as! RoomCellClass
        if self.arrOfRoomStruct[self.ageSelectionContainerView.tag].noOfChildren < 3 {
            self.arrOfRoomStruct[self.ageSelectionContainerView.tag].noOfChildren += 1
            cell.numberOfChildrenLbl.text = "\(self.arrOfRoomStruct[self.ageSelectionContainerView.tag].noOfChildren!)"

            
            switch self.arrOfRoomStruct[self.ageSelectionContainerView.tag].noOfChildren {
                
                case 1:
                self.arrOfRoomStruct[self.ageSelectionContainerView.tag].ageArr[0].age = Int(ageInputArr[cell.ageSelectedIndex])
                
                case 2:
                self.arrOfRoomStruct[self.ageSelectionContainerView.tag].ageArr[1].age = Int(ageInputArr[cell.ageSelectedIndex])
                
                case 3:
                self.arrOfRoomStruct[self.ageSelectionContainerView.tag].ageArr[2].age = Int(ageInputArr[cell.ageSelectedIndex])
                
                default:
                    print("switch enters default block")
            }
            roomTV.reloadData()
        }else{
            print("Only 3 Children allowed in a room")
        }
        
    }
    @IBAction func ageSelectionCancelBtnTapped(_ sender: UIButton) {
        ageSelectionContainerView.isHidden = true
        print("children incremant btn tag =",self.ageSelectionContainerView.tag)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.roomTV.dataSource = self
        self.roomTV.delegate = self
        
//        self.roomTV.rowHeight = UITableView.automaticDimension
//        self.roomTV.estimatedRowHeight = UITableView.automaticDimension
//        self.roomTV.estimatedRowHeight = 250
        
        self.ageSelectionContainerView.isHidden = true
        agePickerView.delegate = self
        agePickerView.dataSource = self
        agePickerView.backgroundColor = UIColor.white
        agePickerView.showsSelectionIndicator = true
        agePickerView.selectRow(0, inComponent: 0, animated: true)
        
    }
    
    @IBAction func addRoomBtnTapped(_ sender: UIButton) {
        
        sender.tag = arrOfRoomStruct.count
        print("sender.tag = ",sender.tag)
        
        var aRoomStruct = RoomStruct()
        aRoomStruct.noOfAdult = 2
        aRoomStruct.noOfChildren = 0
        aRoomStruct.roomNo = arrOfRoomStruct.count + 1
        
        var child1Struct = ChildrenAgeStruct()
        child1Struct.childNo = 1
        child1Struct.age = 0
        
        var child2Struct = ChildrenAgeStruct()
        child2Struct.childNo = 2
        child2Struct.age = 0
        
        var child3Struct = ChildrenAgeStruct()
        child3Struct.childNo = 3
        child3Struct.age = 0
        
        aRoomStruct.ageArr = [child1Struct,child2Struct,child3Struct]
        arrOfRoomStruct.append(aRoomStruct)
        
        let selectedIndexPath = IndexPath(row: sender.tag, section: 0)
        self.roomTV.insertRows(at: [selectedIndexPath], with: .right)
        
        self.perform(#selector(self.reloadTheTableAfterPointFiveSeconds), with: nil, afterDelay: 0.5)
//        roomTV.reloadData()
        
        
        if arrOfRoomStruct.count == 4{
            addRoomView.isHidden = true
        }else{
            addRoomView.isHidden = false
        }
    }
    
    @objc func deleteBtnTapped (_sender : UIButton ){
        print("delete btn tapped")
        arrOfRoomStruct.remove(at: _sender.tag)
        
        let selectedIndexPath = IndexPath(row: _sender.tag, section: 0)
        self.roomTV.deleteRows(at: [selectedIndexPath], with: .left)
        
        updateRoomNoInArrOfRoomStruct()
        if arrOfRoomStruct.count < 4{
            addRoomView.isHidden = false
        }
        self.perform(#selector(self.reloadTheTableAfterPointFiveSeconds), with: nil, afterDelay: 0.5)
        
    }
    @objc func reloadTheTableAfterPointFiveSeconds(){
        roomTV.reloadData()
    }
    
    func updateRoomNoInArrOfRoomStruct(){
        for i in 0..<arrOfRoomStruct.count {
            arrOfRoomStruct[i].roomNo = i + 1
        }
    }

    @objc func adultIncrementBtnTapped(_sender : UIButton){
        print("adultIncrement btn Tapped..")
        
//        let adultIncreIndexPath = NSIndexPath(item: _sender.tag, section: 0)
        let selectedIndexPath = IndexPath(row: _sender.tag, section: 0)
        let cell = self.roomTV.cellForRow(at: selectedIndexPath as IndexPath) as! RoomCellClass
        if self.arrOfRoomStruct[_sender.tag].noOfAdult < 4 {
            self.arrOfRoomStruct[_sender.tag].noOfAdult += 1
            cell.numberOfAdultLbl.text = "\(self.arrOfRoomStruct[_sender.tag].noOfAdult!)"
            roomTV.reloadData()
        }
    }
    
    @objc func adultDecrementBtnTapped(_ sender: UIButton) {
        print("adult decrement btn tapped...")
        
//        if self.arrOfRoomStruct[selectedRowNo].noOfAdult > 1{
//            self.arrOfRoomStruct[selectedRowNo].noOfAdult -= 1
//            self.numberOfAdultLbl.text = "\(self.arrOfRoomStruct[selectedRowNo].noOfAdult!)"
//        }
        
//        let adultDecreIndexPath = NSIndexPath(item: sender.tag, section: 0)
        let selectedIndexPath = IndexPath(row: sender.tag, section: 0)
        let cell = self.roomTV.cellForRow(at: selectedIndexPath as IndexPath) as! RoomCellClass
        if self.arrOfRoomStruct[sender.tag].noOfAdult > 1{
            self.arrOfRoomStruct[sender.tag].noOfAdult -= 1
            cell.numberOfAdultLbl.text = "\(self.arrOfRoomStruct[sender.tag].noOfAdult!)"
            roomTV.reloadData()
        }
    }
    @objc func childrenIncrementBtnTapped(_sender : UIButton) {
        print("Children Increment Btn Tapped")
//        roomTV.reloadData()
        
        if self.arrOfRoomStruct[_sender.tag].noOfChildren < 3 {
            self.ageSelectionContainerView.isHidden = false
            self.ageSelectionContainerView.tag = _sender.tag
            self.agePickerView.selectRow(0, inComponent: 0, animated: false)
            
            let selectedIndexPath = IndexPath(row: _sender.tag, section: 0)
            let cell = self.roomTV.cellForRow(at: selectedIndexPath as IndexPath) as! RoomCellClass
            cell.ageSelectedIndex = 0
            
        }
    }
    @objc func childrenDecrementBtnTapped(_sender : UIButton) {
        print("Children Decrement Btn Tapped")
       
//        let childDecreIndexPath = NSIndexPath(item: _sender.tag, section: 0)
        let selectedIndexPath = IndexPath(row: _sender.tag, section: 0)
        let cell = self.roomTV.cellForRow(at: selectedIndexPath as IndexPath) as! RoomCellClass
        if self.arrOfRoomStruct[_sender.tag].noOfChildren > 0 {
            
            switch self.arrOfRoomStruct[_sender.tag].noOfChildren {
            case 1:
                self.arrOfRoomStruct[_sender.tag].ageArr[0].age = 0
                
            case 2:
                self.arrOfRoomStruct[_sender.tag].ageArr[1].age = 0
                
            case 3:
                self.arrOfRoomStruct[_sender.tag].ageArr[2].age = 0
                
            default:
                print("switch enters default block")
            }
            
            
            self.arrOfRoomStruct[_sender.tag].noOfChildren -= 1
            cell.numberOfChildrenLbl.text = "\(self.arrOfRoomStruct[_sender.tag].noOfChildren!)"
            
            
            
            
            
            
            roomTV.reloadData()
        }
        
    }
    
    @IBAction func backBtnTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func doneBtnTapped(_ sender: UIButton) {
        delegateVariable.didRoomAndGuestDetailDoneBtnTapped(selectedArrayOfRoomStruct: arrOfRoomStruct, controller: self)
        self.navigationController?.popViewController(animated: true)
        
    }
}





extension HotelGuestAndRoomSelectionVC : UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView.tag == 1 {
            return arrOfRoomStruct.count
        }else{
            return arrOfRoomStruct[self.selectedRowNo].noOfChildren
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        if tableView.tag == 1 {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "RoomCellID", for: indexPath) as! RoomCellClass
        cell.roomNoLbl.text = "Room \(arrOfRoomStruct[indexPath.row].roomNo!)"
        cell.numberOfAdultLbl.text = "\(arrOfRoomStruct[indexPath.row].noOfAdult!)"
        cell.numberOfChildrenLbl.text = "\(arrOfRoomStruct[indexPath.row].noOfChildren!)"
        
        
        
        if arrOfRoomStruct.count == 1 {
            cell.deleteBtn.isHidden = true
        }else{
            cell.deleteBtn.isHidden = false
        }
        cell.deleteBtn.addTarget(self, action: #selector(self.deleteBtnTapped), for: .touchUpInside)
//        self.deleteIndexPath = indexPath
        cell.deleteIndexPath = indexPath
        cell.deleteBtn.tag = indexPath.row
        
        
        cell.adultIncrementBtn.addTarget(self, action: #selector(self.adultIncrementBtnTapped), for: .touchUpInside)
//        self.adultIncrementIndexPath = indexPath
        cell.adultIncrementIndexPath = indexPath
        cell.adultIncrementBtn.tag = indexPath.row
        
        cell.adultDecrementBtn.addTarget(self, action: #selector(self.adultDecrementBtnTapped), for: .touchUpInside)
//        self.adultDecrementIndexPath = indexPath
        cell.adultDecrementIndexPath = indexPath
        cell.adultDecrementBtn.tag = indexPath.row
        
        /*
        if cell.btnTappedFlag{
            cell.ageTVContainerViewsHeightConstraint.constant = 50
        }else{
            cell.ageTVContainerViewsHeightConstraint.constant = 0
        }
        cell.childrenIncrementBtn.addTarget(self, action: #selector(self.childrenIncrementBtnTapped), for: .touchUpInside)
        self.childIncrementSelectedIndexPath = indexPath
        cell.childrenIncrementBtn.tag = indexPath.row */
        
        
        cell.childrenIncrementIndexPath = indexPath
        cell.childrenIncrementBtn.tag = indexPath.row
        cell.childrenIncrementBtn.addTarget(self, action: #selector(self.childrenIncrementBtnTapped), for: .touchUpInside)
        print("childrenIncrementIndexPath.row =",cell.childrenIncrementIndexPath.row)
        
        
        cell.childrenDecrementIndexPath = indexPath
        cell.childrenDecrementBtn.tag = indexPath.row
        cell.childrenDecrementBtn.addTarget(self, action: #selector(self.childrenDecrementBtnTapped), for: .touchUpInside)
        
        cell.child1AgeLbl.text = "\(arrOfRoomStruct[indexPath.row].ageArr[0].age!)"
        cell.child2AgeLbl.text = "\(arrOfRoomStruct[indexPath.row].ageArr[1].age!)"
        cell.child3AgeLbl.text = "\(arrOfRoomStruct[indexPath.row].ageArr[2].age!)"
        /*
        cell.child1View.isHidden = true
        cell.child2View.isHidden = true
        cell.child3View.isHidden = true
        
        
        cell.ageContainerView.isHidden = true */
        
        return cell
//        }
        /*
        else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "ChildrenAgeCellID", for: indexPath) as! ChildrenAgeCellClass
            cell.childNoLbl.text = "Child \(indexPath.row + 1)"
            
            if arrOfRoomStruct[selectedRowNo].ageArr[indexPath.row].age == 0{
                cell.ageLbl.text = "infant"
            }else{
                cell.ageLbl.text = "\(arrOfRoomStruct[selectedRowNo].ageArr[indexPath.row].age!) year"
            }
            
            cell.ageIncrementBtn.addTarget(self, action: #selector(self.ageIncrementBtnTapped), for: .touchUpInside)
            cell.ageIncrementBtn.tag = indexPath.row
            
            cell.ageDecrementBtn.addTarget(self, action: #selector(self.ageDecrementBtnTapped), for: .touchUpInside)
            cell.ageDecrementBtn.tag = indexPath.row
            return cell
        } */
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        
        /*
        if tableView.tag == 1 {
            self.guestDetailContainerView.isHidden = false
            self.roomNoTitleLbl.text = "Room \(arrOfRoomStruct[indexPath.row].roomNo!)"
            
            self.numberOfAdultLbl.text = "\(arrOfRoomStruct[indexPath.row].noOfAdult!)"
            self.numberOfChildrenLbl.text = "\(arrOfRoomStruct[indexPath.row].noOfChildren!)"
            
            self.selectedRowNo = indexPath.row
            
            self.ageTV.reloadData()
        }else{
            
        } */
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        let heightToAdd : CGFloat = (CGFloat(self.arrOfRoomStruct[indexPath.row].noOfChildren! * 30))
        return self.basicRowHeight + heightToAdd
//        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    /*
    @IBAction func closeBtnTapped(_ sender: UIButton) {
        self.guestDetailContainerView.isHidden = true
    }
    
    @objc func ageIncrementBtnTapped (_sender : UIButton ){
        if arrOfRoomStruct[selectedRowNo].ageArr[_sender.tag].age < 12{
            arrOfRoomStruct[selectedRowNo].ageArr[_sender.tag].age += 1
            ageTV.reloadData()
        }
    }
    @objc func ageDecrementBtnTapped (_sender : UIButton ){
        if arrOfRoomStruct[selectedRowNo].ageArr[_sender.tag].age > 0{
            arrOfRoomStruct[selectedRowNo].ageArr[_sender.tag].age -= 1
            ageTV.reloadData()
        }
    } */
    
}
class RoomCellClass : UITableViewCell {
//    @IBOutlet weak var roomNoLbl: UILabel!
//    @IBOutlet weak var noOfAdultLbl: UILabel!
//    @IBOutlet weak var deleteBtn: UIButton!
    
    @IBOutlet weak var adultIncrementBtn: UIButton!
    @IBOutlet weak var numberOfAdultLbl: UILabel!
    @IBOutlet weak var adultDecrementBtn: UIButton!
    @IBOutlet weak var childrenIncrementBtn: UIButton!
    @IBOutlet weak var numberOfChildrenLbl: UILabel!
    @IBOutlet weak var childrenDecrementBtn: UIButton!
    
    @IBOutlet weak var ageTVContainerViewsHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var roomNoLbl: UILabel!
    @IBOutlet weak var deleteBtn: UIButton!
    
   
//    var btnTappedFlag : Bool = false
//    var deleteIndexPath : IndexPath = nil
    /*
    @IBOutlet weak var ageContainerView: UIView!
    
    
    @IBOutlet weak var innerTVContainer: UIView!
    @IBOutlet weak var innerTV: UITableView! */
    
    @IBOutlet weak var child1View: UIView!
    @IBOutlet weak var child2View: UIView!
    @IBOutlet weak var child3View: UIView!
    
    @IBOutlet weak var child1AgeLbl: UILabel!
    @IBOutlet weak var child2AgeLbl: UILabel!
    @IBOutlet weak var child3AgeLbl: UILabel!
    
    var child1Age : String = "0"
    var child2Age : String = "0"
    var child3Age : String = "0"
    
//    var childAgeArr = [String]()
    
//    var ageSelectedItem = "1"
    var ageSelectedIndex : Int = 0
//    var agePreviousIndex : Int = 0
    
    var deleteIndexPath : IndexPath! = nil
    var adultIncrementIndexPath : IndexPath! = nil
    var adultDecrementIndexPath : IndexPath! = nil
    var childrenIncrementIndexPath : IndexPath! = nil
    var childrenDecrementIndexPath : IndexPath! = nil
}


//MARK: - PickerView Delegate {
extension HotelGuestAndRoomSelectionVC : UIPickerViewDelegate , UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return ageInputArr.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return ageInputArr[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        let myIndexPath = NSIndexPath(item:self.ageSelectionContainerView!.tag, section: 0)
        let cell = self.roomTV.cellForRow(at:myIndexPath as IndexPath) as! RoomCellClass
        cell.ageSelectedIndex = pickerView.selectedRow(inComponent: 0)
    }
}

class InnerCell: UITableViewCell {
    @IBOutlet weak var Lbl1: UILabel!
    @IBOutlet weak var Lbl2: UILabel!
}
