//
//  PaymentVC.swift
//  UniOrient
//
//  Created by APPLE on 24/05/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

class PaymentVC: UIViewController {

    @IBOutlet weak var loadingView: UIView!
    
    @IBOutlet weak var activityIndView: UIActivityIndicatorView!
    //-------Flight
    var providedInputDict = [String:String]()
    var DictInput = Dictionary<String, String>()
    var selectedStruct : FlightResultAndDetailStruct!
    var FlightTripID : String = String()
    var Booking_SK : String = String()
    var FlightMobileNo : String = String()
    var FlightEmailID : String = String()
     var PassengerArr = [TravellerDetailStruct]()
    
    //----- End Flight
    
    @IBOutlet weak var paymentWebView: UIWebView!
    
    

    var txtnID : String!
    var email : String!
    var finalTotalAmount : String!
    var descriptionForBooking : String!
    var strForChecksum : String!
    
    var aSelectedHotelStruct : HotelStruct!
    var aInputDict : [String:String]!
    var aDateData : DateSelectedStruct!
   
    var aSelectedRoomIndex : Int!
    var aGuestAndRoomDetailsArr = [RoomStruct]()
    var aAPITransactionInputDict : [String : String]!
    var aAPITransactionServiceOutputStruct : APIBookingTransactionStruct!
    var aBookerInfoStruct : BookerInfoStruct!
    var aPricingDictOfAPITransaction : [String : Any]!
    var aConveinceAmtAddedPrice : String!
    var bookingStatusStr : String!
    
    var itineraryDateDisplayFormat = DateFormatter()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        paymentWebView.scrollView.scrollsToTop = true
        
        paymentWebView.delegate = self
        if self.descriptionForBooking == "Hotel Booking"{
            txtnID = aAPITransactionServiceOutputStruct.TripID
            email = aBookerInfoStruct.email
            finalTotalAmount = self.aConveinceAmtAddedPrice
        }else{
            //This block for Flight
            txtnID = self.FlightTripID
            email = self.FlightEmailID
// finalTotalAMount already added from Traveller View
        }
        
        strForChecksum = "\(DragonPayCredentials.MID):\(txtnID!):\(self.finalTotalAmount!):PHP:\(descriptionForBooking!):\(email!):\(DragonPayCredentials.MPwd)"
        print("strForChecksum =",strForChecksum)
        
        let checksum = strForChecksum.sha1()
        print("checksum after applying Alg to String =",checksum)
        
        let inputDictForPayment = [
            "merchantid" : DragonPayCredentials.MID,
            "txnid" : "\(txtnID!)",
            "amount" : finalTotalAmount!,
            "ccy" : "PHP",
            "description" : self.descriptionForBooking!,
            "email" : self.email!,
            "digest" : checksum,
            "param1" : "1"
        ]
        let parserStr = Parser(dict: inputDictForPayment)
        let final = DragonPayCredentials.PaymentURL + parserStr
        print("final = ",final)
        
        let pass_url = final.replacingOccurrences(of: " ", with: "%20")
        print("url to pass to next vc =",pass_url)
      
        self.loadingView.isHidden = false
        self.activityIndView.startAnimating()
        
        
//        showLoading()
        let url = URL (string: pass_url)
        let requestObj = URLRequest(url: url!)
        paymentWebView.loadRequest(requestObj)
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
    @IBAction func backBtnTapped(_ sender: Any)
    {
        self.navigationController?.popViewController(animated: true)
    }
    func Parser(dict:[String:String]) -> String {
        var soapMessage = ""
        
        for (key,value) in dict {
            soapMessage.append("\(key)=\(value)&")
        }
        if soapMessage != "" {
            soapMessage = soapMessage.substring(to: soapMessage.index(soapMessage.endIndex, offsetBy: -1))
        }
        return soapMessage
    }

}
extension PaymentVC : UIWebViewDelegate {
    
    func webViewDidStartLoad(_ webView: UIWebView) {
       // showLoading()
        self.loadingView.isHidden = false
        self.activityIndView.startAnimating()
    }
    
    func webView(_ webView: UIWebView, didFailLoadWithError error: Error) {
        print("Error From Webview delegate method didFailLoadWithError =  ",error.localizedDescription)
         self.loadingView.isHidden = true
      //  hideLoading()
    }
    
    func webViewDidFinishLoad(_ webView: UIWebView) {
        
        if (webView.request?.url != nil){
            let receivedURL = (webView.request?.url?.absoluteString)!
            print("receivedURL = ",receivedURL)
            
            if receivedURL.contains(DragonPayCredentials.RedirectURL){
                print("ctrl here..")
                
                let separeatedURL = receivedURL.components(separatedBy:"?")
                let dataStr = separeatedURL[1]
                let aData = dataStr.components(separatedBy: "&")
                
                
                let transactionId = getTheValue(aStr: aData[0])
                let referenceNo = getTheValue(aStr: aData[1])
                let status = getTheValue(aStr: aData[2])
                var message = getTheValue(aStr: aData[3])
                let digest = getTheValue(aStr: aData[4])
                
                var aPaymentStruct = PaymentStruct()
                aPaymentStruct.transactionId = transactionId
                aPaymentStruct.referenceNo = referenceNo
                aPaymentStruct.status = status
                aPaymentStruct.message = message
                aPaymentStruct.digest = digest
                
                message = message.replacingOccurrences(of: "%5b", with: "[")
                message = message.replacingOccurrences(of: "%5d", with: "]")
                message = message.replacingOccurrences(of: "%3a", with: ":")
                message = message.replacingOccurrences(of: "%23", with: "#")
                message = message.replacingOccurrences(of: "+", with: " ")
                aPaymentStruct.message = message
                
                if status == "S" {
                    
                    let strForChecksum = "\(transactionId):\(referenceNo):\(status):\(message):\(DragonPayCredentials.MPwd)"
                    print("strForChecksum =",strForChecksum)
                    
                    let checksum = strForChecksum.sha1()
                    if checksum != digest {
                       // hideLoading()
                         self.loadingView.isHidden = true
                        self.activityIndView.stopAnimating()
                        
                        if descriptionForBooking == "Hotel Booking"{
                            self.moveToHotelBookingSummaryPage(bookingStatus: "Failure")
                        }else{
                            //This Block for Flight
                             self.moveToFlightBookingSummaryPage(bookingStatus: "Failure")
                        }
                        callPaymentInfoService(paymentData: aPaymentStruct)
                    }else{
                            print("Status is Success...So Payment success...")
                        
                            if descriptionForBooking == "Hotel Booking"{
                               callFinalBookingHotel()
                            }else{
                                //This Block for Flight
                                FlightFinalBooking()
                            }
                            callPaymentInfoService(paymentData: aPaymentStruct)
                    }
                }else{
                   // hideLoading()
                    self.loadingView.isHidden = true
                    self.activityIndView.stopAnimating()
                    
                    callPaymentInfoService(paymentData: aPaymentStruct)
                    
                    if descriptionForBooking == "Hotel Booking"{
                        self.moveToHotelBookingSummaryPage(bookingStatus: "Cancelled")
                    }else{
                        //This Block for Flight
                      self.moveToFlightBookingSummaryPage(bookingStatus: "Cancelled")
                    }
                }

            }else{
               // hideLoading()
                self.loadingView.isHidden = true
                self.activityIndView.stopAnimating()
            }
        
        }
    }
    
    func webView(_ webView: UIWebView, shouldStartLoadWith request: URLRequest, navigationType: UIWebView.NavigationType) -> Bool {
        //        print("request = ",request)
        return true
    }
    func getTheValue(aStr : String)->String{
        let tempArr = aStr.components(separatedBy: "=")
        return tempArr[1]
    }
    
    func callPaymentInfoService(paymentData : PaymentStruct) {
        print("callPaymentInfoService entered....")
        if (Reachability()?.isReachable)! {
            
            let URL : String!
            let inputDictForPaymentInfo : [String : String]!
            
            
            if descriptionForBooking == "Hotel Booking" {
                URL = WebServicesUrl.HotelServiceUrl
                inputDictForPaymentInfo = [ "Booking_SK" : aAPITransactionServiceOutputStruct.BookingSK,
                                            "Module_SK" : "15",
                                            "TotalAmount" : "\(self.finalTotalAmount!)",
                                            "PaymentStatus" : paymentData.status,
                                            "TransactionId" : paymentData.transactionId,
                                            "RefNum" : paymentData.referenceNo,
                                            "Message" : paymentData.message,
                                            "Digest" : paymentData.digest,
                                            "PayFrom" : "1" //for Mobile 1,for web somethingelse
                                        ]
                print("inputDictForPaymentInfo =",inputDictForPaymentInfo)
                
            }else{
                //this block for Flight
                URL = WebServicesUrl.FlightServiceUrl
                inputDictForPaymentInfo = [ "Booking_SK" : self.Booking_SK,
                                            "Module_SK" : "\(self.providedInputDict["ModuleId"]!)",
                                            "TotalAmount" : "\(self.finalTotalAmount!)",
                    "PaymentStatus" : paymentData.status,
                    "TransactionId" : paymentData.transactionId,
                    "RefNum" : paymentData.referenceNo,
                    "Message" : paymentData.message,
                    "Digest" : paymentData.digest,
                    "PayFrom" : "1" //for Mobile 1,for web somethingelse
            ]
            }
            
            WebService().HTTP_POST_WebServiceMethod_Profile(mainURL: URL, suffix:WebServicesUrl.PaymentInfo , parameterDict: inputDictForPaymentInfo) { (ResponseDict, ResponseStatus) in
                print("PaymentInfo Service Response = ",ResponseDict)
                
                if ResponseStatus
                {
                    print("PaymentInfoService call success ..........")
                    let fullResponse = ResponseDict as! [String:String]
                    print(fullResponse)
                    print("Payment Data send to backend....")
                }
            }
            
        }else{
            print("No Internet....")
            self.view.ShowBlackTostWithText(message: "Check Your internet Connection", Interval: 3)
        }
    }
    

    func callFinalBookingHotel(){
        print("callFinalBookingHotel entered....")
        
        if (Reachability()?.isReachable)! {
            let inputDictForFinalBooking : [String : String]!
            let webServiceMethodName : String!
            
            if self.aSelectedHotelStruct.APIType == "7" { //APIType 7 means HotelBeds
                print("Supplier = HotelBeds")
                webServiceMethodName = WebServicesUrl.HotelbedsFinalbooking
                inputDictForFinalBooking = [ "Booking_SK" : aAPITransactionServiceOutputStruct.BookingSK,
                                             "TripId" : aAPITransactionServiceOutputStruct.TripID,
                                             "RoomBookingCode" : self.aSelectedHotelStruct.RoomDetailArr[aSelectedRoomIndex].RoomBookingCode,
                                             "NoOfRooms" : self.aSelectedHotelStruct.NoOfRooms!
                ]
                print("inputDictForFinalBooking = ",inputDictForFinalBooking)
            }else if self.aSelectedHotelStruct.APIType == "18" { //APIType 18 means MikiTravels
                print("Supplier = MikiTravels")
                webServiceMethodName = WebServicesUrl.MikiFinalbooking
    
                inputDictForFinalBooking = [
                    "Booking_SK" : aAPITransactionServiceOutputStruct.BookingSK,
                    "HotelCity" : self.aInputDict["HotelCity"]!,
                    "HotelId" : aSelectedHotelStruct.HotelUniqueKey,
                    "CheckIn" : itineraryDateDisplayFormat.string(from: self.aDateData.checkInDate),
                    "CheckOut" : itineraryDateDisplayFormat.string(from: self.aDateData.checkOutDate),
                    "NoOfRooms" : self.aSelectedHotelStruct.NoOfRooms!,
                    "paxstr" : self.aSelectedHotelStruct.paxstr ?? "",
                    "RoomTypeCode" : aSelectedHotelStruct.RoomDetailArr[aSelectedRoomIndex].RoomTypeCode,
                    "RoomTotalRate" :  "\(self.finalTotalAmount!)", //theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].bbPrice ?? "",
                    "MealBasisID" : aSelectedHotelStruct.RoomDetailArr[aSelectedRoomIndex].RatePlanCode,
                    "Tripid" : aAPITransactionServiceOutputStruct.TripID,
                    "nationality" : "",
                    "RoomBookingCode" : self.aSelectedHotelStruct.RoomDetailArr[aSelectedRoomIndex].RoomBookingCode,
                    "CurrencyCode" : self.aSelectedHotelStruct.Currency
                    ] as? [String : String]
                
                print("inputDictForFinalBooking = ",inputDictForFinalBooking)
                
            }else{
                print("Supplier = HotelExtranet")
                webServiceMethodName = WebServicesUrl.HotelExtranetFinalbooking
                
                inputDictForFinalBooking = [ "Booking_SK" : aAPITransactionServiceOutputStruct.BookingSK,
                                             "HotelCity" : self.aInputDict["HotelCity"]!,
                                             "HotelId" : aSelectedHotelStruct.HotelUniqueKey,
                                             "RoomBookingCode" : self.aSelectedHotelStruct.RoomDetailArr[aSelectedRoomIndex].RoomBookingCode,
                                             "RoomTypeCode" : aSelectedHotelStruct.RoomDetailArr[aSelectedRoomIndex].RoomTypeCode,
                                             "Inclusion" : aSelectedHotelStruct.RoomDetailArr[aSelectedRoomIndex].inclusions,
                                             "MealBasisID" : aSelectedHotelStruct.RoomDetailArr[aSelectedRoomIndex].RatePlanCode,
                                             "APIAmt" : aSelectedHotelStruct.RoomDetailArr[aSelectedRoomIndex].APIAMT
                ]
                print("inputDictForFinalBooking = ",inputDictForFinalBooking)
            }
            WebService().HTTP_POST_WebServiceMethod_Profile(mainURL: WebServicesUrl.HotelServiceUrl, suffix: webServiceMethodName, parameterDict: inputDictForFinalBooking) { (ResponseDict, ResponseStatus) in
                print("Final Service Response = ",ResponseDict)
               // hideLoading()
                self.loadingView.isHidden = true
                self.activityIndView.stopAnimating()
                
                if ResponseStatus
                {
                    print("Service call success ..........")
                    let fullResponse = ResponseDict as! [String:String]
                    print(fullResponse)
                    if fullResponse["Result"] == "" {
                        print("final booking respnse is empty...So transaction failure")
                        self.view.ShowBlackTostWithText(message: "Booking Transaction failed...", Interval: 2)
                        self.moveToHotelBookingSummaryPage(bookingStatus: "Failure")
                    }else{
                        print("final booking response is not empty...so tranaction success..Your hotel  has been confirmed.")
                        
                        self.moveToHotelBookingSummaryPage(bookingStatus: "Success")
                    }
                }
            }
            
        }else{
            print("No Internet....")
            self.view.ShowBlackTostWithText(message: "Check Your internet Connection", Interval: 3)
        }
        
    }
    func moveToHotelBookingSummaryPage(bookingStatus : String){
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier:"HotelBookingSummaryVCSBID") as! HotelBookingSummaryVC
        ctrl.selectedHotelStruct = self.aSelectedHotelStruct
        ctrl.theInputDict = self.aInputDict
        ctrl.dateData = self.aDateData
        ctrl.theSelectedRoomIndex = self.aSelectedRoomIndex
        ctrl.theGuestAndRoomDetailsArr =  self.aGuestAndRoomDetailsArr
        ctrl.apiTransactionInputDict = self.aAPITransactionInputDict
        ctrl.apiTransactionServiceOutputStruct = self.aAPITransactionServiceOutputStruct
        ctrl.theBookerInfoStruct = self.aBookerInfoStruct
        ctrl.pricingDictOfAPITransaction = self.aPricingDictOfAPITransaction
        ctrl.theConveinceAmtAddedPrice = "\(self.finalTotalAmount!)"
        ctrl.bookingStatusStr = bookingStatus
        self.navigationController?.pushViewController(ctrl, animated: true)
    }
    func moveToFlightBookingSummaryPage(bookingStatus : String){
        
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "bookingSummaryVC") as! BookingSummaryViewController
        ctrl.selectedStruct = self.selectedStruct
        ctrl.providedInputDict = self.providedInputDict
        ctrl.PassengerArr = self.PassengerArr
        ctrl.strPaymentStatus = bookingStatus
        self.navigationController?.pushViewController(ctrl, animated: true)
    }
    func FlightFinalBooking()
    {
        
        let strdata = "way=" + "\(self.providedInputDict["WayType"]!)" + "&wayIdentifier=" + "0" + "&adult="
            + "\(self.providedInputDict["AdultCount"]!)" + "&child=" + "\(self.providedInputDict["ChildCount"]!)" + "&infant=" + "\(self.providedInputDict["InfantCount"]!)"
            
            + "&departAirportall=" + "\(self.selectedStruct.dairportall!)" + "&arrivalAirportall=" + "\(self.selectedStruct.aairportall!)" + "&operatingAirlineall=" + "\(self.selectedStruct.operatingAirlineall!)"
            + "&departdatetimetall=" + "\(self.selectedStruct.Departdatetimetall!)" + "&arrivaldatetimeall=" + "\(self.selectedStruct.Arrivaldatetimeall!)" + "&equipmentTypeall=" + "\(self.selectedStruct.equipmentTypeall!)"
            + "&flightNumberall=" + "\(self.selectedStruct.flightnoall!)" + "&marketingAirlineall=" + "\(self.selectedStruct.marketingall!)" + "&bookingCodeall=" + "\(self.selectedStruct.bookingCodeall!)"
            + "&index=0" + "&filename=" + "\(self.selectedStruct.filename!)" + "&booking_SK=" + "\(self.Booking_SK)"
            + "&tripID=" + "\(self.FlightTripID)" + "&email=" + "\(self.FlightEmailID)" + "&mobile=" + "\(self.FlightMobileNo)"
            +  "&ModuleId=" + "\(self.providedInputDict["ModuleId"]!)"
            + "&FromCityName=" + "\(self.providedInputDict["Origin"]!)"  + "&ToCityName=" + "\(self.providedInputDict["Destination"]!)" + "&sessionid=0"  + "&AccountId=" + "IXCRAJ042" + "&api_sk=" + "20" + "&ISLCC=" + "false"
        
        print(strdata)
        
        print(WebServicesUrl.FlightServiceUrl)
        if (Reachability()?.isReachable)!
        {
            WebService().HTTP_POST_FlightBookingTransaction(mainURL: WebServicesUrl.FlightServiceUrl, suffix: "FlightBooking", parameterDict: strdata) { (ResponseDict, success) in
              //  hideLoading()
                self.loadingView.isHidden = true
                self.activityIndView.stopAnimating()
                
                if success {
                    print("Service call success ..........")
                    let fullResponse = ResponseDict as! [String:String]
                    print(fullResponse)
                    
                    if (fullResponse["Result"]?.contains("XMLSchema"))!
                    {
                        self.view.ShowBlackTostWithText(message: "Try after sometimes...Server Problem....", Interval: 2)
                        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "bookingSummaryVC") as! BookingSummaryViewController
                        ctrl.selectedStruct = self.selectedStruct
                        ctrl.providedInputDict = self.providedInputDict
                        ctrl.PassengerArr = self.PassengerArr
                        ctrl.strPaymentStatus = "Failed"
                        self.navigationController?.pushViewController(ctrl, animated: true)
                    }
                    else if (fullResponse["Result"]?.contains("/"))!
                    {
                        let arr = fullResponse["Result"]?.components(separatedBy: "/")
                        var aLoginResponseStruct = FlightAPIBookingTransactionDetails()
                        aLoginResponseStruct.BookingId = arr![0]
                        aLoginResponseStruct.BookingPNR = arr![1]
                        UserDefaults.standard.set(arr![0], forKey: "flightbookingpnr")
                        UserDefaults.standard.set(arr![1], forKey: "flightbookingid")
                        
                        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "bookingSummaryVC") as! BookingSummaryViewController
                        ctrl.selectedStruct = self.selectedStruct
                        ctrl.providedInputDict = self.providedInputDict
                        ctrl.PassengerArr = self.PassengerArr
                        ctrl.strPaymentStatus = "Success"
                        self.navigationController?.pushViewController(ctrl, animated: true)
                        
                    }
                
                    else
                    {
                        self.view.ShowBlackTostWithText(message: "Try after sometimes...Server Problem....", Interval: 2)
                    //    String().alert(view: self, title: "UniOrient Info", message: "Booking Failed"  + ". Kindly contact our UniOrient team for refund")
                        
                        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "bookingSummaryVC") as! BookingSummaryViewController
                        ctrl.selectedStruct = self.selectedStruct
                        ctrl.providedInputDict = self.providedInputDict
                        ctrl.PassengerArr = self.PassengerArr
                        ctrl.strPaymentStatus = "Failed"
                        self.navigationController?.pushViewController(ctrl, animated: true)
                    }
                    
                }
                else
                {
                    self.view.ShowBlackTostWithText(message: "Try after sometimes...Server Problem....", Interval: 2)
                    print("Failure",ResponseDict)
                }
            }
        }
    }
}
