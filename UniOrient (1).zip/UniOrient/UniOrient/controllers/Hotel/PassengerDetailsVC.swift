//
//  PassengerDetailsVC.swift
//  UniOrient
//
//  Created by APPLE on 02/05/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

/*
https://dosaygive.com/miss-ms-mrs/
Miss – Some still use it for any unmarried woman (I do!). But Emily Post says that it okay, but mainly it is for girls 18 years old and younger.

Mrs. – For married women. Also acceptable for divorced and widowed women.*

Ms. – Can be used for any woman over the age of 18. So when in doubt, you can always use this. If a woman is married and keeps her maiden name, refer to her as Ms. */

import UIKit

protocol PassengerDetailsProtocol {
    func didDoneBtnTapped(_ arrToPass : [PassengerStruct] ,_ passengerFilled : Bool ,_ controller : PassengerDetailsVC )
//    func didBackBtnTapped(_ backBtnTappedFlag : Bool ,_ controller : PassengerDetailsVC)
}

class PassengerDetailsVC: UIViewController {

    var DelegateVar:PassengerDetailsProtocol!
    
    
    @IBOutlet weak var myScrollView: UIScrollView!
    @IBOutlet weak var myTV: UITableView!
    var selectedHotelStruct : HotelStruct!
    var theInputDict : [String:String]!
    var theGuestAndRoomDetailsArr = [RoomStruct]()
    var arrayCount : Int!
    
   
    var noOfRooms : Int!
    var adultCountInRoom1 : Int!
    var adultCountInRoom2 : Int!
    var adultCountInRoom3 : Int!
    var adultCountInRoom4 : Int!
    
    var childCountInRoom1 : Int!
    var childCountInRoom2 : Int!
    var childCountInRoom3 : Int!
    var childCountInRoom4 : Int!
   
    var totalGuestInRoom1 : Int!
    var totalGuestInRoom2 : Int!
    var totalGuestInRoom3 : Int!
    var totalGuestInRoom4 : Int!
    
 
//    var adultCountArr = [Int]()
    
    @IBOutlet weak var doneBtn: UIButton!
    
    var passengerDetailStructArr = [PassengerStruct]()
    var previouslySelectedPassengerDetailStructArr = [PassengerStruct]()
    
    let titleSelectedImg = UIImage.init(named: "optionSelectedViolet")
    let titleUnselectedImg = UIImage.init(named: "optionUnselectedViolet")
    
    var allFilledFlag : Bool!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.myTV.dataSource = self
        self.myTV.delegate = self
        
        self.noOfRooms = Int(self.theInputDict["NoOfRooms"]!)
        for i in 0..<theGuestAndRoomDetailsArr.count{
            if i == 0{
                adultCountInRoom1 = self.theGuestAndRoomDetailsArr[0].noOfAdult
                childCountInRoom1 = self.theGuestAndRoomDetailsArr[0].noOfChildren
                totalGuestInRoom1 = adultCountInRoom1 + childCountInRoom1
                
                for _ in 0..<adultCountInRoom1 {
                    var aSt = PassengerStruct()
                    aSt.title = "Mr"
                    aSt.age = "0"
                    passengerDetailStructArr.append(aSt)
                }
                for x in 0..<childCountInRoom1 {
                    var aSt = PassengerStruct()
                    aSt.title = "Mstr"
                    aSt.age = "\(theGuestAndRoomDetailsArr[0].ageArr[x].age!)"
                    passengerDetailStructArr.append(aSt)
                }
                
            }else if i == 1 {
                adultCountInRoom2 = self.theGuestAndRoomDetailsArr[1].noOfAdult
                childCountInRoom2 = self.theGuestAndRoomDetailsArr[1].noOfChildren
                totalGuestInRoom2 = adultCountInRoom2 + childCountInRoom2
                
                for _ in 0..<adultCountInRoom2 {
                    var aSt = PassengerStruct()
                    aSt.title = "Mr"
                    aSt.age = "0"
                    passengerDetailStructArr.append(aSt)
                }
                for x in 0..<childCountInRoom2 {
                    var aSt = PassengerStruct()
                    aSt.title = "Mstr"
                    aSt.age = "\(theGuestAndRoomDetailsArr[1].ageArr[x].age!)"
                    passengerDetailStructArr.append(aSt)
                }
            }else if i == 2 {
                adultCountInRoom3 = self.theGuestAndRoomDetailsArr[2].noOfAdult
                childCountInRoom3 = self.theGuestAndRoomDetailsArr[2].noOfChildren
                totalGuestInRoom3 = adultCountInRoom3 + childCountInRoom3
                
                for _ in 0..<adultCountInRoom3 {
                    var aSt = PassengerStruct()
                    aSt.title = "Mr"
                    aSt.age = "0"
                    passengerDetailStructArr.append(aSt)
                }
                for x in 0..<childCountInRoom3 {
                    var aSt = PassengerStruct()
                    aSt.title = "Mstr"
                    aSt.age = "\(theGuestAndRoomDetailsArr[2].ageArr[x].age!)"
                    passengerDetailStructArr.append(aSt)
                }
            }else if i == 3 {
                adultCountInRoom4 = self.theGuestAndRoomDetailsArr[3].noOfAdult
                childCountInRoom4 = self.theGuestAndRoomDetailsArr[3].noOfChildren
                totalGuestInRoom4 = adultCountInRoom4 + childCountInRoom4
                
                for _ in 0..<adultCountInRoom4 {
                    var aSt = PassengerStruct()
                    aSt.title = "Mr"
                    aSt.age = "0"
                    passengerDetailStructArr.append(aSt)
                }
                for x in 0..<childCountInRoom4 {
                    var aSt = PassengerStruct()
                    aSt.title = "Mstr"
                    aSt.age = "\(theGuestAndRoomDetailsArr[3].ageArr[x].age!)"
                    passengerDetailStructArr.append(aSt)
                }
            }
            //            adultCountArr = self.theGuestAndRoomDetailsArr[i].noOfAdult
        }
        
        if previouslySelectedPassengerDetailStructArr.count > 0 {
            arrayCount = previouslySelectedPassengerDetailStructArr.count
            self.passengerDetailStructArr = previouslySelectedPassengerDetailStructArr
        }else{
            let a = Int(self.theInputDict["Adult"]!)
            let b = Int(self.theInputDict["Child"]!)
            arrayCount = a! + b!
            
            /*
            for i in 0..<arrayCount{
                var aSt = PassengerStruct()
                aSt.title = "Mr"
//                aSt.roomNo = self.theGuestAndRoomDetailsArr[i].roomNo
                passengerDetailStructArr.append(aSt)
            } */
        }

     
        print("self.passengerDetailStructArr = ", self.passengerDetailStructArr)
         myTV.tableFooterView = UIView(frame: CGRect(origin: CGPoint.zero, size: CGSize(width: self.view.frame.size.width, height: self.view.frame.size.height/2)))
        myTV.reloadData()
    }
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        self.doneBtn.layer.cornerRadius = 5
        self.doneBtn.layer.masksToBounds = true
    }

    @IBAction func backBtnTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
//        self.DelegateVar.didBackBtnTapped(true, self)
//        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func doneBtnTapped(_ sender: UIButton) {
       print("self.passengerDetailStructArr = ",self.passengerDetailStructArr)
        
        
        
            for i in 0..<self.passengerDetailStructArr.count{
                if let _ = self.passengerDetailStructArr[i].firstName,!self.passengerDetailStructArr[i].firstName.isEmpty {
                    if let _ = self.passengerDetailStructArr[i].lastName,!self.passengerDetailStructArr[i].lastName.isEmpty {
                        print("\(i) struct fine")
                        self.allFilledFlag = true
                    }else{
                        print("No Last Name")
                        self.allFilledFlag = false
                        self.view.ShowBlackTostWithText(message: "Please provide Guest \(i + 1) LastName", Interval: 3)
                        break
                    }
                }else{
                    print("No First Name")
                    self.allFilledFlag = false
                    self.view.ShowBlackTostWithText(message: "Please provide Guest \(i + 1) FirstName", Interval: 3)
                    break
                }
            }
       
        if allFilledFlag {
            print("All Filled....")
//            DelegateVar.didDoneBtnTapped(self.passengerDetailStructArr,true,self)
            DelegateVar.didDoneBtnTapped(self.passengerDetailStructArr, true, self)
        }
    }
    
  

}
extension PassengerDetailsVC : UITextFieldDelegate{

    func textFieldDidBeginEditing(_ textField: UITextField) {
        let selectedindexPath = IndexPath(row: textField.tag, section: 0)
        self.myTV.scrollToRow(at: selectedindexPath, at: .top, animated: true)
//        print("THe Row to move up =",selectedindexPath.row)
        
//        if selectedindexPath.row == self.arrayCount || selectedindexPath.row == (self.arrayCount-1){
//            myTV.tableFooterView = UIView(frame: CGRect(origin: CGPoint.zero, size: CGSize(width: self.view.frame.size.width, height: self.view.frame.size.height)))
//        }else{
//            myTV.tableFooterView = nil
//        }
//        myTV.reloadData()
        
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {

        let selectedindexPath = IndexPath(row: textField.tag, section: 0)
        //some error
        let cell = self.myTV.cellForRow(at: selectedindexPath) as! PassengerCellClass
        
            if textField == cell.firstNameTxtField {
                self.passengerDetailStructArr[textField.tag].firstName = textField.text
            }else if textField == cell.lastNameTxtField {
                self.passengerDetailStructArr[textField.tag].lastName = textField.text
                //            print("lastname textField.text = ",textField.text)
            }else{
                 print("Where is the Control.....PassengerDetailVC")
            }
        
            myTV.reloadData()
//         textField.resignFirstResponder()
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

}

extension PassengerDetailsVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrayCount
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PassengerCellID", for: indexPath) as! PassengerCellClass
        cell.guestLbl.text = "Guest \(indexPath.row + 1)"
    
        if indexPath.row < self.totalGuestInRoom1{
            cell.roomLbl.text = "Room 1"
            self.passengerDetailStructArr[indexPath.row].roomNo = "1"
            
//            cell.mrBtn.setTitle(self.passengerDetailStructArr[indexPath.row].title,for:.normal)
            if (self.passengerDetailStructArr[indexPath.row].title == "Mstr" || self.passengerDetailStructArr[indexPath.row].title == "Miss"){
                cell.masterMissView.isHidden = false
                

            }else{
                cell.masterMissView.isHidden = true

            }
            
            
            
        }else if indexPath.row < (self.totalGuestInRoom1 + self.totalGuestInRoom2){
            cell.roomLbl.text = "Room 2"
            self.passengerDetailStructArr[indexPath.row].roomNo = "2"
            
//            cell.mrBtn.setTitle(self.passengerDetailStructArr[indexPath.row].title,for:.normal)
            if (self.passengerDetailStructArr[indexPath.row].title == "Mstr" || self.passengerDetailStructArr[indexPath.row].title == "Miss"){
                cell.masterMissView.isHidden = false
            }else{
                cell.masterMissView.isHidden = true
            }
        }else if indexPath.row < (self.totalGuestInRoom1 + self.totalGuestInRoom2 + self.totalGuestInRoom3){
            cell.roomLbl.text = "Room 3"
            self.passengerDetailStructArr[indexPath.row].roomNo = "3"
            
//            cell.mrBtn.setTitle(self.passengerDetailStructArr[indexPath.row].title,for:.normal)
            if (self.passengerDetailStructArr[indexPath.row].title == "Mstr" || self.passengerDetailStructArr[indexPath.row].title == "Miss"){
                cell.masterMissView.isHidden = false
            }else{
                cell.masterMissView.isHidden = true
            }
        }else if indexPath.row < (self.totalGuestInRoom1 + self.totalGuestInRoom2 + self.totalGuestInRoom3 + self.totalGuestInRoom4){
            cell.roomLbl.text = "Room 4"
            self.passengerDetailStructArr[indexPath.row].roomNo = "4"
            
//            cell.mrBtn.setTitle(self.passengerDetailStructArr[indexPath.row].title,for:.normal)
            if (self.passengerDetailStructArr[indexPath.row].title == "Mstr" || self.passengerDetailStructArr[indexPath.row].title == "Miss"){
                cell.masterMissView.isHidden = false
            }else{
                cell.masterMissView.isHidden = true
            }
        }
        
//        if "\(cell.mrBtn.title)" == "Mstr" {
//            cell.mrsBtn.isHidden = true
//        }else{
//            cell.mrsBtn.isHidden = false
//        }
        
        cell.firstNameTxtField.delegate = self
        cell.lastNameTxtField.delegate = self
        
        cell.firstNameTxtField.tag = indexPath.row
        cell.lastNameTxtField.tag = indexPath.row

        //Data fill code
        cell.firstNameTxtField.text = "RMK"
        cell.lastNameTxtField.text = "test"
        
        
        
        
        var firstNameTxt = ""
        if self.passengerDetailStructArr[indexPath.row].firstName != nil{
            firstNameTxt = self.passengerDetailStructArr[indexPath.row].firstName
        }
        cell.configure(textField:cell.firstNameTxtField,text : firstNameTxt ,placeHolder : "Provide First Name")
        
        var lastNameTxt = ""
        if self.passengerDetailStructArr[indexPath.row].lastName != nil{
            lastNameTxt = self.passengerDetailStructArr[indexPath.row].lastName
        }
        cell.configure(textField:cell.lastNameTxtField, text : lastNameTxt,placeHolder : "Provide Last Name")

        
        
        if self.passengerDetailStructArr[indexPath.row].title == "Mstr" {
                cell.mstrBtn.setImage(self.titleSelectedImg, for: .normal)
                cell.missBtn.setImage(self.titleUnselectedImg, for: .normal)
        }else if self.passengerDetailStructArr[indexPath.row].title == "Miss" {
                cell.missBtn.setImage(self.titleSelectedImg, for: .normal)
                cell.mstrBtn.setImage(self.titleUnselectedImg, for: .normal)
        }else if self.passengerDetailStructArr[indexPath.row].title == "Mr" {
                cell.mrBtn.setImage(self.titleSelectedImg, for: .normal)
                cell.msBtn.setImage(self.titleUnselectedImg, for: .normal)
                cell.mrsBtn.setImage(self.titleUnselectedImg, for: .normal)
        }else if self.passengerDetailStructArr[indexPath.row].title == "Ms" {
                cell.mrBtn.setImage(self.titleUnselectedImg, for: .normal)
                cell.msBtn.setImage(self.titleSelectedImg, for: .normal)
                cell.mrsBtn.setImage(self.titleUnselectedImg, for: .normal)
        }else if self.passengerDetailStructArr[indexPath.row].title == "Mrs" {
                cell.mrBtn.setImage(self.titleUnselectedImg, for: .normal)
                cell.msBtn.setImage(self.titleUnselectedImg, for: .normal)
                cell.mrsBtn.setImage(self.titleSelectedImg, for: .normal)
        }
       
        
        cell.mrBtn.addTarget(self, action: #selector(self.mrBtnTapped), for: .touchUpInside)
        cell.mrBtn.tag = indexPath.row
        
        cell.msBtn.addTarget(self, action: #selector(self.msBtnTapped), for: .touchUpInside)
        cell.msBtn.tag = indexPath.row
        
        cell.mrsBtn.addTarget(self, action: #selector(self.mrsBtnTapped), for: .touchUpInside)
        cell.mrsBtn.tag = indexPath.row
        
        cell.mstrBtn.addTarget(self, action: #selector(self.mstrBtnTapped), for: .touchUpInside)
        cell.mstrBtn.tag = indexPath.row
        
        cell.missBtn.addTarget(self, action: #selector(self.missBtnTapped), for: .touchUpInside)
        cell.missBtn.tag = indexPath.row
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 165
    }
    
    @objc func mrBtnTapped (_sender : UIButton ){
        print("mr btn tapped , \(_sender.tag)")
        
        self.passengerDetailStructArr[_sender.tag].title = "Mr"
        self.myTV.reloadData()
        print("self.passengerDetailStructArr = ",self.passengerDetailStructArr)
        let selectedindexPath = IndexPath(row: _sender.tag, section: 0)
        self.myTV.scrollToRow(at: selectedindexPath, at: .top, animated: true)
    }
    @objc func msBtnTapped (_sender : UIButton ){
        print("ms btn tapped, \(_sender.tag)")
        let selectedindexPath = IndexPath(row: _sender.tag, section: 0)
        self.myTV.scrollToRow(at: selectedindexPath, at: .top, animated: true)
        self.passengerDetailStructArr[_sender.tag].title = "Ms"
        self.myTV.reloadData()
        print("self.passengerDetailStructArr = ",self.passengerDetailStructArr)
        
    }
    @objc func mrsBtnTapped (_sender : UIButton ){
        print("mrs btn tapped, \(_sender.tag)")
        let selectedindexPath = IndexPath(row: _sender.tag, section: 0)
        self.myTV.scrollToRow(at: selectedindexPath, at: .top, animated: true)
        self.passengerDetailStructArr[_sender.tag].title = "Mrs"
        self.myTV.reloadData()
        print("self.passengerDetailStructArr = ",self.passengerDetailStructArr)
    }
    @objc func mstrBtnTapped (_sender : UIButton ){
        print("mstr btn tapped, \(_sender.tag)")
        let selectedindexPath = IndexPath(row: _sender.tag, section: 0)
        self.myTV.scrollToRow(at: selectedindexPath, at: .top, animated: true)
        self.passengerDetailStructArr[_sender.tag].title = "Mstr"
        self.myTV.reloadData()
        print("self.passengerDetailStructArr = ",self.passengerDetailStructArr)
    }
    @objc func missBtnTapped (_sender : UIButton ){
        print("miss btn tapped, \(_sender.tag)")
        let selectedindexPath = IndexPath(row: _sender.tag, section: 0)
        self.myTV.scrollToRow(at: selectedindexPath, at: .top, animated: true)
        self.passengerDetailStructArr[_sender.tag].title = "Miss"
        self.myTV.reloadData()
        print("self.passengerDetailStructArr = ",self.passengerDetailStructArr)
    }
   
}
class PassengerCellClass : UITableViewCell {
    @IBOutlet weak var mrBtn: UIButton!
    @IBOutlet weak var msBtn: UIButton!
    @IBOutlet weak var mrsBtn: UIButton!
    @IBOutlet weak var firstNameTxtField: UITextField!
    @IBOutlet weak var lastNameTxtField: UITextField!
    @IBOutlet weak var guestLbl: UILabel!
    @IBOutlet weak var roomLbl: UILabel!

    @IBOutlet weak var guestHeaderView: UIView!
 
    func configure(textField :UITextField, text :String ,placeHolder : String){
        if textField == firstNameTxtField {
            firstNameTxtField.text = text
            firstNameTxtField.placeholder = placeHolder
        }
        if textField == lastNameTxtField {
            lastNameTxtField.text = text
            lastNameTxtField.placeholder = placeHolder
        }
    }
    
    @IBOutlet weak var masterMissView: UIView!
    @IBOutlet weak var mstrBtn: UIButton!
    @IBOutlet weak var missBtn: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
     
    }
    
}
