//
//  HotelResultVC.swift
//  UniOrient
//
//  Created by APPLE on 04/04/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit
//import EDStarRating
import SDWebImage

class HotelResultVC: UIViewController {

    @IBOutlet weak var loadingView: UIView!
    @IBOutlet weak var gif1: UIImageView!
    @IBOutlet weak var gif2: UIImageView!
    @IBOutlet weak var gif3: UIImageView!
    @IBOutlet weak var gif4: UIImageView!
    @IBOutlet weak var gif5: UIImageView!
    
    @IBOutlet weak var topBar: UIView!
    @IBOutlet weak var titleLbl: UILabel!
    
    var inputDict = [String:String]()
    var theDateData : DateSelectedStruct!
    var guestAndRoomDetailsArr = [RoomStruct]()
    
    var noOfNights : String!
    var supplierArr : [String]!
    
    @IBOutlet weak var dataTVContainerView: UIView!
    @IBOutlet weak var errorLbl: UILabel!
    
    @IBOutlet weak var myTV: UITableView!
    var serviceCallCompletedCount : Int!
    
    var hotelResultArr = [HotelStruct]()
    var arrToDisplay = [HotelStruct]()
    
    @IBOutlet weak var hotelBtn: UIButton!
    @IBOutlet weak var ratingBtn: UIButton!
    @IBOutlet weak var priceBtn: UIButton!
    
    @IBOutlet weak var hotelBtnImgView: UIImageView!
    @IBOutlet weak var ratingBtnImgView: UIImageView!
    @IBOutlet weak var priceBtnImgView: UIImageView!
    
    let upArrowImg = UIImage.init(named: "upArrowVioletForSorting")
//    let downArrowImg = UIImage.init(named: "downArrowVioletForSorting")
    
    
    @IBAction func hotelBtnTapped(_ sender: UIButton) {
        
        
        ratingBtnImgView.image = nil
        priceBtnImgView.image = .none
        
        ratingBtn.isSelected = false
        priceBtn.isSelected = false
        
        if !sender.isSelected {
            if hotelBtnImgView.image == nil{
                hotelBtnImgView.image = upArrowImg
            }
            rotate(imgView: hotelBtnImgView)
            sender.isSelected = true
            
            self.arrToDisplay.sort { (hotelStruct1, hotelStruct2) -> Bool in
                return hotelStruct1.HotelName > hotelStruct2.HotelName
            }
        }else{
//            hotelBtnImgView.image = upArrowImg
            sender.isSelected = false
            reRotate(imgView: hotelBtnImgView)
            self.arrToDisplay.sort { (hotelStruct1, hotelStruct2) -> Bool in
                return hotelStruct1.HotelName < hotelStruct2.HotelName
            }
        }
        myTV.reloadData()
        let indexPath = NSIndexPath(row: 0, section: 0)
        self.myTV.scrollToRow(at: indexPath as IndexPath, at: .top, animated: true)
    }

    
    
    @IBAction func ratingBtnTapped(_ sender: UIButton) {
        
        hotelBtnImgView.image = nil
        priceBtnImgView.image = .none
        
        hotelBtn.isSelected = false
        priceBtn.isSelected = false
        
        if !sender.isSelected {
            if ratingBtnImgView.image == nil {
                ratingBtnImgView.image = upArrowImg
            }
            rotate(imgView: ratingBtnImgView)
            sender.isSelected = true
            
            self.arrToDisplay.sort { (hotelStruct1, hotelStruct2) -> Bool in
                let star0Int :Int = Int(hotelStruct1.StarRating)!
                let star1Int :Int = Int(hotelStruct2.StarRating)!
                return star0Int > star1Int
            }
        }else{
//            ratingBtnImgView.image = upArrowImg
            sender.isSelected = false
            reRotate(imgView: ratingBtnImgView)
            
            self.arrToDisplay.sort { (hotelStruct1, hotelStruct2) -> Bool in
                let star0Int :Int = Int(hotelStruct1.StarRating)!
                let star1Int :Int = Int(hotelStruct2.StarRating)!
                return star0Int < star1Int
            }
            
        }
        myTV.reloadData()
        let indexPath = NSIndexPath(row: 0, section: 0)
        self.myTV.scrollToRow(at: indexPath as IndexPath, at: .top, animated: true)
    }
    @IBAction func priceBtnTapped(_ sender: UIButton) {
        hotelBtnImgView.image = nil
        ratingBtnImgView.image = .none
        
        hotelBtn.isSelected = false
        ratingBtn.isSelected = false
        
        if !sender.isSelected {
            sender.isSelected = true
            if priceBtnImgView.image == nil{
                priceBtnImgView.image = upArrowImg
            }
            rotate(imgView: priceBtnImgView)
            
            
            
            self.arrToDisplay.sort{ (hotelStruct1,hotelStruct2) -> Bool in
                let amount0 : Double = Double(hotelStruct1.DispTotalAmount)!
                let amount1 : Double = Double(hotelStruct2.DispTotalAmount)!
                return amount0 > amount1
            }
            
        }else{
            sender.isSelected = false
//            priceBtnImgView.image = upArrowImg
            reRotate(imgView: priceBtnImgView)
            
            
            self.arrToDisplay.sort{ (hotelStruct1,hotelStruct2) -> Bool in
                let amount0 : Double = Double(hotelStruct1.DispTotalAmount)!
                let amount1 : Double = Double(hotelStruct2.DispTotalAmount)!
                return amount0 < amount1
            }
        }
        
        myTV.reloadData()
        let indexPath = NSIndexPath(row: 0, section: 0)
        self.myTV.scrollToRow(at: indexPath as IndexPath, at: .top, animated: true)
    }
    
        func rotate(imgView : UIImageView){
            /*
            let rotationAnimation = CABasicAnimation(keyPath: "transform.rotation")
            rotationAnimation.fromValue = 0.0
            rotationAnimation.toValue = M_PI
            rotationAnimation.duration = 1.0
    
            imgView.layer.add(rotationAnimation, forKey: nil) */
            
            
            /*
            let rotation: CABasicAnimation = CABasicAnimation(keyPath: "transform.rotation.z")
            rotation.toValue = Double.pi  // * 2
            rotation.duration = 0.25 // or however long you want ...
            rotation.isCumulative = true
            rotation.repeatCount = 1 //Float.greatestFiniteMagnitude
            imgView.layer.add(rotation, forKey: "rotationAnimation") */
            
            UIView.animate(withDuration: 0.5) {
                imgView.transform = CGAffineTransform(rotationAngle: .pi)
            }
            
            
        }
    func reRotate(imgView : UIImageView){
        UIView.animate(withDuration: 0.5) {
            imgView.transform = CGAffineTransform.identity
        }
    }
    
    var userSelectedFiltersArr = [HotelUserSelectedFiltersStruct]()
    var filteredArr = [HotelStruct]()
    var hotelFilterArrToFilterVC = [HotelFilterStruct]()
    
    @IBAction func filterBtnTapped(_ sender: UIButton) {
//        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "FilterVCSBID") as! FilterVC
//        self.present(ctrl, animated: true, completion: nil)
        
        
        hotelFilterArrToFilterVC.removeAll()
        
        for aStruct in self.hotelResultArr {
            var aSt = HotelFilterStruct()
            aSt.hotelName = aStruct.HotelName
            aSt.isSelectedAh = false
            //            aSt.setIsSelected(x: false)
            hotelFilterArrToFilterVC.append(aSt)
        }
        
        
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "FilterVCSBID") as! FilterVC
        ctrl.delegateVariable = self
        ctrl.hotelFilterArrToDisplayInFilterVC = hotelFilterArrToFilterVC
        ctrl.previouslySelectedFiltersArr = self.userSelectedFiltersArr
        self.present(ctrl, animated: true, completion: nil)
        
//        self.navigationController?.pushViewController(ctrl, animated: false)
        
    }
    
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        self.serviceCallCompletedCount = 0
    }
    
    let loaderImg = UIImage (named: "loadingHotelGif.gif")
    override func viewDidLoad() {
        super.viewDidLoad()
        print("Git commit test from xcode")
        print("Test")

      self.loadingView.isHidden = false
        gif1.image = loaderImg
        gif2.image = loaderImg
        gif3.image = loaderImg
        gif4.image = loaderImg
        gif5.image = loaderImg
        
        self.topBar.isHidden = true
        
        print("theDateData.checkInDate = ",theDateData.checkInDate)
        self.titleLbl.text = self.inputDict["HotelCity"]
        self.supplierArr = self.inputDict["supplier"]!.components(separatedBy: "|")
        
        self.dataTVContainerView.isHidden = true
        self.errorLbl.isHidden = true
        
        myTV.dataSource = self
        myTV.delegate = self
        myTV.tableFooterView = UIView.init(frame: CGRect.zero)
        
       // showLoading()
        
        for i in 0..<self.supplierArr.count{
            self.inputDict["supplier"] = self.supplierArr[i]
            print("InputDict from For loop:",self.inputDict)
            callSearchHotelService(messageDict: self.inputDict,inputIndex:i)
        }
    }
    
    @IBAction func backBtnTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func callSearchHotelService(messageDict : [String:String],inputIndex : Int){
        if (Reachability()?.isReachable)! {
    
            WebService().HTTP_POST_WebServiceMethod_Hotel(mainURL: WebServicesUrl.HotelServiceUrl, suffix: WebServicesUrl.HotelResult, parameterDict: messageDict) { (ResponseArr, ResponseStatus) in
                
                self.serviceCallCompletedCount += 1
                print("service completed count = ",self.serviceCallCompletedCount)
                
                if ResponseStatus {
                    self.topBar.isHidden = false
                    print("Service call success with supplier ..........",messageDict["supplier"]!)
                   // hideLoading()
                    self.loadingView.isHidden = true
//                    self.filterBtn.isHidden = false
                    
                    self.dataTVContainerView.isHidden = false
                    self.errorLbl.isHidden = true
                    
                    
                    let fullResponseArr = ResponseArr as! [[String:AnyObject]]
                    for aDict in fullResponseArr {
                        var aStruct = HotelStruct()
                        aStruct.NoOfRooms = "\(aDict["NoOfRooms"]!)"
                        aStruct.NoOfNights = "\(aDict["NoOfNights"]!)"
                        aStruct.CheckInDate = "\(aDict["CheckInDate"]!)"
                        aStruct.CheckOutDate = "\(aDict["CheckOutDate"]!)"
                        aStruct.HotelName = "\(aDict["HotelName"]!)"
                        aStruct.ThumbNailImage = "http:\(aDict["ThumbNailImage"]!)"
                        aStruct.Address = "\(aDict["Address"]!)"
                        aStruct.StarRating = "\(aDict["StarRating"]!)"
                        aStruct.RatingImage = "\(aDict["RatingImage"]!)"
                        
//                        aStruct.DispTotalAmount = "\(aDict["DispTotalAmount"]!)"
                        let amount : Float = (aDict["DispTotalAmount"] as! NSNumber).floatValue
                        aStruct.DispTotalAmount = String(format: "%.2f", amount)
                        
                        
                        aStruct.processId = "\(aDict["processId"]!)"
                        aStruct.HotelUniqueKey = "\(aDict["HotelUniqueKey"]!)"
                        aStruct.RoomcategoryCode = "\(aDict["RoomcategoryCode"]!)"
                        aStruct.APIType = "\(aDict["APIType"]!)"
                       
                        if aDict["paxstr"] != nil{
                           aStruct.paxstr = "\(aDict["paxstr"]!)"
                        }else{
                            print ("Pax is not assignd...it is null")
                        }
                        
                        if aDict["Currency"] != nil {
                            aStruct.Currency = "\(aDict["Currency"]!)"
                        }else{
                            print ("Currency is not assignd...it is null")
                        }
                        
                        
                        let tempArr = aDict["dtHotelRate"] as! [[String : AnyObject]]
                        for aRoomDict in tempArr {
                            var aRoomStruct = RoomDetailStruct()
                            aRoomStruct.RoomDescription =  "\(aRoomDict["RoomDescription"]!)"
                            aRoomStruct.inclusions = "\(aRoomDict["inclusions"]!)"
                            aRoomStruct.TotalAmount = "\(aRoomDict["TotalAmount"]!)"
                            aRoomStruct.Cancellationpolicy = "\(aRoomDict["Cancellationpolicy"]!)"
                            
//                            aRoomStruct.BaseFareAmount = "\(aRoomDict["BaseFareAmount"]!)"
                            let BFAmount : Float = Float("\(aRoomDict["BaseFareAmount"]!)")!
                            aRoomStruct.BaseFareAmount = String(format:"%.2f",BFAmount)
                            
                            aRoomStruct.TotalTaxCharges = "\(aRoomDict["TotalTaxCharges"]!)"
                            
//                            aRoomStruct.TotalAmountMarkupWithTax = "\(aRoomDict["TotalAmountMarkupWithTax"]!)"
                            let totalAmount : Float = (aRoomDict["TotalAmountMarkupWithTax"] as! NSNumber).floatValue
                            aRoomStruct.TotalAmountMarkupWithTax = String(format:"%.2f",totalAmount)
                            
                            aRoomStruct.NoOfNights = "\(aRoomDict["NoOfNights"]!)"
                            aRoomStruct.Discount = "\(aRoomDict["Discount"]!)"
                            
                            aRoomStruct.APIType = "\(aRoomDict["APIType"]!)"
                            aRoomStruct.APIAMT = "\(aRoomDict["APIAMT"]!)"
                            aRoomStruct.MarkupAll = "\(aRoomDict["MarkupAll"]!)"
                            aRoomStruct.RoomTypeCode = "\(aRoomDict["RoomTypeCode"]!)"
                            aRoomStruct.RateType = "\(aRoomDict["rateType"]!)"
                            aRoomStruct.RoomBookingCode = "\(aRoomDict["RoomBookingCode"]!)"
                            aRoomStruct.rateComments_Id = "\(aRoomDict["rateComments_Id"]!)"
                            
                            if aDict["bbPrice"] != nil{
                                aRoomStruct.bbPrice = "\(aDict["bbPrice"]!)"
                            }else{
                                print ("bbPrice is not assignd...it is null")
                            }
                            aRoomStruct.RatePlanCode = "\(aRoomDict["RatePlanCode"]!)"
                            
                            aStruct.RoomDetailArr.append(aRoomStruct)
                            
                        }
                        print("hotelResult count :",self.hotelResultArr.count)
                        aStruct.city = "\(self.inputDict["HotelCity"]!)"
                        
                        //                        aStruct.country = "\(self.inputDict["nationality"]!)"
                        
                        self.hotelResultArr.append(aStruct)
                    }
                    self.arrToDisplay = self.hotelResultArr
                    print("Total count :",self.hotelResultArr.count)
                    
                    /*
                    self.arrToDisplay.sort{ (hotelStruct1,hotelStruct2) -> Bool in
                        let amount0 : Double = Double(hotelStruct1.DispTotalAmount)!
                        let amount1 : Double = Double(hotelStruct2.DispTotalAmount)!
                        return amount0 < amount1
                    }
                    self.priceBtnImgView.image = self.upArrowImg */
                    
                    
                    self.arrToDisplay.sort { (hotelStruct1, hotelStruct2) -> Bool in
                        return hotelStruct1.HotelName < hotelStruct2.HotelName
                    }
                    self.hotelBtnImgView.image = self.upArrowImg
                    
                    self.myTV.reloadData()
                    
                    
                    if self.serviceCallCompletedCount == self.supplierArr.count{
                        if self.hotelResultArr.count == 0 {
                            self.dataTVContainerView.isHidden = true
                            self.errorLbl.isHidden = false
                            self.errorLbl.text = "No data for your search!!!"
                            hideLoading()
                        }else{
                            print("Hotel Count is not 0")
                            hideLoading()
                        }
                    }
                    
                    
                }else{
                    print("Service call Failure with supplier ..........",messageDict["supplier"]!)
                    if self.serviceCallCompletedCount == (self.supplierArr.count){
                        if self.hotelResultArr.count == 0 {
                            self.dataTVContainerView.isHidden = true
                            self.errorLbl.isHidden = false
                            self.errorLbl.text = "No data for your search!!!"
                            self.topBar.isHidden = true
                            hideLoading()
                        }else{
                            print("Hotel Count is not 0")
                            hideLoading()
                        }
                    }
                }
            }
        }else{
            print("No Internet......")
            self.dataTVContainerView.isHidden = true
            self.errorLbl.isHidden = false
            self.errorLbl.text = "Internet connetivity Problem!!!"
//            self.filterBtn.isHidden = true
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension HotelResultVC : UITableViewDelegate , UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrToDisplay.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:"HotelCellID",for: indexPath) as! HotelCellClass
        cell.hotelNameLbl.text = arrToDisplay[indexPath.row].HotelName
        cell.hotelAddressLbl.text = arrToDisplay[indexPath.row].Address
        
//        let fStr = NSMutableAttributedString()
//        let attribute1 = [NSAttributedStringKey.font : UIFont.boldSystemFont(ofSize: 14)]
//        let xyz = NSAttributedString(string: self.selectedStruct.amount,attributes:attribute1)
//
//        let attribute2 = [NSAttributedStringKey.foregroundColor : hexStringToUIColor(hex: "#338EDF"),NSAttributedStringKey.font : UIFont.boldSystemFont(ofSize: 18)]
//        let abc = NSAttributedString(string: "MYR ", attributes: attribute2)
//
//        fStr.append(abc)
//        //        fStr.append(NSAttributedString(string: "\n"))
//        fStr.append(xyz)
//        self.amountLbl.attributedText = fStr
        
//        cell.amountLbl.attributedText =  formatAmount(amountSymbol: "PHP", amountSymbolFontSize: 12.0, amount: arrToDisplay[indexPath.row].DispTotalAmount,amountColor: "#29266f", amountFontSize: 18.0 )
        cell.amountLbl.text = arrToDisplay[indexPath.row].DispTotalAmount
        
//        cell.RatingView.starImage = UIImage.init(named: "starUnfilled")
        cell.RatingView.starHighlightedImage = UIImage.init(named: "starFilled")
        cell.RatingView.maxRating = 5
        //        cell.RatingView.delegate = self
        cell.RatingView.horizontalMargin = 2
        //        cell.RatingView.editable = false
        cell.RatingView.displayMode = UInt(EDStarRatingDisplayFull)
        let ratingStr = arrToDisplay[indexPath.row].StarRating!
        
        if !ratingStr.isEmpty{
            cell.RatingView.rating = Float(arrToDisplay[indexPath.row].StarRating)!
        }
        
        
        
        /*
         cell.flightNameLbl.text = self.flightResultAndDetailsArr[indexPath.row].detailArrWithFlightDetailStruct[0].operating
         
         cell.flightImgView.sd_setImage(with: URL(string: flightImgURL), placeholderImage: UIImage(named: "flightGreen"),options: SDWebImageOptions(rawValue: 0), completed: { downloadedImage, error, cacheType, imageURL in
         if error == nil{
         self.flightResultAndDetailsArr[indexPath.row].flightImgData = UIImagePNGRepresentation(downloadedImage!)
         }else{
         print("Error from SBWebImage Block = ",error)
         }
         
         }) */
        
        /*
         cell.hotelImgView.sd_setImage(with: URL(string: finalArr[indexPath.row].ThumbNailImage!), placeholderImage: UIImage(named: "hotelGreen"), options: SDWebImageOptions(rawValue: 0),completed: { downloadedImage, error, cacheType, imageURl in
         if error == nil {
         self.finalArr[indexPath.row].hotelImgData = UIImagePNGRepresentaion(downloadedImage)
         }else{
         print("Error from SBWebImage Block to load hotel Image = ",error)
         }
         }) */
        
        /*
         cell.hotelImgView.sd_setImage(with: URL(string: finalArr[indexPath.row].ThumbNailImage!), placeholderImage: UIImage(named: "hotelGreen"), options: SDWebImageOptions(rawValue:0), progress: { (<#Int#>, <#Int#>, <#URL?#>) in
         <#code#>
         }, completed: <#T##SDExternalCompletionBlock?##SDExternalCompletionBlock?##(UIImage?, Error?, SDImageCacheType, URL?) -> Void#>) */
        
        
        if self.arrToDisplay[indexPath.row].hotelImgData != nil {
            cell.hotelImgView.image =  UIImage(data: self.arrToDisplay[indexPath.row].hotelImgData!)
        }else{
            /*
             cell.hotelImgView.sd_setImage(with: URL(string: finalArr[indexPath.row].ThumbNailImage!)) { (downloadedImg, error, cacheType, imgURL) in
             if error == nil {
             self.finalArr[indexPath.row].hotelImgData = UIImagePNGRepresentation(downloadedImg!)
             }else{
             print("Error from SBWebImage Block to load hotel Image = ",error!)
             }
             } */
            
            
            cell.hotelImgView.sd_setShowActivityIndicatorView(true)
            cell.hotelImgView.sd_setIndicatorStyle(.white)
            
            cell.hotelImgView.sd_setImage(with: URL(string: arrToDisplay[indexPath.row].ThumbNailImage!), placeholderImage: UIImage(named: "bedBlack"),options: SDWebImageOptions(rawValue: 0), completed: { downloadedImg, error, cacheType, imageURL in
                if error == nil{
                    self.arrToDisplay[indexPath.row].hotelImgData = downloadedImg!.pngData()
                }else{
                    print("Error from SBWebImage Block to load hotel Image = ",error!)
                }
                
            })
        }
        
        
        
        
        return cell
    }
    
    //    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    //        return UITableViewAutomaticDimension
    //    }
    //
    //    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
    //        return 100
    //    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier:"HotelDetailVCSBID") as! HotelDetailVC
        ctrl.selectedHotelStruct = self.arrToDisplay[indexPath.row]
        ctrl.theInputDict =  inputDict
        ctrl.dateData = self.theDateData
        ctrl.theGuestAndRoomDetailsArr = self.guestAndRoomDetailsArr
        self.navigationController?.pushViewController(ctrl, animated: true)
        
      
    }
}
class HotelCellClass: UITableViewCell {
    
    @IBOutlet weak var hotelImgView: UIImageView!
    @IBOutlet weak var hotelNameLbl: UILabel!
    @IBOutlet weak var hotelAddressLbl: UILabel!
    @IBOutlet weak var addressImgView: UIImageView!
    @IBOutlet weak var amountLbl: UILabel!
    @IBOutlet weak var RatingView: EDStarRating!
    
}
//MARK: - HotelFliterDelegate {
extension HotelResultVC : HotelFilterDelegate{
    func didBackBtnTapped(filterBtnTappedFlag: Bool, controller: FilterVC) {
        //        self.filterBtn.isSelected = filterBtnTappedFlag
//        controller.navigationController?.popViewController(animated: true)
        controller.dismiss(animated: true, completion: nil)
    }
    func didApplyBtnTapped(userSelected: HotelUserSelectedFiltersStruct, controller: FilterVC) {
//        controller.navigationController?.popViewController(animated: true)
        controller.dismiss(animated: true, completion: nil)
        
        self.userSelectedFiltersArr.removeAll()
        self.userSelectedFiltersArr.append(userSelected)
        
        self.filteredArr = self.hotelResultArr.filter({ (aSt) -> Bool in
            var returnStatus : Bool!
            
            
            if userSelected.isOneStar && userSelected.isTwoStar && userSelected.isThreeStar {
                if !userSelected.isFourStar && !userSelected.isFiveStar{
                    
                    returnStatus = (aSt.StarRating == "1" || aSt.StarRating == "2" || aSt.StarRating == "3") ? true : false
                }else if userSelected.isFourStar && !userSelected.isFiveStar{
                    
                    returnStatus = (aSt.StarRating == "1" || aSt.StarRating == "2" || aSt.StarRating == "3" || aSt.StarRating == "4") ? true : false
                    
                }else if !userSelected.isFourStar && userSelected.isFiveStar{
                    
                    returnStatus = (aSt.StarRating == "1" || aSt.StarRating == "2" || aSt.StarRating == "3" || aSt.StarRating == "5") ? true : false
                    
                }else if userSelected.isFourStar && userSelected.isFiveStar{
                    returnStatus = true
                }
            }else if userSelected.isOneStar && userSelected.isTwoStar {
                if !userSelected.isFourStar && !userSelected.isFiveStar{
                    
                    returnStatus = (aSt.StarRating == "1" || aSt.StarRating == "2") ? true : false
                    
                }else if userSelected.isFourStar && !userSelected.isFiveStar{
                    
                    returnStatus = (aSt.StarRating == "1" || aSt.StarRating == "2" || aSt.StarRating == "4") ? true : false
                    
                }else if !userSelected.isFourStar && userSelected.isFiveStar{
                    
                    returnStatus = (aSt.StarRating == "1" || aSt.StarRating == "2" || aSt.StarRating == "5") ? true : false
                    
                }else if userSelected.isFourStar && userSelected.isFiveStar{
                    
                    returnStatus = (aSt.StarRating == "1" || aSt.StarRating == "2" || aSt.StarRating == "4" || aSt.StarRating == "5") ? true : false
                    
                }
            }else if userSelected.isOneStar && userSelected.isThreeStar {
                if !userSelected.isFourStar && !userSelected.isFiveStar{
                    
                    returnStatus = (aSt.StarRating == "1" || aSt.StarRating == "3") ? true : false
                    
                }else if userSelected.isFourStar && !userSelected.isFiveStar{
                    
                    returnStatus = (aSt.StarRating == "1" || aSt.StarRating == "3" || aSt.StarRating == "4") ? true : false
                    
                }else if !userSelected.isFourStar && userSelected.isFiveStar{
                    
                    returnStatus = (aSt.StarRating == "1" || aSt.StarRating == "3" || aSt.StarRating == "5") ? true : false
                    
                }else if userSelected.isFourStar && userSelected.isFiveStar{
                    
                    returnStatus = (aSt.StarRating == "1" || aSt.StarRating == "3" || aSt.StarRating == "4" || aSt.StarRating == "5") ? true : false
                    
                }
            }else if userSelected.isTwoStar && userSelected.isThreeStar {
                if !userSelected.isFourStar && !userSelected.isFiveStar{
                    
                    returnStatus = (aSt.StarRating == "2" || aSt.StarRating == "3") ? true : false
                    
                }else if userSelected.isFourStar && !userSelected.isFiveStar{
                    
                    returnStatus = (aSt.StarRating == "2" || aSt.StarRating == "3" || aSt.StarRating == "4") ? true : false
                    
                }else if !userSelected.isFourStar && userSelected.isFiveStar{
                    
                    returnStatus = (aSt.StarRating == "2" || aSt.StarRating == "3" || aSt.StarRating == "5") ? true : false
                    
                }else if userSelected.isFourStar && userSelected.isFiveStar{
                    
                    returnStatus = (aSt.StarRating == "2" || aSt.StarRating == "3" || aSt.StarRating == "4" || aSt.StarRating == "5") ? true : false
                    
                }
            }else if userSelected.isOneStar {
                if !userSelected.isFourStar && !userSelected.isFiveStar{
                    
                    returnStatus = (aSt.StarRating == "1") ? true : false
                    
                }else if userSelected.isFourStar && !userSelected.isFiveStar{
                    
                    returnStatus = (aSt.StarRating == "1" || aSt.StarRating == "4") ? true : false
                    
                }else if !userSelected.isFourStar && userSelected.isFiveStar{
                    
                    returnStatus = (aSt.StarRating == "1" || aSt.StarRating == "5") ? true : false
                    
                }else if userSelected.isFourStar && userSelected.isFiveStar{
                    
                    returnStatus = (aSt.StarRating == "1" || aSt.StarRating == "4" || aSt.StarRating == "5") ? true : false
                    
                }
            }else if userSelected.isTwoStar {
                if !userSelected.isFourStar && !userSelected.isFiveStar{
                    
                    returnStatus = (aSt.StarRating == "2") ? true : false
                    
                }else if userSelected.isFourStar && !userSelected.isFiveStar{
                    
                    returnStatus = (aSt.StarRating == "2" || aSt.StarRating == "4") ? true : false
                    
                }else if !userSelected.isFourStar && userSelected.isFiveStar{
                    
                    returnStatus = (aSt.StarRating == "2" || aSt.StarRating == "5") ? true : false
                    
                }else if userSelected.isFourStar && userSelected.isFiveStar{
                    
                    returnStatus = (aSt.StarRating == "2" || aSt.StarRating == "4" || aSt.StarRating == "5") ? true : false
                    
                }
            }else if userSelected.isThreeStar {
                if !userSelected.isFourStar && !userSelected.isFiveStar{
                    
                    returnStatus = (aSt.StarRating == "3") ? true : false
                    
                }else if userSelected.isFourStar && !userSelected.isFiveStar{
                    
                    returnStatus = (aSt.StarRating == "3" || aSt.StarRating == "4") ? true : false
                    
                }else if !userSelected.isFourStar && userSelected.isFiveStar{
                    
                    returnStatus = (aSt.StarRating == "3" || aSt.StarRating == "5") ? true : false
                    
                }else if userSelected.isFourStar && userSelected.isFiveStar{
                    
                    returnStatus = (aSt.StarRating == "3" || aSt.StarRating == "4" || aSt.StarRating == "5") ? true : false
                    
                }
            }else {
                if !userSelected.isFourStar && !userSelected.isFiveStar{
                    returnStatus = true
                }else if userSelected.isFourStar && !userSelected.isFiveStar{
                    
                    returnStatus = (aSt.StarRating == "4") ? true : false
                    
                }else if !userSelected.isFourStar && userSelected.isFiveStar{
                    
                    returnStatus = (aSt.StarRating == "5") ? true : false
                    
                }else if userSelected.isFourStar && userSelected.isFiveStar{
                    
                    returnStatus = (aSt.StarRating == "4" || aSt.StarRating == "5") ? true : false
                    
                }
                
            }
            if returnStatus{
                
                let amount : Float = Float(aSt.DispTotalAmount)!
                
                if userSelected.isUpto999 && userSelected.is1000To2999 && userSelected.is3000To4999 {
                    if !userSelected.is5000To9999 && !userSelected.is10000Plus{
                        returnStatus = (amount <= 4999) ? true : false
                    }else if userSelected.is5000To9999 && !userSelected.is10000Plus{
                        returnStatus = (amount <= 9999) ? true : false
                    }else if !userSelected.is5000To9999 && userSelected.is10000Plus{
                        returnStatus = (amount <= 4999 || amount >= 10000) ? true : false
                    }else if userSelected.is5000To9999 && userSelected.is10000Plus{
                        returnStatus = true
                    }
                }else if userSelected.isUpto999 && userSelected.is1000To2999 {
                    if !userSelected.is5000To9999 && !userSelected.is10000Plus{
                        returnStatus = (amount <= 2999) ? true : false
                    }else if userSelected.is5000To9999 && !userSelected.is10000Plus{
                        returnStatus = (amount <= 2999 || (amount >= 5000 && amount <= 9999)) ? true : false
                    }else if !userSelected.is5000To9999 && userSelected.is10000Plus{
                        returnStatus = (amount <= 2999 || amount >= 10000) ? true : false
                    }else if userSelected.is5000To9999 && userSelected.is10000Plus{
                        returnStatus = (amount <= 2999 || amount >= 5000) ? true : false
                    }
                }else if userSelected.isUpto999 && userSelected.is3000To4999 {
                    if !userSelected.is5000To9999 && !userSelected.is10000Plus{
                        returnStatus = (amount <= 999 || (amount >= 3000 && amount <= 4999)) ? true : false
                    }else if userSelected.is5000To9999 && !userSelected.is10000Plus{
                        returnStatus = (amount <= 999 || (amount >= 3000 && amount <= 9999)) ? true : false
                    }else if !userSelected.is5000To9999 && userSelected.is10000Plus{
                        returnStatus = (amount <= 999 || (amount >= 3000 && amount <= 4999) || amount >= 10000) ? true : false
                    }else if userSelected.is5000To9999 && userSelected.is10000Plus{
                        returnStatus = (amount <= 999 || amount >= 3000) ? true : false
                    }
                }else if userSelected.is1000To2999 && userSelected.is3000To4999 {
                    if !userSelected.is5000To9999 && !userSelected.is10000Plus{
                        
                        returnStatus = (amount >= 1000 && amount <= 4999) ? true : false
                        
                    }else if userSelected.is5000To9999 && !userSelected.is10000Plus{
                        
                        returnStatus = (amount >= 1000 && amount <= 9999) ? true : false
                        
                    }else if !userSelected.is5000To9999 && userSelected.is10000Plus{
                        
                        returnStatus = (amount >= 1000 && amount <= 4999) || (amount >= 10000) ? true : false
                        
                    }else if userSelected.is5000To9999 && userSelected.is10000Plus{
                        
                        returnStatus = (amount >= 1000)  ? true : false
                        
                    }
                }else if userSelected.isUpto999 {
                    if !userSelected.is5000To9999 && !userSelected.is10000Plus{
                        
                        returnStatus = (amount <= 999) ? true : false
                        
                    }else if userSelected.is5000To9999 && !userSelected.is10000Plus{
                        
                        returnStatus = (amount <= 999) || (amount >= 5000 && amount <= 9999) ? true : false
                        
                    }else if !userSelected.is5000To9999 && userSelected.is10000Plus{
                        
                        returnStatus = (amount <= 999) || (amount >= 10000) ? true : false
                        
                    }else if userSelected.is5000To9999 && userSelected.is10000Plus{
                        
                        returnStatus = (amount <= 999) || (amount >= 5000) ? true : false
                        
                    }
                }else if userSelected.is1000To2999 {
                    if !userSelected.is5000To9999 && !userSelected.is10000Plus{
                        
                        returnStatus = (amount >= 1000 && amount <= 2999) ? true : false
                        
                    }else if userSelected.is5000To9999 && !userSelected.is10000Plus{
                        
                        returnStatus = (amount >= 1000 && amount <= 2999) || (amount >= 5000 && amount <= 9999) ? true : false
                        
                    }else if !userSelected.is5000To9999 && userSelected.is10000Plus{
                        
                        returnStatus = (amount >= 1000 && amount <= 2999) || (amount > 10000) ? true : false
                        
                    }else if userSelected.is5000To9999 && userSelected.is10000Plus{
                        
                        returnStatus = (amount >= 1000 && amount <= 2999) || (amount > 5000) ? true : false
                        
                    }
                }else if userSelected.is3000To4999 {
                    if !userSelected.is5000To9999 && !userSelected.is10000Plus{
                        
                        returnStatus = (amount >= 3000 && amount <= 4999) ? true : false
                        
                    }else if userSelected.is5000To9999 && !userSelected.is10000Plus{
                        
                        returnStatus = (amount >= 3000 && amount <= 4999) || (amount >= 5000 && amount <= 9999) ? true : false
                        
                    }else if !userSelected.is5000To9999 && userSelected.is10000Plus{
                        
                        returnStatus = (amount >= 3000 && amount <= 4999) || (amount >= 10000) ? true : false
                        
                    }else if userSelected.is5000To9999 && userSelected.is10000Plus{
                        returnStatus = amount >= 3000 ? true : false
                    }
                }else {
                    if !userSelected.is5000To9999 && !userSelected.is10000Plus{
                        returnStatus = true
                    }else if userSelected.is5000To9999 && !userSelected.is10000Plus{
                        
                        returnStatus = (amount >= 5000 && amount <= 9999) ? true : false
                        
                    }else if !userSelected.is5000To9999 && userSelected.is10000Plus{
                        
                        returnStatus = (amount >= 10000) ? true : false
                        
                        
                    }else if userSelected.is5000To9999 && userSelected.is10000Plus{
                        
                        returnStatus = amount >= 5000 ? true : false
                        
                    }
                    
                }
                
                
                
                
                return returnStatus
            }else{
                return false
            }
        })
        
        print("Filtered Arr Count :",self.filteredArr.count)
        self.arrToDisplay = self.filteredArr
        self.myTV.reloadData()
        if self.filteredArr.count == 0 {
            self.view.ShowBlackTostWithText(message: "No Result for your filter!!!", Interval: 2)
            self.dataTVContainerView.isHidden = true
            self.errorLbl.text = "No Result for your filter!!!"
        }else{
            self.dataTVContainerView.isHidden = false
        }
    }
}
