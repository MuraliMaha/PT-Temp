//
//  HotelDateSelectionVC.swift
//  UniOrient
//
//  Created by APPLE on 02/04/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit


protocol DateSelectionProcol {
//    func didConfirmBtnTapped(selectedDateStringsDict : [String?:String?] ,controller : HotelDateSelectionVC)
    func didConfirmBtnTapped(selectedDateDict : [String? : Date?],noOfNightsStr : String?,noOfNightsInt : Int?, controller : HotelDateSelectionVC)
}

class HotelDateSelectionVC: UIViewController {

    var delegateVariable : DateSelectionProcol!
    var theSelectedData : DateSelectedStruct!
    
    @IBOutlet weak var myCalenderContainerView: UIView!
    @IBOutlet weak var myCalenderView: FSCalendar!
    @IBOutlet weak var bottomView : UIView!
    @IBOutlet weak var checkInDateLbl: UILabel!
    @IBOutlet weak var checkOutDateLbl: UILabel!
    
//    var selectedCheckinDateStr : String!
//    var selectedCheckoutDateStr = "Nothing"
  
    var dateDisplayFormat = DateFormatter()

    
//    var inputParameterDateFormatterHotel = DateFormatter()
//    var selectedCheckinStrToPass : String!
//    var selectedCheckoutStrToPass : String!
    
    @IBOutlet weak var nightView: UIView!
    @IBOutlet weak var noOfNightsLbl: UILabel!
    var noOfNight : Int!
    
//    var oneDay : Double!
//    var nextDay : Date!
    
    var selectedCheckinDate : Date!
    var selectedCheckoutDate : Date!
    
    @IBOutlet weak var confirmBtn: UIButton!
    
    
    var firstDate: Date?
    var lastDate: Date?
    var datesRange: [Date]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.myCalenderView.delegate = self
        self.myCalenderView.dataSource = self
        self.myCalenderView.allowsMultipleSelection = true
        self.myCalenderView.scrollDirection = .vertical
        dateDisplayFormat.dateFormat = "E, d MMM"
        
        
//        self.checkinDateLbl.attributedText = formatDate(dateString: dateDisplayFormat.string(from: Date()))
        
//        self.checkInDateLbl.text = theSelectedData.checkInDateStr
        self.checkInDateLbl.attributedText = formatDate(dateString: dateDisplayFormat.string(from: theSelectedData.checkInDate))
        
//        self.checkOutDateLbl.text = theSelectedData.checkOutDateStr
        self.checkOutDateLbl.attributedText = formatDate(dateString: dateDisplayFormat.string(from: theSelectedData.checkOutDate))
        
        self.noOfNight = theSelectedData.noOfNightsInt
        self.noOfNightsLbl.text = theSelectedData.noOfNightsStr
//        self.selectedCheckinDate = dateDisplayFormat.date(from: theSelectedData.checkInDateStr)
//        self.selectedCheckoutDate = dateDisplayFormat.date(from: theSelectedData.checkOutDateStr)
        self.selectedCheckinDate = theSelectedData.checkInDate
        self.selectedCheckoutDate = theSelectedData.checkOutDate
        
        let range = datesRange(from: self.selectedCheckinDate, to: self.selectedCheckoutDate)
        for d in range {
            myCalenderView.select(d)
        }
        datesRange = range
        
        firstDate = range.first
        lastDate = range.last
       
        
        

//        self.oneDay = 60 * 60 * 24
//        self.nextDay = Date().addingTimeInterval(oneDay)
        
        
//        self.checkInDateLbl.text = dateDisplayFormat.string(from: Date())
//        self.checkOutDateLbl.text = dateDisplayFormat.string(from: nextDay)

        
        
        
//        self.selectedCheckinDate = Date()
//        self.selectedCheckoutDate = nextDay
        
//        self.noOfNight = 1
//        self.noOfNightsLbl.text = "1 Night"
      
       
        
//        self.myCalenderView.select(Date())
//        self.myCalenderView.select(nextDay)
//        firstDate = Date()
//        lastDate = nextDay
//        Calendar.current.date(byAdding: .day, value: 1, to: tempDate)!
    }
    override func viewWillLayoutSubviews() {
        self.nightView.layer.cornerRadius = self.nightView.frame.height / 2.0
        //        self.nightView.clipsToBounds = true
        self.nightView.layer.masksToBounds = true
        self.nightView.backgroundColor = hexStringToUIColor(hex: "#100055")
        
        self.confirmBtn.layer.cornerRadius = 5
        self.confirmBtn.layer.masksToBounds = true
    }
    @IBAction func backBtnTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }

    @IBAction func confirmBtnTapped(_ sender: UIButton) {
        if firstDate != nil && lastDate != nil {
            
            
            let strDict : [String:Date] = ["checkInDate":firstDate!,"checkOutDate":lastDate!]
//            delegateVariable.didConfirmBtnTapped(selectedDateStringsDict: strDict , controller: self)
//            delegateVariable.didConfirmBtnTapped(selectedDateStringsDict: strDict, controller: self)
            delegateVariable.didConfirmBtnTapped(selectedDateDict: strDict,noOfNightsStr:self.noOfNightsLbl.text!,noOfNightsInt: self.noOfNight, controller: self)
        }else{
            print("Date Missing..")
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension HotelDateSelectionVC : FSCalendarDelegate,FSCalendarDataSource,FSCalendarDelegateAppearance {
    func minimumDate(for calendar: FSCalendar) -> Date {
        
        /*
      else{
            if calendarFlagHotel == "checkinCalender" {
                return Date()
            }else{
                return self.selectedCheckinDate.addingTimeInterval(oneDay)
            }
        } */
        
        return Date()
    }
    
//    func calendar(_ calendar: FSCalendar, appearance: FSCalendarAppearance, titleSelectionColorFor date: Date) -> UIColor? {
//        calendar.deselect(date)
//        return UIColor.green
//    }
    
    func calendar(_ calendar: FSCalendar, willDisplay cell: FSCalendarCell, for date: Date, at monthPosition: FSCalendarMonthPosition) {
        calendar.appearance.titleTodayColor = UIColor.red
    }
    
    
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        // nothing selected:
        if firstDate == nil {
            firstDate = date
            datesRange = [firstDate!]
            
            print("datesRange contains: \(datesRange!)")
//            self.checkInDateLbl.text =  self.dateDisplayFormat.string(from: firstDate!)
            self.checkInDateLbl.attributedText = formatDate(dateString: dateDisplayFormat.string(from: firstDate!))

//            self.checkOutDateLbl.text = "Select a Date"
            self.checkOutDateLbl.attributedText = formatDate(dateString: "Select a Date")
            self.nightView.isHidden = true
            self.confirmBtn.isEnabled = false
            self.confirmBtn.isUserInteractionEnabled = false
            return
        }
        
        // only first date is selected:
        if firstDate != nil && lastDate == nil {
            // handle the case of if the last date is less than the first date:
            if date <= firstDate! {
                calendar.deselect(firstDate!)
                firstDate = date
                datesRange = [firstDate!]
                
                print("datesRange contains: \(datesRange!)")
//                self.checkInDateLbl.text =  self.dateDisplayFormat.string(from: firstDate!)
                  self.checkInDateLbl.attributedText = formatDate(dateString: dateDisplayFormat.string(from: firstDate!))
                return
            }
            
            let range = datesRange(from: firstDate!, to: date)
            lastDate = range.last
            
            for d in range {
                calendar.select(d)
            }
            
            datesRange = range
            
            print("datesRange contains: \(datesRange!)")
//            self.checkOutDateLbl.text = self.dateDisplayFormat.string(from: lastDate!)
            self.checkOutDateLbl.attributedText = formatDate(dateString: dateDisplayFormat.string(from: lastDate!))
            
            self.nightView.isHidden = false
            self.confirmBtn.isEnabled = true
            self.confirmBtn.isUserInteractionEnabled = true
            self.noOfNight = (datesRange?.count)! - 1
            if self.noOfNight > 1{
                self.noOfNightsLbl.text = "\(self.noOfNight!) Nights"
            }else{
                self.noOfNightsLbl.text = "\(self.noOfNight!) Night"
            }
            
            
            
            return
        }
        
        // both are selected:
        if firstDate != nil && lastDate != nil {
            for d in calendar.selectedDates {
                calendar.deselect(d)
            }
            
            lastDate = nil
            firstDate = date
            
            datesRange = [firstDate!]
            calendar.select(firstDate!)
            print("datesRange contains: \(datesRange!)")
            
//            self.checkInDateLbl.text =  self.dateDisplayFormat.string(from: firstDate!)
            self.checkInDateLbl.attributedText = formatDate(dateString: dateDisplayFormat.string(from: firstDate!))
//            self.checkOutDateLbl.text = "Select a Date"
            self.checkOutDateLbl.attributedText = formatDate(dateString: "Select a Date")
//            self.noOfNight = datesRange?.count - 1
            self.nightView.isHidden = true
            self.confirmBtn.isEnabled = false
            self.confirmBtn.isUserInteractionEnabled = false
        }
    }
    
    func calendar(_ calendar: FSCalendar, didDeselect date: Date, at monthPosition: FSCalendarMonthPosition) {
        // both are selected:
        
        // NOTE: the is a REDUANDENT CODE:
        if firstDate != nil && lastDate != nil {
            for d in calendar.selectedDates {
                calendar.deselect(d)
            }
            
            lastDate = nil
            firstDate = nil
            
            datesRange = []
            print("datesRange contains: \(datesRange!)")
            
//            self.checkInDateLbl.text = "Select a Date"
            self.checkInDateLbl.attributedText = formatDate(dateString: "Select a Date")
//            self.checkOutDateLbl.text = "Select a Date"
            self.checkOutDateLbl.attributedText = formatDate(dateString: "Select a Date")
            self.noOfNight = datesRange?.count
            self.nightView.isHidden = true
            self.confirmBtn.isEnabled = false
            self.confirmBtn.isUserInteractionEnabled = false
        }
    }
    func datesRange(from: Date, to: Date) -> [Date] {
        // in case of the "from" date is more than "to" date,
        // it should returns an empty array:
        if from > to { return [Date]() }
        
        var tempDate = from
        var array = [tempDate]
        
        while tempDate < to {
            tempDate = Calendar.current.date(byAdding: .day, value: 1, to: tempDate)!
            array.append(tempDate)
        }
        
        return array
    }

    
}
