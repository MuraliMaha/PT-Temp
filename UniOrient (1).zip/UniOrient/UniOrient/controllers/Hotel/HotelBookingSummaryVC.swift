//
//  HotelPaymentVC.swift
//  UniOrient
//
//  Created by APPLE on 23/04/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

class HotelBookingSummaryVC: UIViewController {

    
    var selectedHotelStruct : HotelStruct!
    var theInputDict : [String:String]!
    var dateData : DateSelectedStruct!
    var theSelectedRoomIndex : Int!
    var theGuestAndRoomDetailsArr = [RoomStruct]()
    var apiTransactionInputDict : [String : String]!
    var apiTransactionServiceOutputStruct : APIBookingTransactionStruct!
    var theBookerInfoStruct : BookerInfoStruct!
    var pricingDictOfAPITransaction : [String : Any]!
    var bookingStatusStr : String!
    var theConveinceAmtAddedPrice : String!
    
    @IBOutlet weak var hotelNameLbl: UILabel!
    @IBOutlet weak var addressLbl: UILabel!
    
    var dateDisplayFormat = DateFormatter()
    @IBOutlet weak var dateView: UIView!
    @IBOutlet weak var checkinDateView: UIView!
    @IBOutlet weak var checkinDateLbl: UILabel!
    @IBOutlet weak var checkoutDateView: UIView!
    @IBOutlet weak var checkoutDateLbl: UILabel!
    @IBOutlet weak var nightView: UIView!
    @IBOutlet weak var noOfNightsLbl: UILabel!
    
    
    @IBOutlet weak var bookingStatusLbl: UILabel!
    @IBOutlet weak var transactionIDLbl: UILabel!
    @IBOutlet weak var occupancyLbl: UILabel!
    @IBOutlet weak var roomTypeLbl: UILabel!
    @IBOutlet weak var roomsLbl: UILabel!
    
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var genderLbl: UILabel!
    @IBOutlet weak var mobileNumberLbl: UILabel!
    @IBOutlet weak var emailLbl: UILabel!
    
    @IBOutlet weak var amountLbl: UILabel!
    
    @IBOutlet weak var homePageBtn: UIButton!
    
    @IBOutlet weak var hotelImgView: UIImageView!
    
    
    var loginDetail : LoginDetails!
    var loginResponse : LoginResponse!
    override func viewDidLoad() {
        super.viewDidLoad()

        if selectedHotelStruct.hotelImgData != nil {
            self.hotelImgView.image =  UIImage(data: self.selectedHotelStruct.hotelImgData!)
        }

        self.hotelNameLbl.text = self.selectedHotelStruct.HotelName
        self.addressLbl.text = self.selectedHotelStruct.Address
        
        dateDisplayFormat.dateFormat = "E, d MMM"
        //        self.checkinDateLbl.text = dateDisplayFormat.string(from: Date())
        self.checkinDateLbl.attributedText = formatDate(dateString: dateDisplayFormat.string(from: self.dateData.checkInDate))
        self.checkoutDateLbl.attributedText = formatDate(dateString: dateDisplayFormat.string(from: self.dateData.checkOutDate))
        self.noOfNightsLbl.text = self.dateData.noOfNightsStr
        
        self.bookingStatusLbl.text = self.bookingStatusStr
        self.transactionIDLbl.text = self.apiTransactionServiceOutputStruct.TripID
        self.occupancyLbl.text = self.dateData.noOfNightsStr
        self.roomTypeLbl.text = self.selectedHotelStruct.RoomDetailArr[theSelectedRoomIndex].RoomDescription
        self.roomsLbl.text = self.selectedHotelStruct.NoOfRooms
        
        if FetchLoginDetails() != nil {
            loginDetail = FetchLoginDetails()
            loginResponse = FetchLoginResponse()
            
            self.nameLbl.text = loginResponse.Name
            self.mobileNumberLbl.text = loginResponse.PhoneNo
            self.emailLbl.text = loginDetail.Email
            
        }else{
            self.nameLbl.text = self.theBookerInfoStruct.firstName
//            self.genderLbl.text = self.theBookerInfoStruct.gender
            self.mobileNumberLbl.text = self.theBookerInfoStruct.mobileNo
            self.emailLbl.text = self.theBookerInfoStruct.email
        }
        
        
        if self.bookingStatusStr == "Success"{
            self.amountLbl.attributedText = formatAmount(amountSymbol: "PHP", amountSymbolFontSize: 12.0, amount: self.theConveinceAmtAddedPrice!,amountColor:"#29266f", amountFontSize: 18.0)
            self.bookingStatusLbl.textColor = UIColor.green
        }else{
            self.amountLbl.attributedText = formatAmount(amountSymbol: "PHP", amountSymbolFontSize: 12.0, amount: "0",amountColor:"#29266f", amountFontSize: 18.0)
            self.bookingStatusLbl.textColor = UIColor.red
        }
        
        
        
        // Do any additional setup after loading the view.
    }
    @IBAction func backBtnTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }

    override func viewWillLayoutSubviews() {
        self.nightView.layer.cornerRadius = self.nightView.frame.height / 2.0
        //        self.nightView.clipsToBounds = true
        self.nightView.layer.masksToBounds = true
        self.nightView.backgroundColor = hexStringToUIColor(hex: "#100055")
        
        self.homePageBtn.layer.cornerRadius = 5
        self.homePageBtn.layer.masksToBounds = true
    }
    @IBAction func homePageBtnTapped(_ sender: UIButton) {
        self.navigationController?.popToRootViewController(animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
