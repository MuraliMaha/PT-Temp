//
//  FilterVC.swift
//  UniOrient
//
//  Created by APPLE on 29/04/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

protocol HotelFilterDelegate{
    func didApplyBtnTapped(userSelected : HotelUserSelectedFiltersStruct,controller : FilterVC)
    func didBackBtnTapped(filterBtnTappedFlag : Bool,controller:FilterVC)
}

class FilterVC: UIViewController {

    var delegateVariable : HotelFilterDelegate!
  
    @IBOutlet weak var upTo999Btn: UIButton!
    @IBOutlet weak var oneKTo2999Btn: UIButton!
    @IBOutlet weak var threeKTo4999Btn: UIButton!
    @IBOutlet weak var fiveKTo9999Btn: UIButton!
    @IBOutlet weak var tenPlusBtn: UIButton!
    
    let whiteStarImg = UIImage.init(named: "starWhite.png")
    let yellowStarImg = UIImage.init(named: "starFilled.png")
    @IBOutlet weak var backgroundView1Star: UIView!
    @IBOutlet weak var foregroundView1Star: UIView!
    @IBOutlet weak var backgroundView2Star: UIView!
    @IBOutlet weak var foregroundView2Star: UIView!
    @IBOutlet weak var backgroundView3Star: UIView!
    @IBOutlet weak var foregroundView3Star: UIView!
    @IBOutlet weak var backgroundView4Star: UIView!
    @IBOutlet weak var foregroundView4Star: UIView!
    @IBOutlet weak var backgroundView5Star: UIView!
    @IBOutlet weak var foregroundView5Star: UIView!
    
    @IBOutlet weak var oneStarBtn: UIButton!
    @IBOutlet weak var twoStarBtn: UIButton!
    @IBOutlet weak var threeStarBtn: UIButton!
    @IBOutlet weak var fourStarBtn: UIButton!
    @IBOutlet weak var fiveStarBtn: UIButton!

    @IBOutlet weak var oneStarImgView: UIImageView!
    @IBOutlet weak var twoStarImgView: UIImageView!
    @IBOutlet weak var threeStarImgView: UIImageView!
    @IBOutlet weak var fourStarImgView: UIImageView!
    @IBOutlet weak var fiveStarImgView: UIImageView!
    
    @IBOutlet weak var resetBtn: UIButton!
    @IBOutlet weak var resetBtnBackgroundView: UIView!
    
    @IBOutlet weak var applyBtnBackgroundView: UIView!
    @IBOutlet weak var applyBtn: UIButton!
    
    var hotelFilterArrToDisplayInFilterVC : [HotelFilterStruct]!
    var previouslySelectedFiltersArr : [HotelUserSelectedFiltersStruct]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("selectedFilter",previouslySelectedFiltersArr)
        if previouslySelectedFiltersArr.count > 0{
            if previouslySelectedFiltersArr[0].isOneStar{
                btnTapFunctionality(theBtn: self.oneStarBtn, theImgView: oneStarImgView)
            }
            if previouslySelectedFiltersArr[0].isTwoStar{
                btnTapFunctionality(theBtn: self.twoStarBtn, theImgView: twoStarImgView)
            }
            if previouslySelectedFiltersArr[0].isThreeStar{
                btnTapFunctionality(theBtn: self.threeStarBtn, theImgView: threeStarImgView)
            }
            if previouslySelectedFiltersArr[0].isFourStar{
                btnTapFunctionality(theBtn: self.fourStarBtn, theImgView: fourStarImgView)
            }
            if previouslySelectedFiltersArr[0].isFiveStar{
                btnTapFunctionality(theBtn: self.fiveStarBtn, theImgView: fiveStarImgView)
            }
            if previouslySelectedFiltersArr[0].isUpto999{
                makeBtnSelction(upTo999Btn)
            }
            if previouslySelectedFiltersArr[0].is1000To2999{
                makeBtnSelction(oneKTo2999Btn)
            }
            if previouslySelectedFiltersArr[0].is3000To4999{
                makeBtnSelction(threeKTo4999Btn)
            }
            if previouslySelectedFiltersArr[0].is5000To9999{
                makeBtnSelction(fiveKTo9999Btn)
            }
            if previouslySelectedFiltersArr[0].is10000Plus{
                makeBtnSelction(tenPlusBtn)
            }
  
        }else{
            print("Previously selected filters arr count is 0")
            
        }
    }
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        
        setCornerRadius(backgroundView: backgroundView1Star, foregroundView: foregroundView1Star)
        setCornerRadius(backgroundView: backgroundView2Star, foregroundView: foregroundView2Star)
        setCornerRadius(backgroundView: backgroundView3Star, foregroundView: foregroundView3Star)
        setCornerRadius(backgroundView: backgroundView4Star, foregroundView: foregroundView4Star)
        setCornerRadius(backgroundView: backgroundView5Star, foregroundView: foregroundView5Star)
        
        self.resetBtnBackgroundView.layer.cornerRadius = 5
        self.resetBtnBackgroundView.layer.masksToBounds = true
        
        self.applyBtnBackgroundView.layer.cornerRadius = 5
        self.applyBtnBackgroundView.layer.masksToBounds = true
    }
    func setCornerRadius(backgroundView : UIView,foregroundView : UIView){
        backgroundView.layer.cornerRadius = 5
        backgroundView.layer.masksToBounds = true
        foregroundView.layer.cornerRadius = 5
        foregroundView.clipsToBounds = true
    }
    
    @IBAction func upto999BtnTapped(_ sender: UIButton) {
        makeBtnSelction(sender)
    }
    @IBAction func oneKTo2999BtnTapped(_ sender: UIButton) {
        makeBtnSelction(sender)
    }
    @IBAction func threeKTo4999BtnTapped(_ sender: UIButton) {
        makeBtnSelction(sender)
    }
    @IBAction func fiveKTo9999BtnTapped(_ sender: UIButton) {
        makeBtnSelction(sender)
    }
    @IBAction func tenKPlusBtnTapped(_ sender: UIButton) {
        makeBtnSelction(sender)
    }
    
    func makeBtnSelction(_ sender : UIButton) {
        if !sender.isSelected {
            sender.isSelected = true
        }else{
            sender.isSelected = false
        }
    }
    
    @IBAction func oneStarBtnTapped(_ sender: UIButton) {
        btnTapFunctionality(theBtn: sender, theImgView: self.oneStarImgView)
    }
    @IBAction func twoStarBtnTapped(_ sender: UIButton) {
        btnTapFunctionality(theBtn: sender, theImgView: self.twoStarImgView)
    }
    @IBAction func threeStarBtnTapped(_ sender: UIButton) {
        btnTapFunctionality(theBtn: sender, theImgView: self.threeStarImgView)
    }
    @IBAction func fourStarBtnTapped(_ sender: UIButton) {
        btnTapFunctionality(theBtn: sender, theImgView: self.fourStarImgView)
    }
    @IBAction func fiveStarBtnTapped(_ sender: UIButton) {
        btnTapFunctionality(theBtn: sender, theImgView: self.fiveStarImgView)
    }
    
    func btnTapFunctionality(theBtn : UIButton , theImgView : UIImageView){
        if !theBtn.isSelected{
            theBtn.isSelected = true
            theBtn.setTitleColor(UIColor.white, for: .normal)
            theBtn.backgroundColor = hexStringToUIColor(hex: "#29266f")
            theImgView.backgroundColor = hexStringToUIColor(hex: "#29266f")
            theImgView.image = whiteStarImg
        }else{
            theBtn.isSelected = false
            theBtn.setTitleColor(UIColor.black, for: .normal)
            theBtn.backgroundColor = hexStringToUIColor(hex: "#ffffff")
            theImgView.backgroundColor = hexStringToUIColor(hex: "#ffffff")
            theImgView.image = yellowStarImg
        }
    }
    
  
    
    @IBAction func backBtnTapped(_ sender: UIButton) {
        delegateVariable.didBackBtnTapped(filterBtnTappedFlag: false, controller: self)
    }
    
    @IBAction func applyBtnTapped(_ sender: UIButton){
        
        let aSt = HotelUserSelectedFiltersStruct.init(isUpto999: upTo999Btn.isSelected, is1000To2999: oneKTo2999Btn.isSelected, is3000To4999: threeKTo4999Btn.isSelected, is5000To9999: fiveKTo9999Btn.isSelected,is10000Plus : tenPlusBtn.isSelected, isOneStar: oneStarBtn.isSelected, isTwoStar: twoStarBtn.isSelected, isThreeStar: threeStarBtn.isSelected, isFourStar: fourStarBtn.isSelected, isFiveStar: fiveStarBtn.isSelected)
        delegateVariable.didApplyBtnTapped(userSelected: aSt, controller: self)
        
    }

    @IBAction func resetBtnTapped(_ sender: UIButton) {
        if oneStarBtn.isSelected{
            btnTapFunctionality(theBtn: oneStarBtn, theImgView: self.oneStarImgView)
        }
        if twoStarBtn.isSelected{
            btnTapFunctionality(theBtn: twoStarBtn, theImgView: self.twoStarImgView)
        }
        if threeStarBtn.isSelected{
            btnTapFunctionality(theBtn: threeStarBtn, theImgView: self.threeStarImgView)
        }
        if fourStarBtn.isSelected{
            btnTapFunctionality(theBtn: fourStarBtn, theImgView: self.fourStarImgView)
        }
        if fiveStarBtn.isSelected{
            btnTapFunctionality(theBtn: fiveStarBtn, theImgView: self.fiveStarImgView)
        }
        if upTo999Btn.isSelected{
            makeBtnSelction(upTo999Btn)
        }
        if upTo999Btn.isSelected{
            makeBtnSelction(upTo999Btn)
        }
        if oneKTo2999Btn.isSelected{
            makeBtnSelction(oneKTo2999Btn)
        }
        if threeKTo4999Btn.isSelected{
            makeBtnSelction(threeKTo4999Btn)
        }
        if fiveKTo9999Btn.isSelected{
            makeBtnSelction(fiveKTo9999Btn)
        }
        if tenPlusBtn.isSelected{
            makeBtnSelction(tenPlusBtn)
        }
        
    }
    
    
}
