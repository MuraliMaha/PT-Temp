//
//  HotelRoomsVC.swift
//  UniOrient
//
//  Created by APPLE on 17/04/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

class HotelRoomsVC: UIViewController {

    var theSelectedHotelStruct : HotelStruct!
    var inputDict : [String:String]!
    var theDateData : DateSelectedStruct!
    var guestAndRoomDetsArr = [RoomStruct]()
    
    @IBOutlet weak var tvContainerView: UIView!
    @IBOutlet weak var roomTypeTV: UITableView!
    
    @IBOutlet weak var checkinDateContainer: UIView!
    @IBOutlet weak var checkoutDateContainer: UIView!
    @IBOutlet weak var roomAndGuestContainer: UIView!
    
    @IBOutlet weak var checkinDateLbl: UILabel!
    @IBOutlet weak var checkinMonthAndYearLbl: UILabel!
    @IBOutlet weak var checkinDayLbl: UILabel!
    
    @IBOutlet weak var checkoutDateLbl: UILabel!
    @IBOutlet weak var checkoutMonthAndYearLbl: UILabel!
    @IBOutlet weak var checkoutDayLbl: UILabel!
    var dateDisplayFormat = DateFormatter()
    
    @IBOutlet weak var roomAndGuestLbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        roomTypeTV.delegate = self
        roomTypeTV.dataSource = self
        
        dateDisplayFormat.dateFormat = "E, d MMM"
        let abc = dateDisplayFormat.monthSymbols
  
        let cal = Calendar.current
        let components = cal.dateComponents([.day, .month, .year, .weekday], from: theDateData.checkInDate)
        
        print("Day: \(components.day!)")
        print("Month: \(components.month!)")
        print("Year: \(components.year!)")
        
        
        
//        print("weekday = ",cal.component(.weekday, from: dateData.checkInDate))
//        print("day = ",cal.component(.day, from: dateData.checkInDate))
//        print("month = ",cal.component(.month, from: dateData.checkInDate))
//        print("year",cal.component(.year, from: dateData.checkInDate))
//
        
        
        let checkInDateStr = dateDisplayFormat.string(from: theDateData.checkInDate)
        var checkInDateStrArr = checkInDateStr.components(separatedBy: " ")
        //        for item in checkInDateStrArr{
        //            print("item = ",item)
        //        }
        //
        self.checkinDateLbl.text = checkInDateStrArr[1]
        self.checkinMonthAndYearLbl.text = checkInDateStrArr[2] + ",\(components.year!)"
        checkInDateStrArr[0].remove(at: checkInDateStrArr[0].index(before: checkInDateStrArr[0].endIndex))
        self.checkinDayLbl.text = checkInDateStrArr[0]
        
        let checkOutDateStr = dateDisplayFormat.string(from: theDateData.checkOutDate)
        var checkOutDateStrArr = checkOutDateStr.components(separatedBy: " ")
        //        for item in checkInDateStrArr{
        //            print("item = ",item)
        //        }
        //
        self.checkoutDateLbl.text = checkOutDateStrArr[1]
        self.checkoutMonthAndYearLbl.text = checkOutDateStrArr[2] + ",\(components.year!)"
        checkOutDateStrArr[0].remove(at: checkOutDateStrArr[0].index(before: checkOutDateStrArr[0].endIndex))
        self.checkoutDayLbl.text = checkOutDateStrArr[0]
        
        /*
         self.myCalenderView.delegate = self
         self.myCalenderView.dataSource = self
         self.myCalenderView.allowsMultipleSelection = true
         self.myCalenderView.scrollDirection = .vertical */
        
        
        let  tempStr = self.theSelectedHotelStruct.NoOfRooms + " Room/"
        let a = Int(self.inputDict["Adult"]!)
        let b = Int(self.inputDict["Child"]!)
        let c : Int = a! + b!
        self.roomAndGuestLbl.text =  tempStr + "\(c)" + " Guests"
        
 
    }
    @IBAction func backBtnTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: false)
    }
    
    override func viewWillLayoutSubviews() {
        setCornerRadiusFor(theView: checkinDateContainer , radius: 5.0)
        setCornerRadiusFor(theView: checkoutDateContainer , radius: 5.0)
        setCornerRadiusFor(theView: roomAndGuestContainer , radius: 5.0)
        
   
//        checkinDateView.layer.masksToBounds = true
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension HotelRoomsVC : UITableViewDelegate , UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.theSelectedHotelStruct.RoomDetailArr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "RoomTypeCellID", for: indexPath) as! RoomTypeCellClass
        
        print("RoomDescription =",self.theSelectedHotelStruct.RoomDetailArr[indexPath.row].RoomDescription)
        print("inclusions =",self.theSelectedHotelStruct.RoomDetailArr[indexPath.row].inclusions)
        
        cell.roomTypeLbl.text = self.theSelectedHotelStruct.RoomDetailArr[indexPath.row].RoomDescription
        if self.theSelectedHotelStruct.RoomDetailArr[indexPath.row].inclusions.isEmpty {
            cell.inclusionLbl.text = "No Inclusions from Backend"
        }else{
            cell.inclusionLbl.text = self.theSelectedHotelStruct.RoomDetailArr[indexPath.row].inclusions
        }
        
        cell.amountLbl.attributedText = formatAmount(amountSymbol: "PHP", amountSymbolFontSize: 12.0, amount: self.theSelectedHotelStruct.RoomDetailArr[indexPath.row].TotalAmountMarkupWithTax,amountColor:"#29266f", amountFontSize: 18.0)
        
        if theSelectedHotelStruct.hotelImgData != nil {
            cell.hotelImgView.image =  UIImage(data: self.theSelectedHotelStruct.hotelImgData!)
        }
        
        cell.noOfAdultLbl.text = self.inputDict["Adult"]! + "Adults"
        cell.bookNowBtn.layer.cornerRadius = 2.0
        
        
        cell.bookNowBtn.addTarget(self, action: #selector(self.bookNowBtnTapped), for: .touchUpInside)
//        self.deleteIndexPath = indexPath
        cell.bookNowBtn.tag = indexPath.row
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
    }
    @objc func bookNowBtnTapped (_sender : UIButton ){
        print("booknow btn tapped")
//        let ctrl = self.storyboard?.instantiateViewController(withIdentifier:"HotelBookingVCSBID") as! HotelBookingVC
    
            let ctrl = self.storyboard?.instantiateViewController(withIdentifier:"ReviewHotelVCSBID") as! HotelReviewVC
        
        ctrl.theSelectedHotelStruct = self.theSelectedHotelStruct
        ctrl.inputDict = self.inputDict
        ctrl.theDateData = self.theDateData
        ctrl.selectedRoomIndex = _sender.tag
        ctrl.guestAndRoomDetailsArr =  self.guestAndRoomDetsArr
        self.navigationController?.pushViewController(ctrl, animated: true)
    }
}
class RoomTypeCellClass: UITableViewCell {
    @IBOutlet weak var roomTypeLbl: UILabel!
    @IBOutlet weak var inclusionLbl: UILabel!
    @IBOutlet weak var amountLbl: UILabel!
    @IBOutlet weak var noOfAdultLbl: UILabel!
    @IBOutlet weak var hotelImgView: UIImageView!
    @IBOutlet weak var bookNowBtn: UIButton!
    
    
}
