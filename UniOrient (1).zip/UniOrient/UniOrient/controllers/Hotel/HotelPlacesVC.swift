//
//  HotelPlacesVC.swift
//  UniOrient
//
//  Created by APPLE on 29/03/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

protocol HotelPlacesDelegate {
    func didSelectCity(selectedHotelCityStruct : HotelCityStructNew,controller : HotelPlacesVC)
}

class HotelPlacesVC: UIViewController {
    
    @IBOutlet weak var pickACityLbl: UILabel!
    @IBOutlet weak var searchTxtField: UITextField!
    @IBOutlet weak var placesTV: UITableView!
    
    var hotelPlacesStructArr = [HotelCityStructNew]()
    var searchResultsArray = [HotelCityStructNew]()
    
    var delegateVariable : HotelPlacesDelegate!
    var countryType : String?
    //    var myStringValue:String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        self.placesTV.dataSource = self
        self.placesTV.delegate = self
        
        self.searchTxtField.delegate = self
        //        hotelPlacesStructArr = hotelCityStructArrGlobal
        
        
        self.placesTV.isHidden = true
        self.pickACityLbl.isHidden = false
        
        let toolBar = UIToolbar()
        toolBar.barStyle = UIBarStyle.default
        //        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor.white
        //        toolBar.backgroundColor = hexStringToUIColor(hex: "#AFCA1F")
        toolBar.barTintColor = hexStringToUIColor(hex: "#100055")
        toolBar.sizeToFit()
        
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.plain, target: self, action:#selector(donePicker))
        
        toolBar.setItems([spaceButton, doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        
        //        dateOfBirthTxtField.inputView = DOBDatePicker
        searchTxtField.inputAccessoryView = toolBar
        
        
        if self.countryType == "ph"{
            let dictInput = ["Destination": "" ,"country":self.countryType!,"ReqType" : "JSON"]
            print("Input Dict for popular destination = ",dictInput)
            
            if (Reachability()?.isReachable)! {
                showLoading()
                callPopularDestinationListService_Hotel(messageDict: dictInput)
            }else{
                print("No Internet....")
                self.view.ShowBlackTostWithText(message: "Check Your internet Connection", Interval: 3)
            }
        }else{
            self.searchTxtField.becomeFirstResponder()
        }
    }
    
    func callPopularDestinationListService_Hotel(messageDict : [String:String]) {
        
        WebService().HTTP_POST_WebServiceMethod_Hotel(mainURL: WebServicesUrl.HotelServiceUrl, suffix: WebServicesUrl.GetDestinationList , parameterDict: messageDict) { (ResponseArr, ResponseStatus) in
            hideLoading()
            if ResponseStatus {
                
                let fullResponseArr = ResponseArr as! [[String:AnyObject]]
                self.hotelPlacesStructArr.removeAll()
                for aDict in fullResponseArr {
                    var aStruct = HotelCityStructNew()
                    aStruct.ID = "\(aDict["ID"]!)"
                    aStruct.Country = "\(aDict["Country"]!)"
                    aStruct.AirportName = "\(aDict["AirportName"]!)"
                    aStruct.CityName = "\(aDict["CityName"]!)"
                    aStruct.CitySk = "\(aDict["CitySk"]!)"
                    aStruct.CountryCode = "\(aDict["CountryCode"]!)"
                    aStruct.City = "\(aDict["City"]!)"
                    aStruct.CityCode = "\(aDict["CityCode"]!)"
                    aStruct.ctype = "\(aDict["ctype"]!)"
                    aStruct.Address = "\(aDict["Address"]!)"
                    
                    self.hotelPlacesStructArr.append(aStruct)
                }
                //                let Filtered = self.hotelPlacesStructArr.filter({$0.CityName!.localizedCaseInsensitiveContains(searchString)})
                self.searchResultsArray = self.hotelPlacesStructArr
                self.placesTV.isHidden = false
                self.placesTV.reloadData()
                
            }else{
                print("ResponseStatus :",ResponseStatus)
                self.placesTV.isHidden = true
            }
            
        }
        
        
        
    }
    
    
    
    @objc func donePicker(sender : UIBarButtonItem) {
        if searchTxtField.isFirstResponder {
            self.searchTxtField.resignFirstResponder()
            print("change to gray color by donebtn")
            self.searchTxtField.placeholder = "Pick a City"
            //            self.pickACityLbl.isHidden = true
        }
        if (searchTxtField.text?.isEmpty)! {
            self.pickACityLbl.isHidden = true
        }else{
            
        }
    }
    @IBAction func backBtnTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    override func viewWillAppear(_ animated: Bool) {
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.textChangeNotification), name:UITextField.textDidChangeNotification, object: nil)
        
    }
    override func viewWillDisappear(_ animated: Bool) {
        //        NotificationCenter.default.removeObserver(self, name: .UITextField.textDidChangeNotification , object: nil)
        NotificationCenter.default.removeObserver(self, name: UITextField.textDidChangeNotification, object: nil)
    }
    @objc func textChangeNotification(_ notification : Notification){
        print("SearchTextField changed")
        self.pickACityLbl.isHidden = false
        self.placesTV.isHidden = false
        //        searchRecordsAsPerText(searchStr : searchTxtField.text!)
        searchRecordsAsPerTextFromService(searchStr: searchTxtField.text!)
    }
    func searchRecordsAsPerTextFromService(searchStr : String){
        searchResultsArray.removeAll()
        
        if searchStr.count > 2 {
            //            let inputDict = ["Destination":searchStr , "ReqType" : "JSON"]
            
            let inputDict = ["Destination":searchStr ,"country":self.countryType!,"ReqType" : "JSON"]
            print("Input Dict = ",inputDict)
            
            if (Reachability()?.isReachable)! {
                callDestinationListService_Hotel(messageDict: inputDict, searchString: searchStr)
            }else{
                print("No Internet....")
                self.view.ShowBlackTostWithText(message: "Check Your internet Connection", Interval: 3)
            }
        }else{
            print("Search String count = ",searchStr.count)
            searchResultsArray.removeAll()
            self.placesTV.isHidden = true
        }
        
        
    }
    
    func callDestinationListService_Hotel(messageDict : [String:String],searchString : String) {
        //        WebService().HTTP_POST_WebServiceMethod_Hotel(mainURL: WebServicesUrl.HotelServiceUrlLive, suffix: WebServicesUrl.HotelResult, parameterDict: messageDict) { (ResponseArr, ResponseStatus) in
        //            hideLoading()
        
        
        WebService().HTTP_POST_WebServiceMethod_Hotel(mainURL: WebServicesUrl.HotelServiceUrl, suffix: WebServicesUrl.GetDestinationList , parameterDict: messageDict) { (ResponseArr, ResponseStatus) in
            
            if ResponseStatus {
                
                let fullResponseArr = ResponseArr as! [[String:AnyObject]]
                self.hotelPlacesStructArr.removeAll()
                for aDict in fullResponseArr {
                    var aStruct = HotelCityStructNew()
                    aStruct.ID = "\(aDict["ID"]!)"
                    aStruct.Country = "\(aDict["Country"]!)"
                    aStruct.AirportName = "\(aDict["AirportName"]!)"
                    aStruct.CityName = "\(aDict["CityName"]!)"
                    aStruct.CitySk = "\(aDict["CitySk"]!)"
                    aStruct.CountryCode = "\(aDict["CountryCode"]!)"
                    aStruct.City = "\(aDict["City"]!)"
                    aStruct.CityCode = "\(aDict["CityCode"]!)"
                    aStruct.ctype = "\(aDict["ctype"]!)"
                    aStruct.Address = "\(aDict["Address"]!)"
                    
                    self.hotelPlacesStructArr.append(aStruct)
                }
                let Filtered = self.hotelPlacesStructArr.filter({$0.CityName!.localizedCaseInsensitiveContains(searchString)})
                self.searchResultsArray = Filtered
                if (searchString == "") {
                    self.placesTV.isHidden = true
                }
                else {
                    if self.searchResultsArray.count == 0 {
                        self.placesTV.isHidden = true
                    }
                    self.placesTV.isHidden = false
                }
                //        print(Filtered)
                
                
                self.placesTV.reloadData()
                
            }else{
                print("ResponseStatus :",ResponseStatus)
            }
            
        }
        
        
        
    }
}
// MARK: - TextFieldDelegate {
extension HotelPlacesVC : UITextFieldDelegate{
    
    /*
     func textFieldShouldReturn(_ textField: UITextField) -> Bool{
     if !placesTV.isHidden{
     placesTV.isHidden = true
     }
     textField.resignFirstResponder()
     return true
     } */
    func textFieldDidBeginEditing(_ textField: UITextField) {
        print("Change color textFieldDidBeginEditing HotelPlaces")
        textField.placeholder = ""
        self.pickACityLbl.isHidden = false
    }
    
}
// MARK: - }
//MARK: - TableViewDelegate {

//{"CityCode":"KBL","CityName":"Kabul","CountryCode":"AF","CountryName":"Afghanistan"}
extension HotelPlacesVC : UITableViewDataSource,UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return searchResultsArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "HotelPlacesCellID", for: indexPath) as! HotelPlacesCellClass
        cell.containerView.layer.cornerRadius = 5
        cell.containerView.clipsToBounds = true
        
        if searchResultsArray.count > 0 {
            cell.cityNameLbl.text = searchResultsArray[indexPath.row].CityName
            cell.countryNameLbl.text = searchResultsArray[indexPath.row].Country
        }
        
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let cell : HotelPlacesCellClass!
        
        cell = tableView.cellForRow(at: indexPath) as? HotelPlacesCellClass
        print("Row:\(indexPath.row) selected and its cityName is \(cell.cityNameLbl.text!)")
        print("Row:\(indexPath.row) selected and its countryName is \(cell.countryNameLbl.text!)")
        print("Row:\(indexPath.row) selected and its cityCode is :",searchResultsArray[indexPath.row].CityCode!)
        print("Row:\(indexPath.row) selected and its data is :",searchResultsArray[indexPath.row].Country)
        
        self.placesTV.isHidden = true
        self.searchTxtField.text = ""
        searchTxtField.resignFirstResponder()
        
        delegateVariable.didSelectCity(selectedHotelCityStruct: searchResultsArray[indexPath.row], controller: self)
    }
}
//MARK: - }
class HotelPlacesCellClass : UITableViewCell {
    
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var cityNameLbl: UILabel!
    @IBOutlet weak var countryNameLbl: UILabel!
}
