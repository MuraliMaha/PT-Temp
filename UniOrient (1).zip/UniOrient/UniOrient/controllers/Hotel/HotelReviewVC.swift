//
//  HotelBookingVCTemp.swift
//  UniOrient
//
//  Created by APPLE on 02/05/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

class HotelReviewVC: UIViewController {
    
    var inputDictForAPIBookingTransaction : [String:String] = [:]
    var convienceAmtAddedPrice : Double!
    
    var bookerInfoStruct : BookerInfoStruct!
   
    @IBOutlet weak var guestAlertView: UIView!
    var theSelectedHotelStruct : HotelStruct!
    var inputDict : [String:String]!
    var theDateData : DateSelectedStruct!
    var selectedRoomIndex : Int!
    var guestAndRoomDetailsArr = [RoomStruct]()
    
    
    
    var guestDictToConvert = ["Passenger":[]]
    var guestStructArr = [Any]()
    
    var priceingDictToConvert : [String:Any] = ["APIAmt":10 ,"Markup" : 11, "TotalTaxAmount" : 12 ,"Discount" : 13,"NoofChild" : "" ,"Basefare" : "","TotalAmount" : 14,"Remarks" : "" ,"NoofAdult" : ""]
    
    
    var itineraryDetailsDictToConvert : [String:Any] = ["HotelId": "" ,"HEmail" : "", "LocAndCity" : "" ,"HotelName" : "","Cityname" : "" ,"RoomName" : "","CheckOut" : "","ImpNotes" : "" ,"Inclusion" : "","NoofRooms": "" ,"Cancelpolicy" : "", "HPhone" : "" ,"CheckIn" : "","StarRating" : "" ,"RoomTypeCode" : ""]
    var itineraryDateDisplayFormat = DateFormatter()
    
    var userSK : String!
    
    @IBAction func confirmBtnTapped(_ sender: UIButton) {
        
        let ipAndifAddressArr = getIFAddresses()
        print("ip address = ",ipAndifAddressArr[2])
        
        print("theSelected Hotel struct isssss......",self.theSelectedHotelStruct)
        //PricingDetails
        self.priceingDictToConvert["NoofChild"] = self.inputDict["Child"] //total number child
        self.priceingDictToConvert["NoofAdult"] = self.inputDict["Adult"]
        
        if self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].isFareChanged {
            self.priceingDictToConvert["APIAmt"] = Double(self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].NewAPIAMT)
            self.priceingDictToConvert["Markup"] = Double(self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].NewMarkupAll)
            self.priceingDictToConvert["TotalTaxAmount"] = Double(self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].NewTotalTaxCharges)
            self.priceingDictToConvert["Discount"] = Double(self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].NewDiscount)
            
            
            let bFare = Float(self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].NewBaseFareAmount)
            let mUp = Float(self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].NewMarkupAll)
            self.priceingDictToConvert["Basefare"] = Float(bFare! - mUp!)
            
//            self.priceingDictToConvert["Basefare"] = Float(self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].NewBaseFareAmount) - Float(self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].NewMarkupAll)
            
            
            self.priceingDictToConvert["TotalAmount"] = self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].NewTotalAmountMarkupWithTax
        }else{
            self.priceingDictToConvert["APIAmt"] = Double(self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].APIAMT)
            self.priceingDictToConvert["Markup"] = Double(self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].MarkupAll)
            self.priceingDictToConvert["TotalTaxAmount"] = Double(self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].TotalTaxCharges)
            self.priceingDictToConvert["Discount"] = Double(self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].Discount)
            
            
            let bFare = Float(self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].BaseFareAmount)
            let mUp = Float(self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].MarkupAll)
            self.priceingDictToConvert["Basefare"] = Float(bFare! - mUp!)
            
            self.priceingDictToConvert["TotalAmount"] = self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].TotalAmountMarkupWithTax
        }
        print("priceingDictToConvert = ",self.priceingDictToConvert)
        let thePricingDetailJSONStr = convertDictToJSONString(dictToConvert: self.priceingDictToConvert)
        print("thePricingDetailJSONStr = ",thePricingDetailJSONStr)
       
        //ItineraryDetail
        itineraryDateDisplayFormat.dateFormat = "yyyy-MM-dd"
        self.itineraryDetailsDictToConvert["HotelId"] = theSelectedHotelStruct.HotelUniqueKey
        self.itineraryDetailsDictToConvert["LocAndCity"] = theSelectedHotelStruct.Address
        self.itineraryDetailsDictToConvert["HotelName"] = theSelectedHotelStruct.HotelName
        self.itineraryDetailsDictToConvert["Cityname"] = inputDict["HotelCity"]
        self.itineraryDetailsDictToConvert["RoomName"] = theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].RoomDescription
        
        
        self.itineraryDetailsDictToConvert["CheckOut"] = itineraryDateDisplayFormat.string(from: self.theDateData.checkOutDate)
        self.itineraryDetailsDictToConvert["Inclusion"] = theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].inclusions
        self.itineraryDetailsDictToConvert["NoofRooms"] = theSelectedHotelStruct.NoOfRooms  
        self.itineraryDetailsDictToConvert["Cancelpolicy"] = theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].Cancellationpolicy
        self.itineraryDetailsDictToConvert["CheckIn"] = itineraryDateDisplayFormat.string(from: self.theDateData.checkInDate)
        self.itineraryDetailsDictToConvert["StarRating"] = theSelectedHotelStruct.StarRating
        self.itineraryDetailsDictToConvert["RoomTypeCode"] = theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].RoomTypeCode
        
        print("self.itineraryDetailsDictToConvert = ",self.itineraryDetailsDictToConvert)
        let theItineraryDetailJSONStr = convertDictToJSONString(dictToConvert: self.itineraryDetailsDictToConvert)
        print("theItineraryDetailJSONStr = ",theItineraryDetailJSONStr)
        
        
        
        if !((self.userFirstNameTextField.text?.isEmpty)!),!((self.userEmailTextField.text?.isEmpty)!),!((self.userMobileTextField.text?.isEmpty)!),passengerFilledFlag,checkBoxBtn.isSelected {
            
            self.bookerInfoStruct = BookerInfoStruct()
            if guestTitleSelectedItem == "Mr" {
//                self.bookerInfoStruct.gender = "Male"
            }else {
//                self.bookerInfoStruct.gender = "Female"
            }
            self.bookerInfoStruct.firstName = self.userFirstNameTextField.text!
//            self.bookerInfoStruct.lastName = self.userLastNameTextField.text!
            self.bookerInfoStruct.mobileNo = self.userMobileTextField.text!
            self.bookerInfoStruct.email = self.userEmailTextField.text!
            
            
//            "AdultPerRoom1":(self.selectedArr.count > 0) ? "\(self.selectedArr[0].noOfAdult!)" : "0",
//            "ChildrenPerRoom1":(self.selectedArr.count > 0) ? "\(self.selectedArr[0].noOfChildren!)" : "0",
            
            self.guestStructArr.removeAll()
            for aStr in self.selectedPassengerDetailStructArr{
                var aStruct = FinalGuestStruct()
                aStruct.RoomOrder = aStr.roomNo
                aStruct.FirstName = aStr.firstName
                aStruct.LastName = aStr.lastName
                if aStr.title == "Mr" {
                    aStruct.Title = "1"
                    aStruct.Travellertype = "1"
                    aStruct.age = aStr.age
                }else if aStr.title == "Mrs"{
                    aStruct.Title = "2"
                    aStruct.Travellertype = "1"
                    aStruct.age = aStr.age
                }else if aStr.title == "Ms" {
                    aStruct.Title = "3"
                    aStruct.Travellertype = "1"
                    aStruct.age = aStr.age
                }else if aStr.title == "Mstr"{
                    aStruct.Title = "1"
                    aStruct.Travellertype = "2"
                    aStruct.age = aStr.age
                }else if aStr.title == "Miss"{
                    aStruct.Title = "3"
                    aStruct.Travellertype = "2"
                    aStruct.age = aStr.age
                }
                self.guestStructArr.append(aStruct.asDictionary)
            }
            self.guestDictToConvert["Passenger"] = self.guestStructArr
            let thePassengerDetailJSONStr = convertDictToJSONString(dictToConvert: self.guestDictToConvert)
            
//            print("selected Hotel Struct = ",self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex])

            
            self.inputDictForAPIBookingTransaction = [
                "PassengerDetails" : thePassengerDetailJSONStr, //convertDictToJSONString(dictToConvert: self.guestDictToConvert)
                "PricingDetails" : thePricingDetailJSONStr,
                "ItieneraryDetails" : theItineraryDetailJSONStr,
                "API_SK" : theSelectedHotelStruct.APIType,
                "User_SK" : self.userSK,
                "CityName" : self.inputDict["HotelCity"]!,
                "EmailId" : (self.userEmailTextField.text)!,
                "MobileNo" : (self.userMobileTextField.text)!,
                "noofrooms" : self.theSelectedHotelStruct.NoOfRooms,
                "MobileBooking" : "2", // for iOS 2,android 1
                "IPAddress" : ipAndifAddressArr[2]
            ]
            
            print("THe Final Input Dict For APIBookingTransaction = ",inputDictForAPIBookingTransaction)
            
            callAPIBookingTransactionService(messageDict: inputDictForAPIBookingTransaction)
            /*
             let ctrl = self.storyboard?.instantiateViewController(withIdentifier:"HotelPaymentVCSBID") as! HotelPaymentVC
             self.navigationController?.pushViewController(ctrl, animated: true) */
        }else{
            
            if (self.userFirstNameTextField.text?.isEmpty)! {
                self.myScrollView.scrollToView(view: self.guestDetailHeaderView, animated: true)
                self.view.ShowBlackTostWithText(message: "Please provide First Name", Interval: 3)
            }else if (self.userEmailTextField.text?.isEmpty)! {
                self.myScrollView.scrollToView(view: self.guestDetailHeaderView, animated: true)
                self.view.ShowBlackTostWithText(message: "Please provide Email", Interval: 3)
            }else if (self.userMobileTextField.text?.isEmpty)! {
                self.myScrollView.scrollToView(view: self.guestDetailHeaderView, animated: true)
                self.view.ShowBlackTostWithText(message: "Please provide Mobile Number", Interval: 3)
            }else if !(passengerFilledFlag){
                self.myScrollView.scrollToView(view: self.guestDetailHeaderView, animated: true)
                self.guestAlertView.shake()
                //                self.view.ShowBlackTostWithText(message: "Please provide Guest informations", Interval: 3)
            }else{
                self.view.ShowBlackTostWithText(message: "Please agree terms and Conditions", Interval: 3)
            }
            print("Not all field filled....")
        }
        
    }
    var aAPIBookingTransactionStruct : APIBookingTransactionStruct!
    func callAPIBookingTransactionService(messageDict : [String:String]){
        if (Reachability()?.isReachable)! {

            WebService().HTTP_POST_WebServiceMethod_Profile(mainURL: WebServicesUrl.HotelServiceUrl, suffix: WebServicesUrl.APIBookingTransaction, parameterDict: messageDict) { (ResponseDict, ResponseStatus) in
                if ResponseStatus {
                    print("Service call success from APIBookingTransaction  ..........")
                    let fullResponse = ResponseDict as! [String:String]
                    print(fullResponse)
                    
                    //3270~CIT1520193270~0
                    if (fullResponse["Result"]?.contains("~"))!
                    {
                        let arr = fullResponse["Result"]?.components(separatedBy: "~")
                        print("The Arr =",arr)
                        self.aAPIBookingTransactionStruct = APIBookingTransactionStruct()
                        self.aAPIBookingTransactionStruct.BookingSK = arr![0]
                        self.aAPIBookingTransactionStruct.TripID = arr![1]
                        self.aAPIBookingTransactionStruct.ConvenienceAmt = arr![2]
                        
                        
//                        int additionalamount=(int)a[2] ;
//                        int totalamt=[[dictRoom valueForKey:@"TotalAmountMarkupWithTax"] intValue];
//                        int newtotal=totalamt+additionalamount;
//                        [Userdefault setValue:[NSNumber numberWithInt:newtotal] forKey:@"hotelfinalamount"] ;

                        var Price :String!
                        if self.theSelectedHotelStruct.RoomDetailArr[self.selectedRoomIndex].isFareChanged {
                            Price = self.theSelectedHotelStruct.RoomDetailArr[self.selectedRoomIndex].NewTotalAmountMarkupWithTax
                        }else{
                        Price = self.theSelectedHotelStruct.RoomDetailArr[self.selectedRoomIndex].TotalAmountMarkupWithTax
                        }
                        
                        self.convienceAmtAddedPrice = Double(Price!)! + Double(self.aAPIBookingTransactionStruct.ConvenienceAmt)!
                        print("self.convienceAmtAddedPrice = ",self.convienceAmtAddedPrice)
                        
                        if arr![2] == "0" {
                            print("Convience fee = 0")
                            self.moveToPaymentPage(apiBookingStruct: self.aAPIBookingTransactionStruct)
//                            self.callFinalBooking(APITransactionInputDict: messageDict)
                        }else{
                            print("Show Alert Vieeeewwwwww....")
                            self.alertView.isHidden = false
                            self.alertViewLbl.text = "Convience Fee PHP \(self.aAPIBookingTransactionStruct.ConvenienceAmt!) added"
                            self.callFinalBookingFlag = true
                        }
                        
                        
                    }else{
                        print("Booking transaction failed, please try again!")
                        self.view.ShowBlackTostWithText(message: "Booking transaction failed, please try again!", Interval: 3)
                    }
                    
                }else{
                    print("Service call Failure from APIBookingTransaction..........")
                    print("Booking transaction failed, please try again!")
                    self.view.ShowBlackTostWithText(message: "Booking transaction failed, please try again!", Interval: 3)
                }
            }
        }else{
             print("No Internet......")
            self.view.ShowBlackTostWithText(message: "Check Your internet Connection", Interval: 3)
        }
    }
    
    func  moveToPaymentPage(apiBookingStruct : APIBookingTransactionStruct){
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier:"PaymentVCSBID") as! PaymentVC
//        ctrl.apiBookingTransactionData = apiBookingStruct
//        ctrl.theAmount = "\(self.convienceAmtAddedPrice!)"
        ctrl.aBookerInfoStruct = self.bookerInfoStruct
        ctrl.descriptionForBooking = "Hotel Booking"
        ctrl.aSelectedHotelStruct = self.theSelectedHotelStruct
        ctrl.aInputDict = self.inputDict
        ctrl.aDateData = self.theDateData
        ctrl.aSelectedRoomIndex = self.selectedRoomIndex
        ctrl.aGuestAndRoomDetailsArr =  self.guestAndRoomDetailsArr
        ctrl.aAPITransactionInputDict = inputDictForAPIBookingTransaction
        ctrl.aAPITransactionServiceOutputStruct = self.aAPIBookingTransactionStruct
//        ctrl.aBookerInfoStruct = self.bookerInfoStruct
        ctrl.aPricingDictOfAPITransaction = self.priceingDictToConvert
        ctrl.aConveinceAmtAddedPrice = "\(self.convienceAmtAddedPrice!)"
        ctrl.bookingStatusStr = "Success"
     
        self.navigationController?.pushViewController(ctrl, animated: true)
    }
    
    
    func callFinalBooking(APITransactionInputDict : [String:String] ) {
        
        if (Reachability()?.isReachable)! {
            let inputDictForFinalBooking : [String : String]!
            let webServiceMethodName : String!
            
            if self.theSelectedHotelStruct.APIType == "7" { //APIType 7 means HotelBeds
                print("Supplier = HotelBeds")
                webServiceMethodName = WebServicesUrl.HotelbedsFinalbooking
                inputDictForFinalBooking = [ "Booking_SK" : aAPIBookingTransactionStruct.BookingSK,
                                             "TripId" : aAPIBookingTransactionStruct.TripID,
                                             "RoomBookingCode" : self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].RoomBookingCode,
                                             "NoOfRooms" : self.theSelectedHotelStruct.NoOfRooms!
                ]
                print("inputDictForFinalBooking = ",inputDictForFinalBooking)
            }else if self.theSelectedHotelStruct.APIType == "18" { //APIType 18 means MikiTravels
                print("Supplier = MikiTravels")
                webServiceMethodName = WebServicesUrl.MikiFinalbooking
                inputDictForFinalBooking = [
                    "Booking_SK" : aAPIBookingTransactionStruct.BookingSK,
                    "HotelCity" : self.inputDict["HotelCity"]!,
                    "HotelId" : theSelectedHotelStruct.HotelUniqueKey,
                    "CheckIn" : itineraryDateDisplayFormat.string(from: self.theDateData.checkInDate),
                    "CheckOut" : itineraryDateDisplayFormat.string(from: self.theDateData.checkOutDate),
                    "NoOfRooms" : self.theSelectedHotelStruct.NoOfRooms!,
                    "paxstr" : self.theSelectedHotelStruct.paxstr ?? "",
                    "RoomTypeCode" : theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].RoomTypeCode,
                    "RoomTotalRate" :  "\(self.convienceAmtAddedPrice!)", //theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].bbPrice ?? "",
                    "MealBasisID" : theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].RatePlanCode,
                    "Tripid" : aAPIBookingTransactionStruct.TripID,
                    "nationality" : "",
                    "RoomBookingCode" : self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].RoomBookingCode,
                    "CurrencyCode" : self.theSelectedHotelStruct.Currency
                    ] as? [String : String]
                
                print("inputDictForFinalBooking = ",inputDictForFinalBooking)
                
            }else{
                print("Supplier = HotelExtranet")
                webServiceMethodName = WebServicesUrl.HotelExtranetFinalbooking
                inputDictForFinalBooking = [ "Booking_SK" : aAPIBookingTransactionStruct.BookingSK,
                                             "HotelCity" : self.inputDict["HotelCity"]!,
                                             "HotelId" : theSelectedHotelStruct.HotelUniqueKey,
                                             "RoomBookingCode" : self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].RoomBookingCode,
                                             "RoomTypeCode" : theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].RoomTypeCode,
                                             "Inclusion" : theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].inclusions,
                                             "MealBasisID" : theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].RatePlanCode,
                                             "APIAmt" : theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].APIAMT
                ]
                print("inputDictForFinalBooking = ",inputDictForFinalBooking)
            }
            WebService().HTTP_POST_WebServiceMethod_Profile(mainURL: WebServicesUrl.HotelServiceUrl, suffix: webServiceMethodName, parameterDict: inputDictForFinalBooking) { (ResponseDict, ResponseStatus) in
                print("Final Service Response = ",ResponseDict)
                
                if ResponseStatus
                {
                    print("Service call success ..........")
                    let fullResponse = ResponseDict as! [String:String]
                    print(fullResponse)
                    if fullResponse["Result"] == "" {
                        print("final booking respnse is empty...So transaction failure")
                        self.view.ShowBlackTostWithText(message: "Booking Transaction failed...", Interval: 2)
                        // Need to Remove below lines...
                        let ctrl = self.storyboard?.instantiateViewController(withIdentifier:"HotelBookingSummaryVCSBID") as! HotelBookingSummaryVC
                        ctrl.selectedHotelStruct = self.theSelectedHotelStruct
                        ctrl.theInputDict = self.inputDict
                        ctrl.dateData = self.theDateData
                        ctrl.theSelectedRoomIndex = self.selectedRoomIndex
                        ctrl.theGuestAndRoomDetailsArr =  self.guestAndRoomDetailsArr
                        ctrl.apiTransactionInputDict = APITransactionInputDict
                        ctrl.apiTransactionServiceOutputStruct = self.aAPIBookingTransactionStruct
                        ctrl.theBookerInfoStruct = self.bookerInfoStruct
                        ctrl.pricingDictOfAPITransaction = self.priceingDictToConvert
                        ctrl.theConveinceAmtAddedPrice = "\(self.convienceAmtAddedPrice!)"
                        ctrl.bookingStatusStr = "Fail"
                        self.navigationController?.pushViewController(ctrl, animated: true)
                    }else{
                        print("final booking response is not empty...so tranaction success..Your hotel  has been confirmed.")
                        
                        let ctrl = self.storyboard?.instantiateViewController(withIdentifier:"HotelBookingSummaryVCSBID") as! HotelBookingSummaryVC
                        ctrl.selectedHotelStruct = self.theSelectedHotelStruct
                        ctrl.theInputDict = self.inputDict
                        ctrl.dateData = self.theDateData
                        ctrl.theSelectedRoomIndex = self.selectedRoomIndex
                        ctrl.theGuestAndRoomDetailsArr =  self.guestAndRoomDetailsArr
                        ctrl.apiTransactionInputDict = APITransactionInputDict
                        ctrl.apiTransactionServiceOutputStruct = self.aAPIBookingTransactionStruct
                        ctrl.theBookerInfoStruct = self.bookerInfoStruct
                        ctrl.pricingDictOfAPITransaction = self.priceingDictToConvert
                        ctrl.theConveinceAmtAddedPrice = "\(self.convienceAmtAddedPrice!)"
                        ctrl.bookingStatusStr = "Success"
                        self.navigationController?.pushViewController(ctrl, animated: true)
                    }
                }
            }
            
        }else{
            print("No Internet....")
            self.view.ShowBlackTostWithText(message: "Check Your internet Connection", Interval: 3)
        }
        
        
    }
  
   
    @IBOutlet weak var hotelNameLbl: UILabel!
    @IBOutlet weak var addressLbl: UILabel!
    @IBOutlet weak var ratingView: EDStarRating!
    
    
    @IBOutlet weak var roomTypeLbl: UILabel!
    @IBOutlet weak var inclusionLbl: UILabel!
    @IBOutlet weak var noOfRoomGuestLbl: UILabel!
    
    @IBOutlet weak var checkinDateLbl: UILabel!
    @IBOutlet weak var checkinMonthAndYearLbl: UILabel!
    @IBOutlet weak var checkinDayLbl: UILabel!
    
    @IBOutlet weak var checkoutDateLbl: UILabel!
    @IBOutlet weak var checkoutMonthAndYearLbl: UILabel!
    @IBOutlet weak var checkoutDayLbl: UILabel!
    
    @IBOutlet weak var baseFareLbl: UILabel!
    @IBOutlet weak var taxLbl: UILabel!
    @IBOutlet weak var discountLbl: UILabel!
    @IBOutlet weak var applyBtn: UIButton!
    @IBOutlet weak var totalAmountLbl: UILabel!
    
    @IBOutlet weak var checkBoxBtn: UIButton!
    @IBOutlet weak var confirmBtn: UIButton!
    
    var dateDisplayFormat = DateFormatter()
    
    
    @IBOutlet weak var guestTitlePickerView: UIPickerView!
    var guestTitleSelectedItem = "Mr"
    var guestTitleSelectedIndex : Int = 0
    var guestTitlePreviousIndex : Int = 0
    var guestTitleInputArr = ["Mr","Mrs","Ms"]
    
    @IBOutlet weak var myToolBar: UIToolbar!
    
    
    @IBOutlet weak var guestDetailHeaderView: UIView!
//    @IBOutlet weak var scrollContentView: UIView!
    @IBOutlet weak var myScrollView: UIScrollView!
    
    
    /*
    @IBOutlet weak var tvContainer: UIView!
    @IBOutlet weak var tvContainerHeightCons: NSLayoutConstraint!
    
    @IBOutlet weak var myTv: UITableView!
    @IBOutlet weak var tvHeightCons: NSLayoutConstraint!
    
    

    var myIndexPath : IndexPath! */
    var arrayCount : Int!
    
    
  
//    @IBOutlet weak var mrLabl: UILabel!
//    @IBOutlet weak var firstNameLbl: UILabel!
//    @IBOutlet weak var lastNameLbl: UILabel!
//    @IBOutlet weak var emailLbl: UILabel!
//    @IBOutlet weak var phoneCodeLbl: UILabel!
//    @IBOutlet weak var phoneNoLbl: UILabel!
    
    @IBOutlet weak var userTitleTextField: UITextField!
    @IBOutlet weak var userFirstNameTextField: UITextField!
    @IBOutlet weak var userLastNameTextField: UITextField!
    @IBOutlet weak var userMobileCodeTextField: UITextField!
    
    @IBOutlet weak var userEmailTextField: UITextField!
    @IBOutlet weak var userMobileTextField: UITextField!
    
    
    
    
    
    
    @IBAction func guestInfoBtnTapped(_ sender: UIButton) {
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier:"PassengerDetailsVCSBID") as! PassengerDetailsVC
        //        ctrl.selectedHotelStruct = self.arrToDisplay[indexPath.row]
        //        ctrl.theInputDict =  inputDict
                ctrl.DelegateVar = self
                ctrl.selectedHotelStruct = self.theSelectedHotelStruct
                ctrl.theInputDict = self.inputDict
                ctrl.theGuestAndRoomDetailsArr = self.guestAndRoomDetailsArr
            ctrl.previouslySelectedPassengerDetailStructArr = self.selectedPassengerDetailStructArr
        //        ctrl.theDateData = self.dateData
        //        ctrl.selectedRoomIndex = 0
        self.navigationController?.pushViewController(ctrl, animated: true)
    }
    
    
    
    var selectedPassengerDetailStructArr = [PassengerStruct]()
    var passengerFilledFlag : Bool = false
    @IBOutlet weak var alertImgView: UIImageView!
    
    
    var loginDetail : LoginDetails!
    var loginResponse : LoginResponse!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if FetchLoginDetails() != nil {
            loginDetail = FetchLoginDetails()
            loginResponse = FetchLoginResponse()
            
            
//            self.userTitleTextField.text = "Mr"
            self.userFirstNameTextField.text = loginResponse.Name
//            self.userLastNameTextField.text = "MM"
            self.userEmailTextField.text = loginDetail.Email
//            self.userMobileCodeTextField.text = "+ 91"
            self.userMobileTextField.text = loginResponse.PhoneNo
            
            self.userSK = loginResponse.UserSK
        }else{
            self.userSK = "0"
        }
        
//        self.userTitleTextField.delegate = self
        self.userFirstNameTextField.delegate = self
//        self.userLastNameTextField.delegate = self
        self.userEmailTextField.delegate = self
//        self.userMobileCodeTextField.delegate = self
        self.userMobileTextField.delegate = self
        
        
        self.userTitleTextField.text = guestTitleSelectedItem
        guestTitlePickerView.delegate = self
        guestTitlePickerView.dataSource = self
        guestTitlePickerView.showsSelectionIndicator = true
        myToolBar.isUserInteractionEnabled = true
        
        self.userTitleTextField.inputView = self.guestTitlePickerView
        self.userTitleTextField.inputAccessoryView = self.myToolBar
        
        guestTitlePickerView.selectRow(0, inComponent: 0, animated: true)
        
        
        self.hotelNameLbl.text = theSelectedHotelStruct.HotelName!
        self.addressLbl.text = theSelectedHotelStruct.Address!
        //        self.addressLbl.text = "Each XML Web service needs a unique namespace in order for client applications to distinguish it from other services on the Web. http://tempuri.org/ is available for XML Web services that are under development, but published XML Web services should use a more permanent namespace."
        
        self.ratingView.starImage = UIImage.init(named: "starUnfilled")
        self.ratingView.starHighlightedImage = UIImage.init(named: "starFilled")
        self.ratingView.maxRating = 5
        self.ratingView.horizontalMargin = 0
        self.ratingView.displayMode = UInt(EDStarRatingDisplayFull)
        self.ratingView.rating = Float(self.theSelectedHotelStruct.StarRating)!
        
        if self.theSelectedHotelStruct.RoomDetailArr.count > 0 {
            self.roomTypeLbl.text = self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].RoomDescription
            self.inclusionLbl.text = self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].inclusions
        }
        
        
        let  tempStr = self.theSelectedHotelStruct.NoOfRooms + " Room/"
        let a = Int(self.inputDict["Adult"]!)
        let b = Int(self.inputDict["Child"]!)
        arrayCount = a! + b!
        self.noOfRoomGuestLbl.text = tempStr + "\(arrayCount!)" + " Guests"
            
        dateDisplayFormat.dateFormat = "E, d MMM"
        let cal = Calendar.current
        let components = cal.dateComponents([.day, .month, .year, .weekday], from: theDateData.checkInDate)
        
        let checkInDateStr = dateDisplayFormat.string(from: theDateData.checkInDate)
        var checkInDateStrArr = checkInDateStr.components(separatedBy: " ")
        self.checkinDateLbl.text = checkInDateStrArr[1]
        self.checkinMonthAndYearLbl.text = checkInDateStrArr[2] + ",\(components.year!)"
        checkInDateStrArr[0].remove(at: checkInDateStrArr[0].index(before: checkInDateStrArr[0].endIndex))
        self.checkinDayLbl.text = checkInDateStrArr[0]
        
        
        let checkOutDateStr = dateDisplayFormat.string(from: theDateData.checkOutDate)
        var checkOutDateStrArr = checkOutDateStr.components(separatedBy: " ")
        self.checkoutDateLbl.text = checkOutDateStrArr[1]
        self.checkoutMonthAndYearLbl.text = checkOutDateStrArr[2] + ",\(components.year!)"
        checkOutDateStrArr[0].remove(at: checkOutDateStrArr[0].index(before: checkOutDateStrArr[0].endIndex))
        self.checkoutDayLbl.text = checkOutDateStrArr[0]
        
        
        self.baseFareLbl.attributedText = formatAmount(amountSymbol: "PHP", amountSymbolFontSize: 12.0, amount: theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].BaseFareAmount, amountColor: "#29266f", amountFontSize: 14.0)
        self.taxLbl.attributedText = formatAmount(amountSymbol: "PHP", amountSymbolFontSize: 12.0, amount: theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].TotalTaxCharges, amountColor: "#29266f", amountFontSize: 14.0)
        self.discountLbl.attributedText = formatAmount(amountSymbol: "PHP", amountSymbolFontSize: 12.0, amount: theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].Discount, amountColor: "#29266f", amountFontSize: 14.0)
        
        self.totalAmountLbl.attributedText = formatAmount(amountSymbol: "PHP", amountSymbolFontSize: 12.0, amount: theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].TotalAmountMarkupWithTax, amountColor: "#29266f", amountFontSize: 18.0)
        
        
        /*
        self.myTv.delegate = self
        self.myTv.dataSource = self
        self.tvHeightCons.constant = CGFloat(arrayCount * 40) */
        
        self.alertView.isHidden = true
        //APIType 7 means Hotelbeds. // As of now,no room is selected.so use the first room (RoomDetailArr[0])
        if theSelectedHotelStruct.APIType == "7" && theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].RateType == "RECHECK"{
             print("Fare check Service for HotelBeds called....")
            callHotelBedsCheckratesService()
        }
      
        
    }
    func callHotelBedsCheckratesService(){
        
        showLoading()
        
        let dictInput = ["RoomBookingCode":theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].RoomBookingCode!,
                         "NoOfRooms":theSelectedHotelStruct.NoOfRooms!,
                         "NoOfNights":theSelectedHotelStruct.NoOfNights!,
                         "CityCode":self.inputDict["CityCode"]!,
                         "ctype":self.inputDict["ctype"]!,
                         "ReqType":"JSON"
        ]
        print("Input Dict - callHotelBedsCheckratesService = ",dictInput)
        
        
        if (Reachability()?.isReachable)! {
            WebService().HTTP_POST_WebServiceMethod_Hotel(mainURL: WebServicesUrl.HotelServiceUrl, suffix: WebServicesUrl.HotelBedsCheckrates, parameterDict: dictInput as! [String : String]) { (ResponseArr, ResponseStatus) in
                hideLoading()
                
                if ResponseStatus {
                    print("HotelBedsCheckrates Service call success ..........")
                    
                    //                    self.flightResultArr = responce["FlightResult"] as! [[String:AnyObject]]
                    
                    let fullResponseArr = ResponseArr as! [[String:AnyObject]]
                    let responseDict = fullResponseArr[0]
                    
                    print("HotelBedsCheckrates Service call Response = ",responseDict)
                    self.theSelectedHotelStruct.RoomDetailArr[self.selectedRoomIndex].Cancellationpolicy = "\(responseDict["Cancellationpolicy"]!)"
                    self.theSelectedHotelStruct.RoomDetailArr[self.selectedRoomIndex].NewTotalAmountMarkupWithTax = "\(responseDict["TotalAmountMarkupWithTax"]!)"
                    
                    let oldFare = Float(self.theSelectedHotelStruct.RoomDetailArr[self.selectedRoomIndex].TotalAmountMarkupWithTax)
                    let newFare = Float(self.theSelectedHotelStruct.RoomDetailArr[self.selectedRoomIndex].NewTotalAmountMarkupWithTax)! // + 1.0
                    
                    if oldFare == newFare {
                        print("Fares are same...")
                        self.theSelectedHotelStruct.RoomDetailArr[self.selectedRoomIndex].isFareChanged = false
                    }else{
                        self.theSelectedHotelStruct.RoomDetailArr[self.selectedRoomIndex].isFareChanged = true
                        self.theSelectedHotelStruct.RoomDetailArr[self.selectedRoomIndex].NewAPIAMT = "\(responseDict["APIAMT"]!)"
                        self.theSelectedHotelStruct.RoomDetailArr[self.selectedRoomIndex].NewMarkupAll = "\(responseDict["MarkupAll"]!)"
                        self.theSelectedHotelStruct.RoomDetailArr[self.selectedRoomIndex].NewTotalTaxCharges = "\(responseDict["TotalTaxCharges"]!)"
                        self.theSelectedHotelStruct.RoomDetailArr[self.selectedRoomIndex].NewDiscount = "\(responseDict["Discount"]!)"
                        self.theSelectedHotelStruct.RoomDetailArr[self.selectedRoomIndex].NewBaseFareAmount = "\(responseDict["BaseFareAmount"]!)"
                    self.theSelectedHotelStruct.RoomDetailArr[self.selectedRoomIndex].NewTotalAmountMarkupWithTax = "\(responseDict["TotalAmountMarkupWithTax"]!)"
                        
                        self.fareChangeText = "Room price changed from PHP \(oldFare!)  to  PHP \(newFare), Do you want to continue?"
                        self.alertViewLbl.text = self.fareChangeText
                        self.alertView.isHidden = false
                        print ("the Selected Struct =",self.theSelectedHotelStruct)
                        
                    }
                    
                }else{
                    print("Service call failure ..........")
                    print("Try after sometimes...internet connetivity Problem....")
                }
            }
        }else{
            print("No Internet......")
            self.view.ShowBlackTostWithText(message: "Check Your internet Connection", Interval: 3)
        }
        
        
    }
    /*
    //PricingDetails
    self.priceingDictToConvert["APIAmt"] = Double(self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].APIAMT)
    self.priceingDictToConvert["Markup"] = Double(self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].MarkupAll)
    self.priceingDictToConvert["TotalTaxAmount"] = Double(self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].TotalTaxCharges)
    self.priceingDictToConvert["Discount"] = Double(self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].Discount)
    self.priceingDictToConvert["NoofChild"] = self.inputDict["Child"] //total number child
    
    let bFare = Float(self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].BaseFareAmount)
    let mUp = Float(self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].MarkupAll)
    self.priceingDictToConvert["Basefare"] = Float(bFare! - mUp!)
    
    self.priceingDictToConvert["TotalAmount"] = self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].TotalAmountMarkupWithTax
    self.priceingDictToConvert["NoofAdult"] = self.inputDict["Adult"] */
    
    var fareChangeText : String!
    @IBOutlet weak var alertView: UIView!
    @IBOutlet weak var alertViewLbl: UILabel!
    @IBOutlet weak var continueBtn: UIButton!
    var callFinalBookingFlag : Bool = false
    
    @IBAction func alertViewCancelBtnTapped(_ sender: UIButton) {
        print("AlertView Cncel Tapped..")
        self.alertView.isHidden = true
        //        let ctrl = storyboard?.instantiateViewController(withIdentifier: "HomePageVC") as! HomePageVC
        //        self.navigationController?.popToViewController(ctrl, animated: true)
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    @IBAction func alertViewContinueBtnTapped(_ sender: UIButton) {
        self.alertView.isHidden = true
        print("AlertView OK Tapped..So do Nothing")
        self.baseFareLbl.attributedText = formatAmount(amountSymbol: "PHP", amountSymbolFontSize: 12.0, amount: theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].NewBaseFareAmount, amountColor: "#29266f", amountFontSize: 14.0)
        self.taxLbl.attributedText = formatAmount(amountSymbol: "PHP", amountSymbolFontSize: 12.0, amount: theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].NewTotalTaxCharges, amountColor: "#29266f", amountFontSize: 14.0)
        self.discountLbl.attributedText = formatAmount(amountSymbol: "PHP", amountSymbolFontSize: 12.0, amount: theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].NewDiscount, amountColor: "#29266f", amountFontSize: 14.0)
        
        self.totalAmountLbl.attributedText = formatAmount(amountSymbol: "PHP", amountSymbolFontSize: 12.0, amount: theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].NewTotalAmountMarkupWithTax, amountColor: "#29266f", amountFontSize: 18.0)
        
        
        
        if self.callFinalBookingFlag {
            self.moveToPaymentPage(apiBookingStruct: self.aAPIBookingTransactionStruct)
//            callFinalBooking(APITransactionInputDict: inputDictForAPIBookingTransaction)
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
        
    }
    //MARK: - Keyboard show
    var keyboardSize : CGRect?
    @objc func keyboardWillShow(_ notification : NSNotification){
        self.myScrollView.scrollToView(view: self.guestDetailHeaderView, animated: true)
    }
    
    @objc func keyboardWillHide(_ notification : NSNotification)
    {
        
    }

    override func viewWillLayoutSubviews() {
        self.applyBtn.layer.cornerRadius = 5.0
        self.applyBtn.layer.masksToBounds = true
        
        self.confirmBtn.layer.cornerRadius = 5.0
        self.confirmBtn.layer.masksToBounds = true
        
        /*
         self.guestTitleTextField.layer.shadowOpacity = 1
         self.guestTitleTextField.layer.shadowOffset = CGSize(width: -1, height: 1)//CGSize.zero //CGSize(width: -1, height: 1)
         self.guestTitleTextField.layer.shadowRadius = 5
         
         self.firstNameTextField.layer.shadowOpacity = 1
         self.firstNameTextField.layer.shadowOffset = CGSize(width: 0, height: 1)//CGSize.zero //CGSize(width: -1, height: 1)
         self.firstNameTextField.layer.shadowRadius = 5 */
        
    }
    @IBAction func backBtnTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
//        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func checkBoxBtnTapped(_ sender: UIButton) {
        if !sender.isSelected {
            sender.isSelected = true
        }else{
            sender.isSelected = false
        }
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */

    @IBAction func applyBtnTapped(_ sender: UIButton) {
    }
    
    @IBAction func pickerCancelBtnTapped(_ sender: UIBarButtonItem) {
        self.view.endEditing(true)
        //        self.guestTitlePickerView.isHidden = true
        
    }
    @IBAction func pickerDoneBtnTapped(_ sender: UIBarButtonItem) {
        self.view.endEditing(true)
        //        self.guestTitlePickerView.isHidden = true
        
        
        guestTitleSelectedItem = "\(guestTitleInputArr[guestTitleSelectedIndex])"
        self.userTitleTextField.text = guestTitleSelectedItem
        self.userTitleTextField.resignFirstResponder()
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
/*
extension HotelBookingVCTemp : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrayCount
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PassengerCellID", for: indexPath) as! PassengerCellClass
        cell.passengerNameLbl.text = "\( indexPath.row + 1) Passenger"
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: false)
        print("Tapped Cell index = \(indexPath.row)")
        self.myIndexPath = indexPath
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "PassengerDetailsVCSBID") as! PassengerDetailsVC
        ctrl.DelegateVar = self
        ctrl.travellerTVIndex = indexPath.row
        //        self.present(ctrl, animated: true, completion: nil)
        self.navigationController?.pushViewController(ctrl, animated: false)
        
    }
}
class PassengerCellClass : UITableViewCell {
    @IBOutlet weak var passengerNameLbl: UILabel!
} */
extension HotelReviewVC : UITextFieldDelegate{
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
//        if textField == self.guestTitleTextField {
//            pickerContainer.isHidden = false
//            guestTitlePickerView.reloadAllComponents()
//            guestTitlePickerView.selectRow(guestTitleSelectedIndex, inComponent: 0, animated: true)
//        }
        
        if textField == self.userTitleTextField {
            guestTitlePickerView.reloadAllComponents()
            guestTitlePickerView.selectRow(guestTitleSelectedIndex, inComponent: 0, animated: true)
        }else if textField == self.userEmailTextField{
            textField.keyboardType = .emailAddress
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
  
    
}
//MARK: - PickerViewDelegate {
extension HotelReviewVC:UIPickerViewDelegate,UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return guestTitleInputArr.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return guestTitleInputArr[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.guestTitleSelectedIndex = pickerView.selectedRow(inComponent: 0)
    }
}
//MARK: - }
extension HotelReviewVC : PassengerDetailsProtocol {
    func didDoneBtnTapped(_ arrToPass: [PassengerStruct], _ passengerFilled: Bool, _ controller: PassengerDetailsVC) {
        self.selectedPassengerDetailStructArr = arrToPass
        self.passengerFilledFlag = passengerFilled
        self.alertImgView.isHidden = true
        print("self.selectedPassengerDetailStructArr =",self.selectedPassengerDetailStructArr)
        controller.navigationController?.popViewController(animated: true)
//        self.navigationController?.popViewController(animated: true)
    }
    
//    func didBackBtnTapped(_ backBtnTappedFlag: Bool, _ controller: PassengerDetailsVC) {
//        if backBtnTappedFlag {
//            
//        }
//            
//    }
    
//    func didDoneBtnTapped(_ arrToPass: [PassengerStruct], _ controller: PassengerDetailsVC) {
//        self.selectedPassengerDetailStructArr = arrToPass
//    }
    
   
//    func didDoneBtnTapped(_ structToPass: TravellerDetailStruct, _ controller: PassengerDetailsVC) {
//        print("Details of Traveller = ", structToPass)
//
////        let cell = myTv.cellForRow(at: myIndexPath) as! PassengerCellClass
////        self.GrandArr[myIndexPath.row] = structToPass
////        cell.nameLbl.text = self.GrandArr[myIndexPath.row].firstName
////        cell.detailLbl.text = self.StaticArr[myIndexPath.row]
////        cell.detailLbl.textColor = UIColor.black
//
//        self.navigationController?.popViewController(animated: true)
//
//    }

    
}

struct FinalGuestStruct {
    var age : String!
    var RoomOrder : String!
    var Travellertype : String!
    var Title : String!
    var FirstName : String!
    var LastName : String!
    
    var asDictionary : [String:Any] {
        let mirror = Mirror(reflecting: self)
        let dict = Dictionary(uniqueKeysWithValues: mirror.children.lazy.map({ (label:String?,value:Any) -> (String,Any)? in
            guard label != nil else { return nil }
            return (label!,value)
        }).compactMap{ $0 })
        return dict
    }
    
}

/*
struct FinalPricingDetailsStruct {
    var APIAmt : String!
    var Markup : String!
    var TotalTaxAmount : String!
    var Discount : String!
    var NoofChild : String!
    var Basefare : String!
    var TotalAmount : String!
    var Remarks : String!
    var NoofAdult: String!
}*/
struct APIBookingTransactionStruct {
    var BookingSK : String!
    var TripID : String!
    var ConvenienceAmt : String!
}
