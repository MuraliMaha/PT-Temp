//
//  HotelReviewTemp.swift
//  UniOrient
//
//  Created by APPLE on 12/04/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit
import SDWebImage

class HotelDetailVC: UIViewController {
    var hotelDescriptionStr : String!
    
    var selectedHotelStruct : HotelStruct!
    var theInputDict : [String:String]!
    var dateData : DateSelectedStruct!
    var theGuestAndRoomDetailsArr = [RoomStruct]()
    var selectedRoomIndex : Int = 0
    
    var hoteltlArr = [HoteltlStruct]()
    var facilitytlArr = [FacilitytlStruct]()
    var gallerytlArr = [GallerytlStruct]()
    var HFGContainerArr = [HFGContainerStruct]()
    
    var imagePathArr = [String]()
    @IBOutlet weak var myCarousalView : AACarousel!
    
    @IBOutlet weak var ratingView: EDStarRating!
    @IBOutlet weak var addressLbl: UILabel!
    @IBOutlet weak var hotelNameLbl: UILabel!
    

    @IBOutlet weak var recommendedRoomView: UIView!
    @IBOutlet weak var checkInView: UIView!
    @IBOutlet weak var checkOutView: UIView!
    @IBOutlet weak var roomAndGuestView: UIView!
    @IBOutlet weak var roomDetailView: UIView!
    
    @IBOutlet weak var hotelDescriptionView: UIView!

    
    
    @IBOutlet weak var recommendedRoomHeightCons: NSLayoutConstraint!


    
    @IBOutlet weak var roomAndGuestLbl: UILabel!
    @IBOutlet weak var roomDetailHotelImgView: UIImageView!
    @IBOutlet weak var roomDetailRoomTypeLbl: UILabel!
    @IBOutlet weak var roomDetailAmountLbl: UILabel!
   
    
    @IBAction func roomDetailViewALLBtnTapped(_ sender: UIButton) {
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier:"HotelRoomsVCSBID") as! HotelRoomsVC
        ctrl.theSelectedHotelStruct = selectedHotelStruct
        ctrl.inputDict = self.theInputDict
        ctrl.theDateData = self.dateData
        ctrl.guestAndRoomDetsArr = self.theGuestAndRoomDetailsArr
        self.navigationController?.pushViewController(ctrl, animated: false)
        
        
        /*
        ctrl.theSelectedHotelStruct = self.selectedHotelStruct
        ctrl.inputDict = self.theInputDict
        ctrl.theDateData = self.dateData
        ctrl.selectedRoomIndex = 0
        ctrl.guestAndRoomDetailsArr = self.theGuestAndRoomDetailsArr
        self.navigationController?.pushViewController(ctrl, animated: true) */
    }
    
    @IBOutlet weak var roomDetailInclusionLbl: UILabel!
    @IBOutlet weak var noOfAdultsLbl: UILabel!
    
    @IBOutlet weak var bottomViewRoomTypeLbl: UILabel!
    @IBOutlet weak var bottomViewAmountLbl: UILabel!
    
    var dateDisplayFormat = DateFormatter()
    
    @IBOutlet weak var dateLbl: UILabel!
    @IBOutlet weak var monthAndYearLbl: UILabel!
    @IBOutlet weak var dayLbl: UILabel!
    
    @IBOutlet weak var checkoutDateLbl: UILabel!
    @IBOutlet weak var checkoutMonthAndYearLbl: UILabel!
    @IBOutlet weak var checkoutDayLbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

//        self.alertView.isHidden = true
        
        self.myCarousalView.ImageLoaderStart()
        
        myCarousalView.delegate = self
        myCarousalView.setCarouselOpaque(layer: true, describedTitle: true, pageIndicator: false)
        
        self.hotelNameLbl.text = selectedHotelStruct.HotelName!
        self.addressLbl.text = selectedHotelStruct.Address!
        
        self.ratingView.starImage = UIImage.init(named: "starUnfilled")
        self.ratingView.starHighlightedImage = UIImage.init(named: "starFilled")
        self.ratingView.maxRating = 5
        self.ratingView.horizontalMargin = 0
        self.ratingView.displayMode = UInt(EDStarRatingDisplayFull)
        self.ratingView.rating = Float(self.selectedHotelStruct.StarRating)!
        
        
        dateDisplayFormat.dateFormat = "E, d MMM"
//        let abc = dateDisplayFormat.monthSymbols

        let cal = Calendar.current
        let components = cal.dateComponents([.day, .month, .year, .weekday], from: dateData.checkInDate)
        
        print("Day: \(components.day!)")
        print("Month: \(components.month!)")
        print("Year: \(components.year!)")
        
        
        
        print("weekday = ",cal.component(.weekday, from: dateData.checkInDate))
        print("day = ",cal.component(.day, from: dateData.checkInDate))
        print("month = ",cal.component(.month, from: dateData.checkInDate))
        print("year",cal.component(.year, from: dateData.checkInDate))
        
        

        let checkInDateStr = dateDisplayFormat.string(from: dateData.checkInDate)
        var checkInDateStrArr = checkInDateStr.components(separatedBy: " ")
//        for item in checkInDateStrArr{
//            print("item = ",item)
//        }
//
        self.dateLbl.text = checkInDateStrArr[1]
        self.monthAndYearLbl.text = checkInDateStrArr[2] + ",\(components.year!)"
        checkInDateStrArr[0].remove(at: checkInDateStrArr[0].index(before: checkInDateStrArr[0].endIndex))
        self.dayLbl.text = checkInDateStrArr[0]
        
        let checkOutDateStr = dateDisplayFormat.string(from: dateData.checkOutDate)
        var checkOutDateStrArr = checkOutDateStr.components(separatedBy: " ")
        //        for item in checkInDateStrArr{
        //            print("item = ",item)
        //        }
        //
        self.checkoutDateLbl.text = checkOutDateStrArr[1]
        self.checkoutMonthAndYearLbl.text = checkOutDateStrArr[2] + ",\(components.year!)"
        checkOutDateStrArr[0].remove(at: checkOutDateStrArr[0].index(before: checkOutDateStrArr[0].endIndex))
        self.checkoutDayLbl.text = checkOutDateStrArr[0]
        
        /*
        self.myCalenderView.delegate = self
        self.myCalenderView.dataSource = self
        self.myCalenderView.allowsMultipleSelection = true
        self.myCalenderView.scrollDirection = .vertical */
      
        
        let  tempStr = self.selectedHotelStruct.NoOfRooms + " Room/"
        let a = Int(self.theInputDict["Adult"]!) //gives total number of adults
        let b = Int(self.theInputDict["Child"]!) // gives total number of children
        let c : Int = a! + b!
        self.roomAndGuestLbl.text =  tempStr + "\(c)" + " Guests"
        
        
        if selectedHotelStruct.hotelImgData != nil {
            self.roomDetailHotelImgView.image =  UIImage(data: self.selectedHotelStruct.hotelImgData!)
        }
        if self.selectedHotelStruct.RoomDetailArr.count > 0 {
            self.roomDetailRoomTypeLbl.text = self.selectedHotelStruct.RoomDetailArr[0].RoomDescription
            self.roomDetailInclusionLbl.text = self.selectedHotelStruct.RoomDetailArr[0].inclusions
            
            self.bottomViewRoomTypeLbl.text = self.selectedHotelStruct.RoomDetailArr[0].RoomDescription
        }
        self.noOfAdultsLbl.text = self.theInputDict["Adult"]! + "Adults"
        
        
//         cell.amountLbl.attributedText =  formatAmount(amountSymbol: "\u{20B9}", amount: arrToDisplay[indexPath.row].DispTotalAmount )
//        self.roomDetailAmountLbl.text = formatAmount(amountSymbol: "\u{20B9}", amount: self.selectedHotelStruct.DispTotalAmount)
        
//        self.roomDetailAmountLbl.text = "\u{20B9} " + self.selectedHotelStruct.DispTotalAmount
        self.roomDetailAmountLbl.attributedText = formatAmount(amountSymbol: "PHP", amountSymbolFontSize: 12.0, amount: self.selectedHotelStruct.DispTotalAmount,amountColor:"#29266f", amountFontSize: 18.0)
        
        self.bottomViewAmountLbl.attributedText = formatAmount(amountSymbol: "PHP", amountSymbolFontSize: 12.0, amount: self.selectedHotelStruct.DispTotalAmount,amountColor: "#ffffff", amountFontSize: 18.0)
        
        
        
        
        
//        self.childrenCount = Int(theInputDict["Child"]!)
//        print("Children Count ")
        
       
        
        
       
        
        /*
        print("containerViewHeightCons Initial = ",containerViewHeightCons.constant)
        print("recommendedRoomHeightCons.constant Initial = ",recommendedRoomHeightCons.constant)
        print("calendarContainerHeightCons.constant Initial = ",calendarContainerHeightCons.constant)
        print("roomEditHeightCons Initial = ",roomEditHeightCons.constant)
        print("hotelDescriptionHeightCons Initial = ",hotelDescriptionHeightCons.constant)

        self.containerViewHeightConstraint = containerViewHeightCons.constant
        self.recommendedRoomHeightConstraint = recommendedRoomHeightCons.constant
        self.calendarContainerHeightConstraint = calendarContainerHeightCons.constant
        self.roomEditHeightConstraint = roomEditHeightCons.constant
        self.hotelDescriptionHeightConstraint = hotelDescriptionHeightCons.constant
        
        
        calendarContainerHeightCons.constant = 0
        hideCalendarsChildren()
        roomEditHeightCons.constant = 0
        hideGuestEditsChildren()
        recommendedRoomHeightCons.constant -= self.calendarContainerHeightConstraint + self.roomEditHeightConstraint //(150 + 100)
        containerViewHeightCons.constant -= self.calendarContainerHeightConstraint + self.roomEditHeightConstraint
        
        
        hotelDescriptionHeightCons.constant = 120
        containerViewHeightCons.constant -= (self.hotelDescriptionHeightConstraint - 120)
        
        print("containerViewHeightCons = ",containerViewHeightCons.constant)
        print("recommendedRoomHeightCons.constant = ",recommendedRoomHeightCons.constant)
        print("calendarContainerHeightCons.constant = ",calendarContainerHeightCons.constant)
        print("roomEditHeightCons = ",roomEditHeightCons.constant)
        print("hotelDescriptionHeightCons = ",hotelDescriptionHeightCons.constant) */
        
        self.readAllImgDownArrow = UIImage(named: "downArrowViolet")
        self.readAllImgUpArrow = UIImage(named: "upArrowViolet")
        self.readAllImgView.image = self.readAllImgDownArrow
        
        /*
        //APIType 7 means Hotelbeds. // As of now,no room is selected.so use the first room (RoomDetailArr[0])
        if selectedHotelStruct.APIType == "7" && selectedHotelStruct.RoomDetailArr[0].RateType == "RECHECK"{
                callHotelBedsCheckratesService()
        } */
        self.callGetHotelDetailService()
    }
    /*
    func callHotelBedsCheckratesService(){
        
        showLoading()
        
        let inputDict = ["RoomBookingCode":selectedHotelStruct.RoomDetailArr[0].RoomBookingCode!,
                         "NoOfRooms":selectedHotelStruct.NoOfRooms!,
                         "NoOfNights":selectedHotelStruct.NoOfNights!,
                         "CityCode":theInputDict["CityCode"]!,
                         "ctype":theInputDict["ctype"]!,
                         "ReqType":"JSON"
                         ]
        print("Input Dict - callHotelBedsCheckratesService = ",inputDict)
        
        
        if (Reachability()?.isReachable)! {
            WebService().HTTP_POST_WebServiceMethod_Hotel(mainURL: WebServicesUrl.HotelServiceUrl, suffix: WebServicesUrl.HotelBedsCheckrates, parameterDict: inputDict) { (ResponseArr, ResponseStatus) in
                hideLoading()
                
                if ResponseStatus {
                    print("HotelBedsCheckrates Service call success ..........")
                    
                    //                    self.flightResultArr = responce["FlightResult"] as! [[String:AnyObject]]
                    
                    let fullResponseArr = ResponseArr as! [[String:AnyObject]]
                    let responseDict = fullResponseArr[0]
                    
                    self.selectedHotelStruct.RoomDetailArr[self.selectedRoomIndex].Cancellationpolicy = "\(responseDict["Cancellationpolicy"]!)"
                    self.selectedHotelStruct.RoomDetailArr[self.selectedRoomIndex].NewFare = "\(responseDict["TotalAmountMarkupWithTax"]!)"
                    
                    let oldFare = Float(self.selectedHotelStruct.RoomDetailArr[self.selectedRoomIndex].TotalAmountMarkupWithTax)
                    let newFare = Float(self.selectedHotelStruct.RoomDetailArr[self.selectedRoomIndex].NewFare)! + 1.0
                    if oldFare == newFare {
                        print("Fares are same...")
                    }else{
                        self.alertView.isHidden = false
                    }
                    
                }else{
                    print("Service call failure ..........")
                    print("Try after sometimes...internet connetivity Problem....")
                }
            }
        }else{
             print("No Internet......")
        }
        
        
    }
    
    @IBOutlet weak var alertView: UIView!
    @IBOutlet weak var alertViewLbl: UILabel!
    @IBAction func alertViewCancelBtnTapped(_ sender: UIButton) {
        print("AlertView Cncel Tapped..")
        self.alertView.isHidden = true
//        let ctrl = storyboard?.instantiateViewController(withIdentifier: "HomePageVC") as! HomePageVC
//        self.navigationController?.popToViewController(ctrl, animated: true)
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    @IBAction func alertViewOKBtnTapped(_ sender: UIButton) {
        self.alertView.isHidden = true
        print("AlertView OK Tapped..So do Nothing")
    } */
    
//    @IBOutlet weak var checkinDateContainer: UIView!
//    @IBOutlet weak var checkoutDateContainer: UIView!
    @IBOutlet weak var roomAndGuestContainer: UIView!
//    @IBOutlet weak var checkinDateView: UIView!
//    @IBOutlet weak var checkoutDateView: UIView!
    @IBOutlet weak var roomGuestView: UIView!
    
   
    @IBOutlet weak var roomDetailBookNowBtn: UIButton!
    @IBOutlet weak var bottomViewBookNowBtn: UIButton!
    
    override func viewWillLayoutSubviews() {
//        setCornerRadiusFor(theView: checkinDateContainer , radius: 5.0)
//        setCornerRadiusFor(theView: checkoutDateContainer , radius: 5.0)
//        setCornerRadiusFor(theView: roomAndGuestContainer , radius: 5.0)
        
//        checkinDateView.clipsToBounds = true
//        checkoutDateView.clipsToBounds = true
//        roomGuestView.clipsToBounds = true
        
//        checkinDateView.layer.masksToBounds = true
        
        
        roomDetailBookNowBtn.layer.cornerRadius = 5.0
        bottomViewBookNowBtn.layer.cornerRadius = 5.0
        
    }
    
    /*
    func hideGuestEditsChildren(){
        self.guestEditView.subviews.forEach { $0.isHidden = true}
    }
    func showGuestEditsChildren(){
        self.guestEditView.subviews.forEach { $0.isHidden = false}
    }
    func hideCalendarsChildren(){
        self.calendarContainerView.subviews.forEach { $0.isHidden = true}
    }
    func showCalendarsChildren(){
        self.calendarContainerView.subviews.forEach { $0.isHidden = false}
    }
    @IBAction func checkInBtnTapped(_ sender: UIButton) {
        
        if !(sender.isSelected) {
            sender.isSelected = true
            calendarContainerHeightCons.constant = self.calendarContainerHeightConstraint
            showCalendarsChildren()
            recommendedRoomHeightCons.constant +=  self.calendarContainerHeightConstraint
            containerViewHeightCons.constant += self.calendarContainerHeightConstraint
            
            print("containerViewHeightCons = ",containerViewHeightCons.constant)
            print("recommendedRoomHeightCons.constant = ",recommendedRoomHeightCons.constant)
            print("calendarContainerHeightCons.constant = ",calendarContainerHeightCons.constant)
            print("roomEditHeightCons = ",roomEditHeightCons.constant)
        }else{
            sender.isSelected = false
            calendarContainerHeightCons.constant = 0
            hideCalendarsChildren()
            recommendedRoomHeightCons.constant -=  self.calendarContainerHeightConstraint
            containerViewHeightCons.constant -= self.calendarContainerHeightConstraint
            
            print("containerViewHeightCons = ",containerViewHeightCons.constant)
            print("recommendedRoomHeightCons.constant = ",recommendedRoomHeightCons.constant)
            print("calendarContainerHeightCons.constant = ",calendarContainerHeightCons.constant)
            print("roomEditHeightCons = ",roomEditHeightCons.constant)
        }
    }
    
    @IBAction func roomAndGuestBtnTapped(_ sender: UIButton) {

        if !(sender.isSelected){
            sender.isSelected = true
            roomEditHeightCons.constant = self.roomEditHeightConstraint
            showGuestEditsChildren()
            recommendedRoomHeightCons.constant +=  self.roomEditHeightConstraint
            containerViewHeightCons.constant += self.roomEditHeightConstraint
            
            print("containerViewHeightCons = ",containerViewHeightCons.constant)
            print("recommendedRoomHeightCons.constant = ",recommendedRoomHeightCons.constant)
            print("calendarContainerHeightCons.constant = ",calendarContainerHeightCons.constant)
            print("roomEditHeightCons = ",roomEditHeightCons.constant)
        }else{
            sender.isSelected = false
            roomEditHeightCons.constant = 0
            hideGuestEditsChildren()
            recommendedRoomHeightCons.constant -=  self.roomEditHeightConstraint
            containerViewHeightCons.constant -= self.roomEditHeightConstraint
            
            print("containerViewHeightCons = ",containerViewHeightCons.constant)
            print("recommendedRoomHeightCons.constant = ",recommendedRoomHeightCons.constant)
            print("calendarContainerHeightCons.constant = ",calendarContainerHeightCons.constant)
            print("roomEditHeightCons = ",roomEditHeightCons.constant)
        }
        
        
        
    } */
    
    
    @IBOutlet weak var hotelDescriptionReadAllBtn: UIButton!
    @IBOutlet weak var hotelDescriptionLbl: UILabel!
    
    @IBOutlet weak var readAllImgView: UIImageView!
    var readAllImgDownArrow : UIImage!
    var readAllImgUpArrow : UIImage!
    
    @IBOutlet weak var hotelDescriptionViewHeightCons: NSLayoutConstraint!
    @IBOutlet weak var hotelDescriptionLblHeightCons: NSLayoutConstraint!
    var isLabelAtMaxHeight = false
    
    @IBAction func hotelDescriptionReadAllBtnTapped(_ sender: UIButton) {
        if isLabelAtMaxHeight {
            hotelDescriptionReadAllBtn.setTitle("Read All", for: .normal)
            self.readAllImgView.image = self.readAllImgDownArrow
            isLabelAtMaxHeight = false
            hotelDescriptionLblHeightCons.constant = 70
            hotelDescriptionViewHeightCons.constant = 100
        }
        else {
            hotelDescriptionReadAllBtn.setTitle("Read Less", for: .normal)
            self.readAllImgView.image = self.readAllImgUpArrow
            isLabelAtMaxHeight = true
            hotelDescriptionLblHeightCons.constant = getLabelHeight(text: self.hotelDescriptionLbl.text! , width: hotelDescriptionLbl.bounds.width,font: hotelDescriptionLbl.font)
            hotelDescriptionViewHeightCons.constant = hotelDescriptionLblHeightCons.constant + 30
//            self.hotelDescriptionLbl.text = "Nov 21, 2018 - In this tutorial, you'll learn how to enable self-sizing table view cells, as well . Update note: Kevin Colligan updated this tutorial for Xcode 10, iOS 12 and Swift 4.2. .Your cell heights will need to be dynamic, based on the content of each cell. .A label with its number of lines set to 0 will grow based on how Not the answer you're looking for? Browse other questions tagged This site contains user submitted content, comments and opinions and is for informational purposes only.I would suggest you the ilyapuchka ReadMoreTextView library which is on this link. It is the easiest way to achieve this and it is retty lightweight.You can install it with CocoaPods, just implement pod 'ReadMoreTextView' into the podfile and you can use it likie this:"
        }
    }
    func getLabelHeight(text: String, width: CGFloat, font: UIFont) -> CGFloat {
        let lbl = UILabel(frame: .zero)
        lbl.frame.size.width = width
        lbl.font = font
        lbl.numberOfLines = 0
        lbl.text = text
        lbl.sizeToFit()
        
        
        return lbl.frame.size.height
    }

        /*
        if !(sender.isSelected){
            sender.isSelected = true
            hotelDescriptionHeightCons.constant = self.hotelDescriptionHeightConstraint
            containerViewHeightCons.constant += (self.hotelDescriptionHeightConstraint - 120)
            
            print("containerViewHeightCons = ",containerViewHeightCons.constant)
            print("recommendedRoomHeightCons.constant = ",recommendedRoomHeightCons.constant)
            print("calendarContainerHeightCons.constant = ",calendarContainerHeightCons.constant)
            print("roomEditHeightCons = ",roomEditHeightCons.constant)
            print("hotelDescriptionHeightCons = ",hotelDescriptionHeightCons.constant)
            self.hotelDescriptionReadAllBtn.setTitle("Read Less", for: .normal)
            
            self.readAllImgView.image = self.readAllImgUpArrow
        }else{
            sender.isSelected = false
            hotelDescriptionHeightCons.constant = 120
            containerViewHeightCons.constant -= (self.hotelDescriptionHeightConstraint - 120)
            
            print("containerViewHeightCons = ",containerViewHeightCons.constant)
            print("recommendedRoomHeightCons.constant = ",recommendedRoomHeightCons.constant)
            print("calendarContainerHeightCons.constant = ",calendarContainerHeightCons.constant)
            print("roomEditHeightCons = ",roomEditHeightCons.constant)
            print("hotelDescriptionHeightCons = ",hotelDescriptionHeightCons.constant)
            self.hotelDescriptionReadAllBtn.setTitle("Read All", for: .normal)
            self.readAllImgView.image = self.readAllImgDownArrow
        } */
    
    
    
    
    
    
    
    func callGetHotelDetailService(){
        
        if (Reachability()?.isReachable)! {
            //            showLoading()
            let DictInput = [
                "HotelID":selectedHotelStruct.HotelUniqueKey!,
                "apiname":selectedHotelStruct.APIType!, //selectedHotelStruct.RoomDetailArr.count > 0 ? selectedHotelStruct.RoomDetailArr[0].RoomDetailAPIType : selectedHotelStruct.APIType
                
                //"prid":selectedHotelStruct.processId!,
                "prid": selectedHotelStruct.processId ?? "", //"",
                
                /* "HotelCity":selectedHotelStruct.city!,
                 "HotelCountry":selectedHotelStruct.country!, */
                
                "CityCode":theInputDict["CityCode"]!,
                "ReqType":"json"
            ]
            print("InputDict for HotelDetail service = ",DictInput)
            
            
            WebService().HTTP_POST_WebServiceMethod_Hotel(mainURL: WebServicesUrl.HotelServiceUrl, suffix: WebServicesUrl.HotelDetails, parameterDict: DictInput as! [String : String]) { (ResponseArr, ResponseStatus) in
                hideLoading()
                
                if ResponseStatus {
                    print("Service call success ..........")
                    
                    //                    self.flightResultArr = responce["FlightResult"] as! [[String:AnyObject]]
                    
                    let fullResponseArr = ResponseArr as! [[String:AnyObject]]
                    for aDict in fullResponseArr {
                        var aHFGContainerStruct = HFGContainerStruct()
                        let TempHoteltlArr = aDict["hoteltl"] as! [[String:AnyObject]]
                        let TempFacilitytlArr = aDict["facilitytl"] as! [[String:AnyObject]]
                        let TempGallerytlArr = aDict["gallerytl"] as! [[String:AnyObject]]
                        let TempReviewtlArr = aDict["reviewtl"] as! [String:AnyObject]
                        
                        self.hoteltlArr.removeAll()
                        for aHotelDict in TempHoteltlArr{
                            var aHotelStru = HoteltlStruct()
                            
                            /*
                             aHotelStru.Address = "\(aHotelDict["Address"]!)"
                             aHotelStru.hotel_name = "\(aHotelDict["hotel_name"]!)" */
                            
                            /*
                             aHotelStru.latitude = "\(aHotelDict["Latitude"]!)"
                             aHotelStru.longitude = "\(aHotelDict["Longitude"]!)"
                             aHotelStru.description = "\(aHotelDict["description"]!)" */
                            
                            aHotelStru.overview = "\(aHotelDict["overview"]!)"
                            
                            self.hoteltlArr.append(aHotelStru)
                        }
                        
                        /*
                         DispatchQueue.main.async() {
                         self.descriptionLbl.text = self.hoteltlArr[0].description!
                         } */
                        
                        self.hotelDescriptionStr = self.hoteltlArr[0].overview!
                        self.hotelDescriptionLbl.text = self.hotelDescriptionStr
                            
                        self.facilitytlArr.removeAll()
                        for aFacilityDict in TempFacilitytlArr{
                            var aFacilityStru = FacilitytlStruct()
                            //                            aFacilityStru.amenity_text = "\(aFacilityDict["amenity_text"]!)"
                            
                            aFacilityStru.Facility = "\(aFacilityDict["Facility"]!)"
                            aFacilityStru.FacilityType = "\(aFacilityDict["FacilityType"]!)"
                            
                            self.facilitytlArr.append(aFacilityStru)
                            
                        }
                        
                        self.imagePathArr.removeAll()
                        self.gallerytlArr.removeAll()
                        for galDict in TempGallerytlArr{
                            var aGalStr = GallerytlStruct()
                            //aGalStr.wide_angle_Image_Url = "\(galDict["wide_angle_Image_Url"]!)"
                            /* aGalStr.thumb_nail_image_Url = "\(galDict["thumb_nail_image_Url"]!)" */
                            aGalStr.imagepath = "\(galDict["imagepath"]!)"
                            
                            
                            self.gallerytlArr.append(aGalStr)
                            self.imagePathArr.append(aGalStr.imagepath)
                            //                            self.imagePathArr.append(aGalStr.thumb_nail_image_Url)
                        }
                        
                        
                        aHFGContainerStruct.HoteltlArr = self.hoteltlArr
                        aHFGContainerStruct.FaciltytlArr = self.facilitytlArr
                        aHFGContainerStruct.GallerytlArr = self.gallerytlArr
                        
                        self.HFGContainerArr.append(aHFGContainerStruct)
                        print("Hotel Detail service success..")
                    }
                    
                    print("HFG Container Array count: ",self.HFGContainerArr.count)
                    print("self.HFGContainerArr[0].HoteltlArr.count = ",self.HFGContainerArr[0].HoteltlArr.count)
                    print("self.HFGContainerArr[0].FaciltytlArr.count = ",self.HFGContainerArr[0].FaciltytlArr.count)
                    print("self.HFGContainerArr[0].GallerytlArr.count = ",self.HFGContainerArr[0].GallerytlArr.count)
                    
                    //                    cell.hotelImgView.sd_setShowActivityIndicatorView(true)
                    //                    cell.hotelImgView.sd_setIndicatorStyle(.gray)
                    
                    
                    //                    self.myCarousalView.sd_setShowActivityIndicatorView(true)
                    //                    self.myCarousalView.sd_setIndicatorStyle(.gray)
                    
//                    self.myCarousalView.ImageLoaderStart()
                    
                    for aStr in self.imagePathArr {
                        print("The Img url = ",aStr)
                    }
                    self.myCarousalView.setCarouselData(paths: self.imagePathArr, describedTitle: ["MyTitle"], isAutoScroll: true, timer: 50.0, defaultImage: nil)
                    
                    
                    self.myCarousalView.ImageLoaderStop()
                    
                    //The following is for gettting Hotel Description
//                    print("Selected HotelStruct = ",self.selectedHotelStruct)
                    if self.selectedHotelStruct.RoomDetailArr[self.selectedRoomIndex].rateComments_Id != "" {
                        if self.selectedHotelStruct.APIType == "7"{
                            self.callHotelBedsratecommentsService(id: self.selectedHotelStruct.RoomDetailArr[self.selectedRoomIndex].rateComments_Id)
                        }
                    }
                  
                    
                }else{
                    print("Service call failure ..........")
                    print("Try after sometimes...internet connetivity Problem....")
                    self.myCarousalView.ImageLoaderStop()
                    //                    self.view.ShowBlackTostWithText(message: "Try after sometimes...internet connetivity Problem....", Interval: 2)
                    
                    if self.selectedHotelStruct.RoomDetailArr[self.selectedRoomIndex].rateComments_Id != "" {
                        if self.selectedHotelStruct.APIType == "7"{
                            self.callHotelBedsratecommentsService(id: self.selectedHotelStruct.RoomDetailArr[self.selectedRoomIndex].rateComments_Id)
                        }
                    }
                    
                }
            }
            
            
        }
        else{
            print("No Internet......")
            self.view.ShowBlackTostWithText(message: "Check Your internet Connection", Interval: 3)
            self.myCarousalView.ImageLoaderStop()
            //            self.dataTVContainerView.isHidden = true
            //            self.errorLbl.text = "Internet connetivity Problem!!!"
        }
    }
    func callHotelBedsratecommentsService(id : String){
        if (Reachability()?.isReachable)! {
            //            showLoading()
            let DictInput = [
                "HotbedsrateC_Id":id,
                "CheckIn":self.theInputDict["CheckIndate"]!
            ]
            print("InputDict for HotelBeds ratecomments  service = ",DictInput)
            
            WebService().HTTP_POST_WebServiceMethod_Profile(mainURL: WebServicesUrl.HotelServiceUrl, suffix: WebServicesUrl.HotelBedsRateComments, parameterDict: DictInput as! [String : String]) { (ResponseDict, ResponseStatus) in
                
                if ResponseStatus {
                    print("Service call success ..........")
                    let fullResponse = ResponseDict as! [String:String]
                    print("Reponse from HotelBedsRateComments Service",fullResponse)
                    
                    self.hotelDescriptionStr = self.hotelDescriptionStr +  "\(fullResponse["Result"]!)"
                    self.hotelDescriptionLbl.text = self.hotelDescriptionStr
                    
                    
                    
                }else{
                    print("Service call failure ..........")
                    print("Try after sometimes...internet connetivity Problem....")
                }
            }
            
            
        }else{
             print("No Internet......")
            self.view.ShowBlackTostWithText(message: "Check Your internet Connection", Interval: 3)
        }
    }
    @IBAction func backBtnTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }

    @IBAction func bottomViewBookNowBtnTapped(_ sender: UIButton) {
//        let ctrl = self.storyboard?.instantiateViewController(withIdentifier:"HotelBookingVCSBID") as! HotelBookingVC
        
          let ctrl = self.storyboard?.instantiateViewController(withIdentifier:"ReviewHotelVCSBID") as! HotelReviewVC
        
        ctrl.theSelectedHotelStruct = self.selectedHotelStruct
        ctrl.inputDict = self.theInputDict
        ctrl.theDateData = self.dateData
        ctrl.selectedRoomIndex = self.selectedRoomIndex
        ctrl.guestAndRoomDetailsArr = self.theGuestAndRoomDetailsArr
        self.navigationController?.pushViewController(ctrl, animated: true)
    }
    
    @IBAction func roomDetailBookNowBtnTapped(_ sender: UIButton) {
//        let ctrl = self.storyboard?.instantiateViewController(withIdentifier:"HotelBookingVCSBID") as! HotelBookingVC
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier:"ReviewHotelVCSBID") as! HotelReviewVC
        ctrl.theSelectedHotelStruct = self.selectedHotelStruct
        ctrl.inputDict = self.theInputDict
        ctrl.theDateData = self.dateData
        ctrl.selectedRoomIndex = self.selectedRoomIndex
        ctrl.guestAndRoomDetailsArr = self.theGuestAndRoomDetailsArr
        self.navigationController?.pushViewController(ctrl, animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension HotelDetailVC : AACarouselDelegate {
    
    //    func callBackFirstDisplayView(_ imageView: UIImageView, _ url: [String], _ index: Int) {
    //        imageView.sd_setImage(with: URL(string: url[index]), completed: nil)
    //    }
    
    
    func callBackFirstDisplayView(_ imageView: UIImageView, _ url: [String], _ index: Int) {
        imageView.sd_setImage(with: URL(string: url[index]), completed: nil)
    }
    
    func downloadImages(_ url: String, _ index: Int) {
        print("THe Url is :",url)
        /*
        let imgView = UIImageView()
        imgView.sd_setImage(with: URL(string: url)!) { (downloadImage, error, cacheType, url) in
            
            if error == nil{
                self.myCarousalView.images[index] = downloadImage!
            }else{
                print("The error is : \(error)")
            }
        } */
        
//        SDWebImageManager.shared().downloadImage(with: NSURL(string: "...") as URL!, options: .continueInBackground, progress: {
//            (receivedSize :Int, ExpectedSize :Int) in
//
//        }, completed: {
//            (image : UIImage?, error : Error?, cacheType : SDImageCacheType, finished : Bool, url : URL?) in
//
//        })
//        SDWebImageManager *manager = [SDWebImageManager sharedManager];

        
        
//        SDWebImageManager *manager = [SDWebImageManager sharedManager];
//        [manager loadImageWithURL:imageURL
//            options:0
//            progress:nil
//            completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, BOOL finished, NSURL *imageURL) {
//            if (image) {
//            // do something with image
//            }
//            }];
        
        let mgr : SDWebImageManager = SDWebImageManager.shared()
        mgr.loadImage(with: URL(string: url), options: [] , progress: nil) { (downloadedImg, downloadedImgData, myError, nil, finishedFlag , myURL) in
            if finishedFlag {
                if downloadedImg != nil{
                    self.myCarousalView.images[index] = downloadedImg!
                }else{
                    print("THe Error = ",myError)
                }
            }else{
                print("The error is : \(myError)")
            }
        }
    }
    
}
extension HotelDetailVC : FSCalendarDelegate,FSCalendarDataSource,FSCalendarDelegateAppearance {
    func minimumDate(for calendar: FSCalendar) -> Date {
        
        /*
         else{
         if calendarFlagHotel == "checkinCalender" {
         return Date()
         }else{
         return self.selectedCheckinDate.addingTimeInterval(oneDay)
         }
         } */
        
        return Date()
    }
    
    //    func calendar(_ calendar: FSCalendar, appearance: FSCalendarAppearance, titleSelectionColorFor date: Date) -> UIColor? {
    //        calendar.deselect(date)
    //        return UIColor.green
    //    }
    
    func calendar(_ calendar: FSCalendar, willDisplay cell: FSCalendarCell, for date: Date, at monthPosition: FSCalendarMonthPosition) {
        calendar.appearance.titleTodayColor = UIColor.red
    }
    
    
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        print("a Date selected....")
    }
    
    func calendar(_ calendar: FSCalendar, didDeselect date: Date, at monthPosition: FSCalendarMonthPosition) {
        print("a Date Deselected....")
    }
   
    
    
}
