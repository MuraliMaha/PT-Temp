//
//  HotelNationalityVC.swift
//  UniOrient
//
//  Created by APPLE on 21/05/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

protocol HotelNationalityDelegate {
    func didSelectNation(selectedHotelNationalityStruct : HotelNationalityStruct,controller : HotelNationalityVC)
}

class HotelNationalityVC: UIViewController {
    
    @IBOutlet weak var pickANationLbl: UILabel!
    @IBOutlet weak var searchTxtField: UITextField!
    @IBOutlet weak var nationTV: UITableView!
    
    var hotelNationalityStructArr = [HotelNationalityStruct]()
    var searchResultsArray = [HotelNationalityStruct]()
    
    var delegateVariable : HotelNationalityDelegate!
    //    var countryType : String?
    
    var viewLodedFlag : Bool!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.viewLodedFlag = true
        self.pickANationLbl.isHidden = true
        
        self.nationTV.dataSource = self
        self.nationTV.delegate = self
        
        self.searchTxtField.delegate = self
        //        hotelPlacesStructArr = hotelCityStructArrGlobal
        
        //        self.searchTxtField.becomeFirstResponder()
        self.nationTV.isHidden = true
        
        
        let toolBar = UIToolbar()
        toolBar.barStyle = UIBarStyle.default
        //        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor.white
        //        toolBar.backgroundColor = hexStringToUIColor(hex: "#AFCA1F")
        toolBar.barTintColor = hexStringToUIColor(hex: "#100055")
        toolBar.sizeToFit()
        
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.plain, target: self, action:#selector(donePicker))
        
        toolBar.setItems([spaceButton, doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        
        //        dateOfBirthTxtField.inputView = DOBDatePicker
        searchTxtField.inputAccessoryView = toolBar
        
        showLoading()
        self.callNationalityListService_Hotel(messageDict: ["ReqType" : "JSON"], searchString: "viewLoaded")
    }
    @objc func donePicker(sender : UIBarButtonItem) {
        if searchTxtField.isFirstResponder {
            self.searchTxtField.resignFirstResponder()
            print("change to gray color by donebtn")
            self.searchTxtField.placeholder = "Pick your Country"
            //            self.pickACityLbl.isHidden = true
        }
        if (searchTxtField.text?.isEmpty)! {
            self.pickANationLbl.isHidden = true
        }else{
            
        }
    }
    @IBAction func backBtnTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    override func viewWillAppear(_ animated: Bool) {
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.textChangeNotification), name:UITextField.textDidChangeNotification, object: nil)
        
    }
    override func viewWillDisappear(_ animated: Bool) {
        //        NotificationCenter.default.removeObserver(self, name: .UITextField.textDidChangeNotification , object: nil)
        NotificationCenter.default.removeObserver(self, name: UITextField.textDidChangeNotification, object: nil)
    }
    @objc func textChangeNotification(_ notification : Notification){
        print("SearchTextField changed")
        self.viewLodedFlag = false
        self.pickANationLbl.isHidden = false
        self.nationTV.isHidden = false
        //        searchRecordsAsPerText(searchStr : searchTxtField.text!)
        searchRecordsAsPerTextFromService(searchStr: searchTxtField.text!)
    }
    func searchRecordsAsPerTextFromService(searchStr : String){
        searchResultsArray.removeAll()
        
        if searchStr.count > 0 {
            let inputDict = ["ReqType" : "JSON"]
            print("Input Dict = ",inputDict)
            
            if (Reachability()?.isReachable)! {
                callNationalityListService_Hotel(messageDict: inputDict, searchString: searchStr)
            }else{
                print("No Internet....")
                self.view.ShowBlackTostWithText(message: "Check Your internet Connection", Interval: 3)
            }
        }else{
            print("Search String count = ",searchStr.count)
            searchResultsArray.removeAll()
            self.nationTV.isHidden = true
        }
        
        
    }
    func callNationalityListService_Hotel(messageDict : [String:String],searchString : String) {
        //        WebService().HTTP_POST_WebServiceMethod_Hotel(mainURL: WebServicesUrl.HotelServiceUrlLive, suffix: WebServicesUrl.HotelResult, parameterDict: messageDict) { (ResponseArr, ResponseStatus) in
        //            hideLoading()
        
        
        WebService().HTTP_POST_WebServiceMethod_Hotel(mainURL: WebServicesUrl.HotelServiceUrl, suffix: WebServicesUrl.GetNationality, parameterDict: messageDict) { (ResponseArr, ResponseStatus) in
            
            hideLoading()
            if ResponseStatus {
                
                let fullResponseArr = ResponseArr as! [[String:AnyObject]]
                self.hotelNationalityStructArr.removeAll()
                for aDict in fullResponseArr {
                    var aStruct = HotelNationalityStruct()
                    aStruct.CountryCode = "\(aDict["CountryCode"]!)"
                    aStruct.CountryName = "\(aDict["CountryName"]!)"
                    self.hotelNationalityStructArr.append(aStruct)
                }
           //------- Ascending order
                
                self.hotelNationalityStructArr.sort { (hotelStruct1, hotelStruct2) -> Bool in
                    return hotelStruct1.CountryName < hotelStruct2.CountryName
                }
                
        //--------------
                
        print("count : ",self.hotelNationalityStructArr.count)
                
        //------- Moving Philippines to Top
                for index in 0..<self.hotelNationalityStructArr.count
                {
                    print(index)
                    if self.hotelNationalityStructArr[index].CountryName == "PHILIPPINES"
                    {
                        let temp = self.hotelNationalityStructArr.remove(at: index)
                        self.hotelNationalityStructArr.insert(temp, at: 0)
                    }
                }
                print("first ",self.hotelNationalityStructArr[0])
        //--------------
                
                if self.viewLodedFlag{
                    self.searchResultsArray = self.hotelNationalityStructArr
                }else{
                    let Filtered = self.hotelNationalityStructArr.filter({$0.CountryName!.localizedCaseInsensitiveContains(searchString)})
                    self.searchResultsArray = Filtered
                    
                }
                
                //        print(Filtered)
                
                if (searchString == "") {
                    self.nationTV.isHidden = true
                }
                else {
                    if self.searchResultsArray.count == 0 {
                        self.nationTV.isHidden = true
                    }
                    self.nationTV.isHidden = false
                }
                self.nationTV.reloadData()
                
            }else{
                print("ResponseStatus :",ResponseStatus)
            }
            
        }
    
    }
    
 
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
// MARK: - TextFieldDelegate {
extension HotelNationalityVC : UITextFieldDelegate{
    
    /*
     func textFieldShouldReturn(_ textField: UITextField) -> Bool{
     if !nationTV.isHidden{
     nationTV.isHidden = true
     }
     textField.resignFirstResponder()
     return true
     } */
    func textFieldDidBeginEditing(_ textField: UITextField) {
        print("Change color textFieldDidBeginEditing ")
        textField.placeholder = ""
        self.pickANationLbl.isHidden = false
    }
    
}
// MARK: - }

//MARK: - TableViewDelegate {

extension HotelNationalityVC : UITableViewDataSource,UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return searchResultsArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "HotelNationalityCellID", for: indexPath) as! HotelNationalityCellClass
        cell.containerView.layer.cornerRadius = 5
        cell.containerView.clipsToBounds = true
        
        if searchResultsArray.count > 0 {
            cell.countryNameLbl.text = self.searchResultsArray[indexPath.row].CountryName
        }
        
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let cell : HotelNationalityCellClass!
        
        cell = tableView.cellForRow(at: indexPath) as? HotelNationalityCellClass
        print("Row:\(indexPath.row) selected and its countryName is \(cell.countryNameLbl.text!)")
        
        
        self.nationTV.isHidden = true
        self.searchTxtField.text = ""
        searchTxtField.resignFirstResponder()
        
        delegateVariable.didSelectNation(selectedHotelNationalityStruct: searchResultsArray[indexPath.row], controller: self)
    }
}
//MARK: - }
class HotelNationalityCellClass : UITableViewCell {
    
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var countryNameLbl: UILabel!
}
