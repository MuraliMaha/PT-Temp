//
//  UpdateProfileViewController.swift
//  UniOrient
//
//  Created by Pranas on 22/05/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

class UpdateProfileViewController: UIViewController {
    @IBOutlet weak var mrBtn: UIButton!
    @IBOutlet weak var mrsbtn: UIButton!
    @IBOutlet weak var msBtn: UIButton!
    
    @IBOutlet weak var txtPassportNumber: UITextField!
    @IBOutlet weak var txtFirstName: UITextField!
    @IBOutlet weak var txtLastName: UITextField!
    @IBOutlet weak var txtDOB: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var txtMobileNum: UITextField!
 
    @IBOutlet weak var txtPswd: UITextField!
    var dateString : String!
     var strTitle : String!
    var strFirstName : String = String()
    var strLastName : String = String()
    var strEmail : String = String()
    var strMobileNo : String = String()
    var strDOB : String = String()
    var strPassword : String = String()
    var strPassportNo : String = String()
    var DOBDatePicker: UIDatePicker!
    var dateFormatter = DateFormatter()
    var isKeyboardVisible : Bool = false
   
    override func viewDidLoad() {
        super.viewDidLoad()

        if strTitle == "Mr"
        {
           self.mrBtn.isSelected = true
            selectedTitle = "Mr"
        }
        else if strTitle == "Mrs"
        {
            self.mrsbtn.isSelected = true
            selectedTitle = "Mrs"
        }
        else if strTitle == "Ms"
        {
            self.msBtn.isSelected = true
            selectedTitle = "Ms"
        }
        self.txtFirstName.text = self.strFirstName
        self.txtLastName.text = self.strLastName
        self.txtEmail.text = self.strEmail
        self.txtMobileNum.text = self.strMobileNo
        self.txtDOB.text = self.strDOB
        self.txtPswd.text = self.strPassword
        self.txtPassportNumber.text = self.strPassportNo
        DOBDatePicker = UIDatePicker()
        dateFormatter.dateFormat = "dd-MMM-yyyy"
        dateString = dateFormatter.string(from: Date())
        
        let toolBar = UIToolbar()
        toolBar.barStyle = UIBarStyle.default
        //        toolBar.isTranslucent = true
        toolBar.tintColor = UIColor.white
        //        toolBar.backgroundColor = hexStringToUIColor(hex: "#AFCA1F")
        toolBar.barTintColor = hexStringToUIColor(hex: "#16137c")
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.plain, target: self, action:#selector(donePicker))
        
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
       
        let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItem.Style.plain, target: self, action:#selector(cancelPicker))
        
        toolBar.setItems([cancelButton, spaceButton, doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        
        //        myDatePicker.datePickerMode = UIDatePickerMode.date
        DOBDatePicker.datePickerMode = UIDatePicker.Mode.date
        
        txtDOB.inputView = DOBDatePicker
        txtDOB.inputAccessoryView = toolBar
        
        let Toolbar = UIToolbar(frame: CGRect.init(x: 0, y: 0, width: self.view.frame.width, height: 40))
        //        let Toolbar = UIToolbar()
        Toolbar.barStyle = .default
        
        Toolbar.isTranslucent = true
        //        Toolbar.backgroundColor = hexStringToUIColor(hex: "#AFCA1F")
        Toolbar.barTintColor = hexStringToUIColor(hex: "#16137c")
        Toolbar.tintColor = UIColor.white
        
        let DoneItem = UIBarButtonItem.init(title: "Done", style: .done, target: self, action: #selector(PickDoneAction(_:)))
        let FlexiItem = UIBarButtonItem.init(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        
        Toolbar.setItems([FlexiItem,DoneItem], animated: true)
        Toolbar.isUserInteractionEnabled = true
        
    }
    
    @objc func donePicker(sender : UIBarButtonItem) {
        
        if txtDOB.isFirstResponder {
            txtDOB.text = dateString
            self.txtDOB.resignFirstResponder()
        }
    }
    
    @objc func cancelPicker(sender : UIBarButtonItem ){
        if txtDOB.isFirstResponder {
            self.txtDOB.resignFirstResponder()
        }
    }
    @objc func PickDoneAction(_ sender:UIBarButtonItem) {
        self.view.endEditing(true)
    }
    //MARK: - Keyboard show
    var keyboardSize : CGRect?
    @objc func keyboardWillShow(_ notification : NSNotification){
        
        keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue
        if !self.isKeyboardVisible{
            
            self.view.frame.origin.y -= 150.0//keyboardSize!.height
            
        }
        self.isKeyboardVisible = true
        
    }
    
    @objc func keyboardWillHide(_ notification : NSNotification)
    {
        if keyboardSize != nil{ // this condition is for, when keyboard is visible and tapping on backBtn crashes as self.keyboardSize is nil
            self.view.frame.origin.y += 150.0//keyboardSize!.height
            self.isKeyboardVisible = false
        }else{
            print("KeyboardSize is nil ")
        }
        
    }
    
    @IBAction func signUpBtn(_ sender: UIButton)
    {
        if !(Reachability()!.isReachable) {
            print("No Internet from Register..................")
        }
        else
        {
            if txtFirstName.text == ""
            {
                String().alert(view: self, title: "UniOrient Info", message: "Enter First Name")
            }
            if txtLastName.text == ""
            {
                String().alert(view: self, title: "UniOrient Info", message: "Enter Last Name")
            }
            if txtDOB.text == ""
            {
                String().alert(view: self, title: "UniOrient Info", message: "Enter DOB")
            }
            else if txtEmail.text == ""
            {
                String().alert(view: self, title: "UniOrient Info", message: "Enter Email ID")
            }
            else if txtPswd.text == ""
            {
                String().alert(view: self, title: "UniOrient Info", message: "Enter Password")
            }
          
            else if txtMobileNum.text == ""
            {
                String().alert(view: self, title: "UniOrient Info", message: "Enter Phone Number")
            }
            else if txtPassportNumber.text == ""
            {
                String().alert(view: self, title: "UniOrient Info", message: "Enter Passport Number")
            }
            else{
                callRegisterService()
            }
            
        }
    }
    
    var selectedTitle : String!
    
    @IBAction func mrBtnTapped(_ sender: UIButton) {
        print("mr btn tapped")
        mrBtn.isSelected = true
        msBtn.isSelected = false
        mrsbtn.isSelected = false
        selectedTitle = "Mr"
    }
    @IBAction func msBtnTapped(_ sender: UIButton) {
        print("ms btn tapped")
        mrBtn.isSelected = false
        msBtn.isSelected = true
        mrsbtn.isSelected = false
        selectedTitle = "Ms"
    }
    @IBAction func mrsBtnTapped(_ sender: UIButton) {
        print("mrs btn tapped")
        mrBtn.isSelected = false
        msBtn.isSelected = false
        mrsbtn.isSelected = true
        selectedTitle = "Mrs"
    }
    
    @IBAction func backbtn(_ sender: UIButton)
    {
        // self.dismiss(animated: true, completion: nil)
        self.navigationController?.popViewController(animated: true)
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
  
    func callRegisterService() {
        //UserSK AddressSK
         let userSK = UserDefaults.standard.value(forKey: "userSK")
         let addressSK = UserDefaults.standard.value(forKey: "addressSK")
        print(userSK!, " - ", addressSK!)
        var title : String!
        if selectedTitle == "Mr"
        {
            title = "1"
        }
        else if selectedTitle == "Mrs"
        {
            title = "2"
        }
        else if selectedTitle == "Ms"
        {
            title = "3"
        }
        let RequestDict : [String:String] = ["UserSK":"\(userSK!)","AddressSK":"\(addressSK!)", "Title":title, "FirstName":txtFirstName.text!,"LastName":txtLastName.text!,"Address":"0", "Country":"0","CityName":"0","CitySk":"0", "Zipcode":"0","MobileNo":txtMobileNum.text!,"DOB":txtDOB.text!, "Email":txtEmail.text!,"Password":txtPswd.text!,"PassportNumber":txtPassportNumber.text!]
        print("Login Detail from Login..",RequestDict)
        
        WebService().HTTP_POST_WebServiceMethod_Profile(mainURL: WebServicesUrl.MainURL, suffix: "UpdateProfile", parameterDict: RequestDict) { (ResponseDict, ResponseStatus) in
            print("Login Response from LoginPage = ",ResponseDict)
            
            if ResponseStatus {
                
                let fullResponse = ResponseDict as! [String:String]
                print(fullResponse)
                //                ["Result": "483~2536~mks kalai~123456"]
                
                if (fullResponse["Result"]?.contains("~"))!
                {
                    let alert = UIAlertController(title: "UniOrient Info", message: "Update Successfully",         preferredStyle: UIAlertController.Style.alert)
                    
                    
                    alert.addAction(UIAlertAction(title: "Ok",
                                                  style: UIAlertAction.Style.default,
                                                  handler: {(_: UIAlertAction!) in
                                                    self.navigationController?.popViewController(animated: true)
                   
                                                    //self.dismiss(animated: true, completion: nil)
                    }))
               self.present(alert, animated: true, completion: nil)
                }else{
                    String().alert(view: self, title: "UniOrient Info", message: fullResponse["Result"]!)
                }
                
                
            }else{
                String().alert(view: self, title: "UniOrient Info", message: "Service call failure. Try after sometimes...")
                print("Service call failure ..........")
                print("Try after sometimes.......")
   
            }
            
        }
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
extension UpdateProfileViewController : UITextFieldDelegate
{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField .resignFirstResponder()
        return true
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        if textField == txtEmail || textField == txtPswd || textField == txtPassportNumber  || textField == txtMobileNum
        {
            if view.frame.origin.y == 0
            {
                animateViewMoving(up: true, moveValue: 100)
            }
            
        }
        if textField == txtDOB {
            dateString = dateFormatter.string(from: Date())
            let calendar:NSCalendar = NSCalendar.current as NSCalendar
            let components = calendar.components([NSCalendar.Unit.year, NSCalendar.Unit.month, NSCalendar.Unit.day, NSCalendar.Unit.hour, NSCalendar.Unit.minute], from: NSDate() as Date)
            let date = calendar.date(from: components)!
            DOBDatePicker.maximumDate = date
            DOBDatePicker.setDate(date, animated: true)
            DOBDatePicker.addTarget(self, action: #selector(handleDatePicker), for: UIControl.Event.valueChanged)
        }
        
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        if view.frame.origin.y != 0 {
            self.view.frame.origin.y = 0
        }
    }
    @objc func handleDatePicker(sender: UIDatePicker) {
        dateString = dateFormatter.string(from: sender.date)
    }
    
    func animateViewMoving (up:Bool, moveValue :CGFloat){
        let movementDuration:TimeInterval = 0.1
        let movement:CGFloat = ( up ? -moveValue : moveValue)
        UIView.beginAnimations( "animateView", context: nil)
        UIView.setAnimationBeginsFromCurrentState(true)
        UIView.setAnimationDuration(movementDuration )
        self.view.frame = self.view.frame.offsetBy(dx: 0, dy: movement)
        UIView.commitAnimations()
    }
}
