//
//  ProfileVC.swift
//  UniOrient
//
//  Created by APPLE on 28/03/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

class ProfileVC: UIViewController {

    @IBOutlet weak var profileContainer: UIView!
    @IBOutlet weak var profileImgContainer: UIView!
    @IBOutlet weak var profileImgView: UIImageView!
    @IBOutlet weak var userNameLbl: UILabel!
    
    
    @IBOutlet weak var myTripsAndCouponContainer: UIView!
    @IBOutlet weak var myTripsView: UIView!
    @IBOutlet weak var myTripsLbl: UILabel!
    @IBOutlet weak var myCouponsView: UIView!
    @IBOutlet weak var myCouponLbl: UILabel!
    @IBOutlet weak var aboutusView: UIView!
    @IBOutlet weak var versionLbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if let LoginDetal = FetchLoginDetails() {
            let loginResponse = FetchLoginResponse()
            self.userNameLbl.text = loginResponse?.Name
        }else{
            
        }
        
        let myTripsTap = UITapGestureRecognizer.init(target: self, action: #selector(myTripsViewTapped(_:)))
        myTripsTap.numberOfTapsRequired = 1
        myTripsView.addGestureRecognizer(myTripsTap)
        
        let myCouponTap = UITapGestureRecognizer.init(target: self, action: #selector(myCouponViewTapped(_:)))
        myCouponTap.numberOfTapsRequired = 1
        myCouponsView.addGestureRecognizer(myCouponTap)
        
        let aboutusTap = UITapGestureRecognizer.init(target: self, action: #selector(aboutusViewTapped(_:)))
        aboutusTap.numberOfTapsRequired = 1
        aboutusView.addGestureRecognizer(aboutusTap)
    }
    
    @objc func aboutusViewTapped(_ responder : UITapGestureRecognizer){
            let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "AboutUsVCSBID") as! AboutUsVC
            self.navigationController?.pushViewController(ctrl, animated: true)
    }
    
    @objc func myTripsViewTapped(_ responder : UITapGestureRecognizer){
        
        if let LoginDetal = FetchLoginDetails() {
            let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "TripVCSBID") as! TripVC
            ctrl.cameFrom = "Profile"
            //        ctrl.delegateVariable = self
            self.navigationController!.pushViewController(ctrl, animated: true)
        }else{
            let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "LoginPageVCSBID") as! LoginPageVC
            ctrl.delegateVariable = self
            ctrl.loginFrom = "Profile"
            self.present(ctrl, animated: true, completion: nil)
        }
        
       
    }
    @objc func myCouponViewTapped(_ responder : UITapGestureRecognizer){
       /*
        if let LoginDetal = FetchLoginDetails() {
           
        }else{
            let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "LoginPageVCSBID") as! LoginPageVC
            ctrl.delegateVariable = self
            ctrl.loginFrom = "Profile"
            self.present(ctrl, animated: true, completion: nil)
        } */
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension ProfileVC : LoginProtocol {
    
    func didLoggedIn(controller: LoginPageVC) {
        //        controller.navigationController?.popViewController(animated: true)
        //        controller.navigationController?.dismiss(animated: true, completion: nil)
//        controller.naviRef.dismiss(animated: true, completion: nil)
        controller.dismiss(animated: true, completion: nil)
        
        
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "TripVCSBID") as! TripVC
        ctrl.cameFrom = "Profile"
        //        ctrl.delegateVariable = self
        self.navigationController!.pushViewController(ctrl, animated: true)
    }
}
