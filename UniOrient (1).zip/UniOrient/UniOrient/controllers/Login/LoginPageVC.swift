//
//  LoginPageVC.swift
//  UniOrient
//
//  Created by APPLE on 28/03/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

protocol LoginProtocol {
    func didLoggedIn(controller : LoginPageVC)
}

class LoginPageVC: UIViewController {

    @IBOutlet weak var activityIndView: UIActivityIndicatorView!
    @IBOutlet weak var loadingView: UIView!
    @IBOutlet weak var termsandCondBtn: UIButton!
    @IBOutlet weak var lblTermsandCond: UILabel!
    @IBOutlet weak var emailTxtField: UITextField!
    @IBOutlet weak var passwordTxtField: UITextField!
    @IBOutlet weak var loginBtn: UIButton!
    
    var isFromProfile : String!
    var loginFrom : String!
    var delegateVariable : LoginProtocol!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        self.loadingView.isHidden = true
        self.activityIndView.stopAnimating()
        
        emailTxtField.delegate = self
        passwordTxtField.delegate = self
        
//        self.perform(#selector(self.showLoginOrReg), with: nil, afterDelay: 0.2)
        let tap = UITapGestureRecognizer(target: self, action: #selector(tapLabel(tap:)))
        self.lblTermsandCond.addGestureRecognizer(tap)
        self.lblTermsandCond.isUserInteractionEnabled = true
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: false)
    }
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        
        self.loginBtn.layer.cornerRadius = 5
        self.loginBtn.layer.masksToBounds = true
        
        self.lblTermsandCond.text = "By signing up you agree to our Terms & Conditions and Privacy Policy"
        let text = (self.lblTermsandCond.text)!
        let underlineAttriString = NSMutableAttributedString(string: text)
        let range1 = (text as NSString).range(of: "Terms & Conditions")
        underlineAttriString.addAttribute(NSAttributedString.Key.underlineStyle, value: NSUnderlineStyle.single.rawValue, range: range1)
        let range2 = (text as NSString).range(of: "Privacy Policy")
        underlineAttriString.addAttribute(NSAttributedString.Key.underlineStyle, value: NSUnderlineStyle.single.rawValue, range: range2)
        self.lblTermsandCond.attributedText = underlineAttriString
    }
    
    @objc func tapLabel(tap: UITapGestureRecognizer) {
        guard let range = self.lblTermsandCond.text?.range(of: "Terms & Conditions")?.nsRange else {
            return
        }
        guard let range1 = self.lblTermsandCond.text?.range(of: "Privacy Policy")?.nsRange else {
            return
        }
        if tap.didTapAttributedTextInLabel(label: self.lblTermsandCond, inRange: range) {
            let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "termsandCondVC") as! TermsandCondViewController
            ctrl.strCheck = "Terms and Conditions"
             self.navigationController?.pushViewController(ctrl, animated: true)
            // self.navigationController?.present(ctrl, animated: true, completion: nil)
        }
        else if tap.didTapAttributedTextInLabel(label: self.lblTermsandCond, inRange: range1) {
            let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "termsandCondVC") as! TermsandCondViewController
              ctrl.strCheck = "Privacy Policy"
            self.navigationController?.pushViewController(ctrl, animated: true)
        }
    }
    
    
    @IBAction func forgotPwdBtnTapped(_ sender: Any)
    {
        if let viewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "forgotPwdVC") as? ForgotPasswordViewController {
            if let navigator = navigationController {
                navigator.pushViewController(viewController, animated: true)
            }
        }
    }
    
    @IBAction func closeBtnTapped(_ sender: UIButton)
    {
        self.dismiss(animated: true, completion: nil)
     
        if self.isFromProfile == "yes"
        {
            self.navigationController?.dismiss(animated: false, completion:nil);
        }else{
          
        }
      
   
    }
    @IBAction func checkBoxBtnTapped(_ sender: UIButton) {
        if !sender.isSelected {
            sender.isSelected = true
        }else{
            sender.isSelected = false
        }
    }
    
    @IBAction func signupBtnTapped(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "RegisterVC") as! RegisterViewController
        self.navigationController?.pushViewController(vc, animated: true)
       // self.present(vc, animated: true, completion: nil)

    }
    
    @IBAction func loginBtnTapped(_ sender: UIButton)
    {
///////////////// Murali ////////////////////
//        if !(Reachability()!.isReachable) {
//            print("No Internet from Login..................")
//            self.view.ShowBlackTostWithText(message: "Check Your internet Connection", Interval: 3)
//        }
//        else {
////            callLoginService()
//            if self.loginFrom == "HomePage"{
////                self.navigationController?.popViewController(animated: true)
//                self.delegateVariable.didLoggedIn(controller: self)
//            }else if self.loginFrom == "Profile" {
//                //                        delegateVariable.didSelectAirport(selectedAirportStruct: searchResultsArray[indexPath.row], controller: self)
//                self.delegateVariable.didLoggedIn(controller: self)
//            }else if self.loginFrom == "HotelReview" {
////                self.delegateVariable.didLoggedIn(selectedString: "hideBtns", controller: self)
//            }
//        }
//////////////////////////// rekha
        if !(Reachability()!.isReachable) {
            print("No Internet from Login..................")
        }
        else
        {
            if emailTxtField.text == ""
            {
                String().alert(view: self, title: "UniOrient Info", message: "Enter Email ID")
            }
            else if passwordTxtField.text == ""
            {
                String().alert(view: self, title: "UniOrient Info", message: "Enter Password")
            }
            else if (termsandCondBtn.isSelected == false)
            {
                String().alert(view: self, title: "UniOrient Info", message: "Accept Terms & Conditions and Privacy Policy of UniOrient Travel Inc. ")
            }
            else{
                self.loadingView.isHidden = false
                self.activityIndView.startAnimating()
                callLoginService()
            }
            
        }
    }
    func callLoginService() {
        
        let RequestDict : [String:String] = ["UserName":emailTxtField.text!,"Password":passwordTxtField.text!]
        print("Login Detail from Login..",RequestDict)
        
        WebService().HTTP_POST_WebServiceMethod_Profile(mainURL: WebServicesUrl.MainURL, suffix: WebServicesUrl.Login, parameterDict: RequestDict) { (ResponseDict, ResponseStatus) in
            print("Login Response from LoginPage = ",ResponseDict)
            self.loadingView.isHidden = true
            self.activityIndView.stopAnimating()
            if ResponseStatus
            {
                print("Service call success ..........")
                let fullResponse = ResponseDict as! [String:String]
                print(fullResponse)
                //                ["Result": "483~2536~mks kalai~123456"]
                
                if (fullResponse["Result"]?.contains("~"))!
                {
                   
                    let arr = fullResponse["Result"]?.components(separatedBy: "~")
                    var aLoginDetailStruct = LoginDetails()
                    aLoginDetailStruct.Email = self.emailTxtField.text!
                    aLoginDetailStruct.Password = self.passwordTxtField.text!
                   
                    SaveLoginDetailsWithStruct(Struct: aLoginDetailStruct)
                    UserDefaults .standard .set(arr?[0], forKey: "userSK")
                     UserDefaults .standard .set(arr?[1], forKey: "addressSK")
                    var aLoginResponseStruct = LoginResponse()
                    aLoginResponseStruct.UserSK = arr![0]
                     aLoginResponseStruct.AddressSK = arr![1]
                    aLoginResponseStruct.Name = arr![2]
                    aLoginResponseStruct.PhoneNo = arr![3]
                    
                    SaveLoginResponseWithStruct(Struct: aLoginResponseStruct)
                    
                    let alert = UIAlertController(title: "UniOrient Info", message: "Login Successfully",         preferredStyle: UIAlertController.Style.alert)
                    
               
                    alert.addAction(UIAlertAction(title: "Ok",
                                                  style: UIAlertAction.Style.default,
                                                  handler: {(_: UIAlertAction!) in
                                                   self.dismiss(animated: true, completion: nil)
                    }))
                    self.present(alert, animated: true, completion: nil)
                    
                  //  String().alert(view: self, title: "UniOrient Info", message: "Login Successfully")
                    print("Contains tilt")
                   
                    if self.loginFrom == "HomePage"
                    {
                        self.navigationController?.popToRootViewController(animated: true)
                        
                    }
                    else if self.loginFrom == "FlightReview" {
//                        self.delegateVariable.didLoggedIn(selectedString: "hideBtns", controller: self)
                    }else if self.loginFrom == "HotelBooking" {
//                        self.delegateVariable.didLoggedIn(selectedString: "hideLoginView", controller: self)
                    }
                    
                    
                }else{
                    String().alert(view: self, title: "UniOrient Info", message: fullResponse["Result"]!)
                }
                
            }else{
                 self.view.ShowBlackTostWithText(message: "Try after sometimes...Server Problem....", Interval: 2)
                print("Service call failure ..........")
                print("Try after sometimes.......")
                
                
                /*  Message.shared.Alert(Title: "", Message: Constants.InternalError, TitleAlign: .normal, MessageAlign: .normal, Actions: [Message.AlertActionWithSelector(Title: "quit", Selector: #selector(self.QuitApp), Controller: self),Message.AlertActionWithSelector(Title: "retry", Selector: #selector(self.CallService), Controller: self)], Controller: self)*/
            }
            
        }
    }

    func callProfileService(withUserSK : String){
        print("Profile Service method entered....")
    }

}
extension LoginPageVC : UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}

extension UITapGestureRecognizer {
    
    func didTapAttributedTextInLabel(label: UILabel, inRange targetRange: NSRange) -> Bool {
        // Create instances of NSLayoutManager, NSTextContainer and NSTextStorage
        let layoutManager = NSLayoutManager()
        let textContainer = NSTextContainer(size: CGSize.zero)
        let textStorage = NSTextStorage(attributedString: label.attributedText!)
        
        // Configure layoutManager and textStorage
        layoutManager.addTextContainer(textContainer)
        textStorage.addLayoutManager(layoutManager)
        
        // Configure textContainer
        textContainer.lineFragmentPadding = 0.0
        textContainer.lineBreakMode = label.lineBreakMode
        textContainer.maximumNumberOfLines = label.numberOfLines
        let labelSize = label.bounds.size
        textContainer.size = labelSize
        
        // Find the tapped character location and compare it to the specified range
        let locationOfTouchInLabel = self.location(in: label)
        let textBoundingBox = layoutManager.usedRect(for: textContainer)
        
        let textContainerOffset = CGPoint(x: (labelSize.width - textBoundingBox.size.width) * 0.5 - textBoundingBox.origin.x, y: (labelSize.height - textBoundingBox.size.height) * 0.5 - textBoundingBox.origin.y)
        
        let locationOfTouchInTextContainer = CGPoint(x: locationOfTouchInLabel.x - textContainerOffset.x, y: locationOfTouchInLabel.y - textContainerOffset.y)
        let indexOfCharacter = layoutManager.characterIndex(for: locationOfTouchInTextContainer, in: textContainer, fractionOfDistanceBetweenInsertionPoints: nil)
        return NSLocationInRange(indexOfCharacter, targetRange)
    }
    
}

extension Range where Bound == String.Index {
    var nsRange:NSRange {
        return NSRange(location: self.lowerBound.encodedOffset,
                       length: self.upperBound.encodedOffset -
                        self.lowerBound.encodedOffset)
    }
}
