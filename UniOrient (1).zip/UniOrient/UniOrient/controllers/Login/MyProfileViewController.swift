//
//  MyProfileViewController.swift
//  UniOrient
//
//  Created by Pranas on 22/05/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

class MyProfileViewController: UIViewController {

    @IBOutlet weak var activityIndView: UIActivityIndicatorView!
    @IBOutlet weak var loadingView: UIView!
    @IBOutlet weak var lblUserName: UILabel!
    
    @IBOutlet weak var loginAndDetailBtn: UIButton!
    @IBOutlet weak var profileImg: UIImageView!
    @IBOutlet weak var lblEmailId: UILabel!
    @IBOutlet weak var lblDOB: UILabel!
    @IBOutlet weak var lblFirstName: UILabel!
    
    @IBOutlet weak var lblMobileNo: UILabel!
    @IBOutlet weak var lblLastName: UILabel!
    @IBOutlet weak var profileView: UIView!
    var pswd : String = String()
    var strTitle : String = String()
    var strFirstName : String = String()
    var strLastName : String = String()
    var strEmail : String = String()
    var strMobileNo : String = String()
    var strDOB : String = String()
    var strPassword : String = String()
    var strPassportNo : String = String()
    var profileResultArr = [[String:AnyObject]]()
    
    @IBOutlet weak var contactDetailsView: UIView!
    @IBOutlet weak var myTripsView: UIView!
    
    
    @IBOutlet weak var loginBtn: UIButton!
    
    @IBOutlet weak var viewProfileBtn: UIButton!
    @IBOutlet weak var logoutBtn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
     
    }
   
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
      
        let userSK = UserDefaults.standard.value(forKey: "userSK")
        if userSK == nil
        {
            self.loadingView.isHidden = true
            self.activityIndView.stopAnimating()
         //  self.myTripsView.isHidden = true
         //   self.contactDetailsView.isHidden = true
            self.logoutBtn.isHidden = true
            self.loginBtn.isEnabled = true
            self.viewProfileBtn.isHidden = true
            self.loginBtn .setTitle("     Login     ", for: UIControl.State.normal)
            //------------After Logout
            self.profileImg.image = UIImage (named: "profileUserViolet")
            self.lblUserName.text = "Guest User"
            self.lblFirstName.text = "First Name : " +  "XXXXXX"
            self.lblLastName.text = "Last Name : " + "XXXXX"
            self.lblDOB.text = "date of Birth : " + "XX-XX-19XX"
            self.lblEmailId.text = "Email Id : " + "XXXXXXXX@XXXXXX.XXX"
            self.lblMobileNo.text = "Phone No : " + "XXXXXXXXXX"
        }
        else
        {
            self.myTripsView.isHidden = false
            self.contactDetailsView.isHidden = false
            self.logoutBtn.isHidden = false
            self.viewProfileBtn.isHidden = false
            self.loginBtn .setTitle("     Personal Details     ", for: UIControl.State.normal)
            self.loginBtn.isEnabled = false
            callProfileService ()
        }
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
    @IBAction func logoutBtnTapped(_ sender: Any)
    {
        let alert = UIAlertController(title: "UniOrient Info", message: "Are you sure to logout?",         preferredStyle: UIAlertController.Style.alert)
        
        alert.addAction(UIAlertAction(title: "Cancel",
                                      style: UIAlertAction.Style.default,
                                      handler: {(_: UIAlertAction!) in
                                       
        }))
        alert.addAction(UIAlertAction(title: "Ok",
                                      style: UIAlertAction.Style.default,
                                      handler: {(_: UIAlertAction!) in
                                        UserDefaults.standard.removeObject(forKey: "userSK")
                                        self .viewWillAppear(true)
                                  
        }))
        self.present(alert, animated: true, completion: nil)
    }
    @IBAction func editBtnTapped(_ sender: Any)
    {
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "updateProfileVC") as! UpdateProfileViewController
        ctrl.strFirstName = self.strFirstName
        ctrl.strLastName = self.strLastName
        ctrl.strEmail = self.strEmail
        ctrl.strMobileNo = self.strMobileNo
        ctrl.strDOB = self.strDOB
        ctrl.strPassword = self.pswd
        ctrl.strTitle = self.strTitle
        ctrl.strPassportNo = self.strPassportNo
        self.navigationController?.pushViewController(ctrl, animated: false)
       
    }
    //    override func viewWillDisappear(_ animated: Bool) {
//        super.viewWillDisappear(animated)
//        navigationController?.setNavigationBarHidden(false, animated: false)
//    }
    
    
    @IBAction func loginBtnTapped(_ sender: UIButton)
    {
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "LoginPageVCSBID") as! LoginPageVC
        ctrl.isFromProfile = "yes"
        let navController = UINavigationController(rootViewController: ctrl)
        self.present(navController, animated:true, completion: nil)
    }
    @IBAction func closeBtnTapped(_ sender: Any)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func myTripsBtnTapped(_ sender: UIButton)
    {
        /*
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "MyBookingsVC") as! MyBookingsViewController
        ctrl.strBackBtnDisplay = "myProfile"
        self.navigationController?.pushViewController(ctrl, animated: false) */
        
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "MyBookingListVCSBID") as! MyBookingListVC
        ctrl.strBackBtnDisplay = "myProfile"
        self.navigationController?.pushViewController(ctrl, animated: false)
    }
    
    func callProfileService() {
        
        self.loadingView.isHidden = false
        self.activityIndView.startAnimating()
        
        let userSK = UserDefaults.standard.value(forKey: "userSK")
        let RequestDict : [String:String] = ["UserSK":userSK! as! String,"RequestType":"JSON"]
        print("Login Detail from Login..",RequestDict)
        
        WebService().HTTP_POST_WebServiceMethod_Flight(mainURL:WebServicesUrl.MainURL,suffix: "GetProfile", parameterDict: RequestDict) { (ResponceDict, success) in
          
            if success {
            
                self.loadingView.isHidden = true
                self.activityIndView.stopAnimating()
                
                let responce = ResponceDict as! [String:AnyObject]
                print("result",responce)
                self.profileResultArr = responce["Table"] as! [[String:AnyObject]]
                for aResultDict in self.profileResultArr
                {
                    self.lblUserName.text = "\(aResultDict["TitleName"]!)" + " " + "\(aResultDict["FirstName"]!)" + " " + "\(aResultDict["LastName"]!)"
                    self.lblFirstName.text = "First Name : " +  "\(aResultDict["FirstName"]!)"
                    self.lblLastName.text = "Last Name : " + "\(aResultDict["LastName"]!)"
                    self.lblDOB.text = "date of Birth : " + "\(aResultDict["DOB"]!)"
                    self.lblEmailId.text = "Email Id : " + "\(aResultDict["EmailId"]!)"
                    self.lblMobileNo.text = "Phone No : " + "\(aResultDict["Mobile"]!)"
                    self.strFirstName =  "\(aResultDict["FirstName"]!)"
                    self.strLastName =  "\(aResultDict["LastName"]!)"
                    self.strDOB =  "\(aResultDict["DOB"]!)"
                   self.strPassportNo =  "\(aResultDict["PassportNumber"]!)"
                    self.strFirstName =  "\(aResultDict["FirstName"]!)"
                    self.strLastName =  "\(aResultDict["LastName"]!)"
                    self.strDOB =  "\(aResultDict["DOB"]!)"
                    self.strPassword =  "\(aResultDict["Password"]!)"
                    self.strEmail =  "\(aResultDict["EmailId"]!)"
                    self.strMobileNo =  "\(aResultDict["Phone"]!)"
                    self.pswd =  "\(aResultDict["Password"]!)"
                    self.strTitle =  "\(aResultDict["TitleName"]!)"
                    
                    if self.strTitle == "Mr"
                    {
                        self.profileImg.image = UIImage (named: "man")
                    }
                    else
                    {
                        self.profileImg.image = UIImage (named: "girl")
                    }
            }
        }
    }
    }
    func convertToDictionary(text: String) -> [String: Any]? {
        if let data = text.data(using: .utf8) {
            do {
                return try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
            } catch {
                print(error.localizedDescription)
            }
        }
        return nil
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
