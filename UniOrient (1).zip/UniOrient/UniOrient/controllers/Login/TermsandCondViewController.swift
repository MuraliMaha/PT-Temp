//
//  TermsandCondViewController.swift
//  UniOrient
//
//  Created by Pranas on 15/05/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

class TermsandCondViewController: UIViewController {
    @IBOutlet weak var mWebView: UIWebView!
    var strCheck : String = String()
   
    @IBOutlet weak var lblTitle: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
      
     
    }
  
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        var url: URL!
        activityIndicator .startAnimating()
        if strCheck == "Terms & Conditions"{
            url = URL(string: WebServicesUrl.TermsandCond )
        }else{
            url = URL(string: WebServicesUrl.PrivacyPolicy )
        }
        lblTitle . text = self.strCheck
        UIWebView.loadRequest(webView)(URLRequest(url: url!))
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: false)
    }
    @IBOutlet weak var webView: UIWebView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBAction func backBtnTapped(_ sender: Any)
    {
        self.navigationController?.popViewController(animated: true)
    }
   
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension TermsandCondViewController: UIWebViewDelegate {
    func webViewDidFinishLoad(_ webView: UIWebView) {
        activityIndicator .stopAnimating()
        activityIndicator.isHidden = true
    }
}
