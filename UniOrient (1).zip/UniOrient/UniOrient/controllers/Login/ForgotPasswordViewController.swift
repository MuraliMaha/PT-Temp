//
//  ForgotPasswordViewController.swift
//  UniOrient
//
//  Created by Pranas on 21/05/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

class ForgotPasswordViewController: UIViewController,UITextFieldDelegate
{

    @IBOutlet weak var activityIndView: UIActivityIndicatorView!
    @IBOutlet weak var loadingView: UIView!
    @IBOutlet weak var txtEmailId: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.loadingView.isHidden = true
        self.activityIndView.stopAnimating()
       
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField .resignFirstResponder()
        return true
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: false)
    }
    @IBAction func backBtnTapped(_ sender: UIButton)
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func submitBtnTapped(_ sender: UIButton)
    {
        if !(Reachability()!.isReachable) {
            print("No Internet from Login..................")
        }
        else
        {
            if txtEmailId.text == ""
            {
                String().alert(view: self, title: "UniOrient Info", message: "Enter Email ID")
            }
            else if !(self.txtEmailId.text?.isValidEmail())!
            {
                String().alert(view: self, title: "UniOrient Info", message: "Enter Valid Email ID")
            }
            else{
                self.loadingView.isHidden = false
                self.activityIndView.startAnimating()
                callLoginService()
            }
            
        }
    }
   
    func callLoginService() {
        
        let RequestDict : [String:String] = ["UserName":txtEmailId.text!]
        print("Login Detail from Login..",RequestDict)
        
        WebService().HTTP_POST_WebServiceMethod_Profile(mainURL: WebServicesUrl.MainURL, suffix: "ForgotPassword", parameterDict: RequestDict) { (ResponseDict, ResponseStatus) in
            print("Login Response from LoginPage = ",ResponseDict)
            self.loadingView.isHidden = true
            self.activityIndView.stopAnimating()
            if ResponseStatus
            {
                print("Service call success ..........")
                let fullResponse = ResponseDict as! [String:String]
                print(fullResponse)
                //                ["Result": "483~2536~mks kalai~123456"]
                
                if (fullResponse["Result"]?.contains("~"))!
                {
                   /* let arr = fullResponse["Result"]?.components(separatedBy: "~")
                    
                    let alert = UIAlertController(title: "UniOrient Info", message: "We sent a link to your EmailID for reset your password.",  preferredStyle: UIAlertController.Style.alert)
                    
                    alert.addAction(UIAlertAction(title: "Ok",
                                                  style: UIAlertAction.Style.default,
                                                  handler: {(_: UIAlertAction!) in
                                                    self.dismiss(animated: true, completion: nil)
                    }))*/
                 
                    
                }else{
                    String().alert(view: self, title: "UniOrient Info", message: "Your password : " + fullResponse["Result"]!)
                }
                
            }else{
                   self.view.ShowBlackTostWithText(message: "Try after sometimes...Server Problem....", Interval: 2)
      
            }
            
        }
    }
  
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
