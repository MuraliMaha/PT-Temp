//
//  TripVC.swift
//  UniOrient
//
//  Created by APPLE on 28/03/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

class TripVC: UIViewController {

    @IBOutlet weak var backBtn: UIButton!
    var cameFrom : String!
    
    var loginDetail : LoginDetails!
    var loginResponse : LoginResponse!
    
    var dateFormatter = DateFormatter()
    var currentDateStr : String!
    
    var tripMode : String = "CurrentTrips"
    
    var inputDict = [String:String]()
    
    @IBOutlet weak var tripContainerView: UIView!
    @IBOutlet weak var errorLbl: UILabel!
    var myTripsArr = [[String:AnyObject]]()
    var upcomingTripsArr = [MyTripsStruct]()
    var completedTripsArr = [MyTripsStruct]()
    var tempArr : [MyTripsStruct]!
    
    @IBOutlet weak var upcomingView: UIView!
    @IBOutlet weak var upcomingTV: UITableView!
    
    @IBOutlet weak var upcomingBtn: UIButton!
    @IBOutlet weak var completedBtn: UIButton!
    
    @IBOutlet weak var headerView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.headerView.isHidden = true
        self.tripContainerView.isHidden = true
        
        self.backBtn.isHidden = (cameFrom == "Profile") ? false : true
        
        dateFormatter.dateFormat = "dd-MM-yyyy"
        self.currentDateStr = dateFormatter.string(from: Date())
        print("Current Date Str =",self.currentDateStr)
        
        loginDetail = FetchLoginDetails()
        loginResponse = FetchLoginResponse()
        
//        print("user Sk = ",loginResponse.UserSK)
  
        self.upcomingTV.dataSource = self
        self.upcomingTV.delegate = self
        
        
//        self.upcomingBtn.isSelected = true
//        self.completedBtn.isSelected = false
//        self.upcomingBtn.backgroundColor = hexStringToUIColor(hex: "#AFCA1F") //TripArcher Green Color
//        self.upcomingBtn.setTitleColor(UIColor.white, for: .selected)
        
       /*
        self.upcomingBtn.borderColor = UIColor.black
        
        self.upcomingBtn.shadowOffset = CGSize(width: 0,height: 5)
        self.upcomingBtn.shadowOpacity = 1 */
        
//        self.upcomingBtn.setTitleColor(UIColor.darkGray, for: .normal)
       callMyBookingsService()
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()

        upcomingBtn.layer.cornerRadius = upcomingBtn.bounds.size.height / 2.0
        upcomingBtn.layer.masksToBounds = true
        //        flightBtn.backgroundColor = hexStringToUIColor(hex: "#100055")
        upcomingBtn.backgroundColor = hexStringToUIColor(hex: "#29266f")
        upcomingBtn.setTitleColor(UIColor.white, for: .normal)
//        upcomingBtn.setImage(UIImage.init(named: "hotelWhite"), for: .normal)
        upcomingBtn.layer.borderWidth = 1
        upcomingBtn.layer.borderColor = hexStringToUIColor(hex:"#7C7C7C").cgColor
        
        completedBtn.layer.cornerRadius = completedBtn.frame.height / 2.0
        completedBtn.layer.masksToBounds = true
        completedBtn.backgroundColor = hexStringToUIColor(hex: "#ffffff")
        completedBtn.setTitleColor(UIColor.darkGray, for: .normal)
//        completedBtn.setImage(UIImage.init(named: "flightGray"), for: .normal)
        completedBtn.layer.borderWidth = 1
        completedBtn.layer.borderColor = hexStringToUIColor(hex:"#7C7C7C").cgColor
    }
    
    override func viewWillAppear(_ animated: Bool) {
        print("View will appear")
          navigationController?.setNavigationBarHidden(true, animated: false)
        self.upcomingBtn.isSelected = true
        self.completedBtn.isSelected = false
        
    }
    
    @IBAction func upcomingBtnTapped(_ sender: UIButton) {
        print("upcoming Btn tapped")
        /*
         if !sender.isSelected {
         sender.isSelected = true
         completedBtn.isSelected = false
         self.tripMode = "CurrentTrips"
         
         //            sender.backgroundColor = hexStringToUIColor(hex: "#AFCA1F") //TripArcher Green Color
         //            sender.setTitleColor(UIColor.white, for: .selected)
         sender.backgroundColor = hexStringToUIColor(hex: "#29266f")
         sender.setTitleColor(UIColor.white, for: .selected)
         
         /*
         sender.borderColor = UIColor.black
         
         sender.shadowOffset = CGSize(width: 0,height: 5)
         sender.shadowOpacity = 1 */
         
         //            self.completedBtn.isSelected = false
         
         //            self.completedBtn.backgroundColor = hexStringToUIColor(hex: "#FFFFFF")
         //            self.completedBtn.setTitleColor(UIColor.darkGray, for: .normal)
         completedBtn.backgroundColor = hexStringToUIColor(hex: "#ffffff")
         completedBtn.setTitleColor(UIColor.darkGray, for: .selected)
         
         /*
         self.completedBtn.shadowOffset = CGSize(width: 0,height: 0)
         self.completedBtn.shadowOpacity = 0 */
         if upcomingTripsArr.count > 0 {
         print("Dont call service")
         upcomingTV.reloadData()
         }else{
         //                callMyBookingsService()
         }
         } */
        
        if !sender.isSelected {
            sender.isSelected = true
            completedBtn.isSelected = false
            
            sender.backgroundColor = hexStringToUIColor(hex: "#29266f")
            sender.setTitleColor(UIColor.white, for: .normal)
            //            upcomingBtn.setImage(UIImage.init(named: "flightWhite"), for: .normal)
            
            completedBtn.backgroundColor = hexStringToUIColor(hex: "#ffffff")
            completedBtn.setTitleColor(UIColor.darkGray, for: .normal)
            //            hotelBtn.setImage(UIImage.init(named: "hotelGray"), for: .normal)
        }
        
    }
    @IBAction func completedBtnTapped(_ sender: UIButton) {
        print("completed Btn tapped")
        /*
         if !sender.isSelected {
         sender.isSelected = true
         upcomingBtn.isSelected = false
         self.tripMode = "PastTrips"
         
         sender.backgroundColor = hexStringToUIColor(hex: "#29266f")
         sender.setTitleColor(UIColor.white, for: .selected)
         
         upcomingBtn.backgroundColor = hexStringToUIColor(hex: "#ffffff")
         upcomingBtn.setTitleColor(UIColor.darkGray, for: .selected)
         
         if completedTripsArr.count > 0 {
         print("Dont Call service")
         upcomingTV.reloadData()
         }else{
         //                callMyBookingsService()
         }
         } */
        
        if !sender.isSelected {
            sender.isSelected = true
            upcomingBtn.isSelected = false
            
            sender.backgroundColor = hexStringToUIColor(hex: "#29266f")
            sender.setTitleColor(UIColor.white, for: .normal)
            //            hotelBtn.setImage(UIImage.init(named: "hotelWhite"), for: .normal)
            
            upcomingBtn.backgroundColor = hexStringToUIColor(hex: "#ffffff")
            upcomingBtn.setTitleColor(UIColor.darkGray, for: .normal)
            //            flightBtn.setImage(UIImage.init(named: "flightGray"), for: .normal)
        }
        
    }
    
    @IBAction func backBtnTapped(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
  
    func callMyBookingsService(){
        if (Reachability()?.isReachable)! {
            showLoading()
            
            inputDict = ["API_SK":"", "Module":"", "PNRO":"",
                         "Mode":self.tripMode,
                         "Fromdate":self.currentDateStr,
                         "ToDate":"",
                         "User_Sk":self.loginResponse.UserSK,
                         "BookingType":"2",
                         "RequestType":"JSON"]
            
            print("InputDict = ",inputDict)
            
            
            WebService().HTTP_POST_WebServiceMethod_Flight(mainURL: WebServicesUrl.MyBookingURL, suffix: WebServicesUrl.MyTrips, parameterDict: inputDict) { (ResponseDict, ResponseStatus) in
                
                hideLoading()
                if ResponseStatus {
                    print("Service call success ..........")
                    self.upcomingView.isHidden = false
                    
                    let responce = ResponseDict as! [String:AnyObject]
                    self.myTripsArr = responce["Table"] as! [[String:AnyObject]]
                    
                    //                    self.upcomingTripsArr.removeAll()
                    
                    for aResultDict in self.myTripsArr{
                        var aResultAndDetailStruct = MyTripsStruct()
                        
                        aResultAndDetailStruct.Rownumber = "\(aResultDict["Rownumber"]!)"
                        aResultAndDetailStruct.Booking_sk = "\(aResultDict["Booking_sk"]!)"
                        aResultAndDetailStruct.BookingNo = "\(aResultDict["BookingNo"]!)"
                        aResultAndDetailStruct.Booking_Date = "\(aResultDict["Booking_Date"]!)"
                        aResultAndDetailStruct.Arrival = "\(aResultDict["Departure"]!)"
                        aResultAndDetailStruct.Departure = "\(aResultDict["Arrival"]!)"
                        aResultAndDetailStruct.PNRNo = "\(aResultDict["PNRNo"]!)"
                        aResultAndDetailStruct.Module_sk = "\(aResultDict["Module_sk"]!)"
                        aResultAndDetailStruct.TotalAmt = "\(aResultDict["TotalAmt"]!)"
                        aResultAndDetailStruct.BookingStatus = "\(aResultDict["ProviderName"]!)"
                        aResultAndDetailStruct.ProviderName = "\(aResultDict["BookingStatus"]!)"
                        aResultAndDetailStruct.Module = "\(aResultDict["Module"]!)"
//                        aResultAndDetailStruct.DomainType = "\(aResultDict["DomainType"]!)"
                        
                        if self.upcomingBtn.isSelected{
                            self.upcomingTripsArr.append(aResultAndDetailStruct)
                        }else{
                            self.completedTripsArr.append(aResultAndDetailStruct)
                        }
                        
                        
                    }
                    self.upcomingTV.reloadData()
                    if self.upcomingBtn.isSelected {
                        print("upcoming count :",self.upcomingTripsArr.count)
                    }else{
                        print("completed count:",self.completedTripsArr.count)
                    }
      
                    
                }else{
                    print("Service call failure ..........")
                    print("Try after sometimes.......")
                    self.view.ShowBlackTostWithText(message: "Try after sometimes...Server Problem....", Interval: 2)
                    
                    self.upcomingView.isHidden = true
                    
                }
                
            }
        }else{
            print("No Internet......")
            self.upcomingView.isHidden = true
            self.errorLbl.text = "Internet connetivity Problem!!!"
        }
    }

    
}
extension TripVC : UITableViewDelegate , UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if upcomingBtn.isSelected{
            return self.upcomingTripsArr.count
        }else{
            return self.completedTripsArr.count
        }
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //        var cell = UITableViewCell()
        //        if tableView.tag == 1{
        //            cell = tableView.dequeueReusableCell(withIdentifier: "UpcomingCellID", for: indexPath) as! UpcomingCellClass
        //        }else if tableView.tag == 2{
        //            cell = tableView.dequeueReusableCell(withIdentifier: "CompletedCellID", for: indexPath) as! CompletedCellClass
        //        }
        //
        //        return cell
        
        if upcomingBtn.isSelected{
            tempArr = self.upcomingTripsArr
        }else{
            tempArr = self.completedTripsArr
        }
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "TripsCellClassID", for: indexPath) as! TripsCellClass
        cell.moduleLbl.text = self.tempArr[indexPath.row].Module
        cell.transactionIDLbl .text = self.tempArr[indexPath.row].BookingNo
        cell.transactionDateLbl .text = self.tempArr[indexPath.row].Booking_Date
        cell.departureLbl .text = self.tempArr[indexPath.row].Departure
        cell.arrivalLbl .text = self.tempArr[indexPath.row].Arrival
        cell.PNRLbl .text = self.tempArr[indexPath.row].PNRNo
        cell.amountLbl .text = self.tempArr[indexPath.row].TotalAmt
        
        
        return cell
    }
}
class TripsCellClass : UITableViewCell {
    
    @IBOutlet weak var moduleLbl: UILabel!
    @IBOutlet weak var transactionIDLbl: UILabel!
    @IBOutlet weak var transactionDateLbl: UILabel!
    @IBOutlet weak var departureLbl: UILabel!
    @IBOutlet weak var arrivalLbl: UILabel!
    @IBOutlet weak var PNRLbl: UILabel!
    @IBOutlet weak var amountLbl: UILabel!
    @IBOutlet weak var aBtn: UIButton!
}
