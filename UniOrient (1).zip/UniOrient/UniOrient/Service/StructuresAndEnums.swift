//
//  StructuresAndEnums.swift
//  TripArcher
//
//  Created by APPLE on 22/11/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit

//-----------------Encode struct to Dictionary
struct UserInfo  {
    var structIndex : String!
    var travellerTitle : String!
    var firstName : String!
    var lastName : String!
    var dateOfBirth : String!
    var passportNo : String!
    var expiryDate : String!
    var filterStr : String!
    
    var dictionaryRepresentation: [String: String] {
        return [
            "title" : travellerTitle,
            "firstName" : firstName,
            "lastName" : lastName,
            "DOB" : dateOfBirth,
            "passportNo" : passportNo,
            "expiryDate" : expiryDate
        ]
    }
    var nsDictionary: NSDictionary {
        return dictionaryRepresentation as NSDictionary
    }
}
struct JSON {
    static let encoder = JSONEncoder()
}
extension Encodable {
    subscript(key: String) -> Any? {
        return dictionary[key]
    }
    var dictionary: [String: Any] {
        return (try? JSONSerialization.jsonObject(with: JSON.encoder.encode(self))) as? [String: Any] ?? [:]
    }
}


//-----------------End Encode struct to Dictionary


struct TravellerDetailStruct {
    var structIndex : String!
    var travellerTitle : String!
    var firstName : String!
    var lastName : String!
    var dateOfBirth : String!
    var passportNo : String!
    var expiryDate : String!
    var filterStr : String!
    
}

//{"CityCode":"KBL","CityName":"Kabul","CountryCode":"AF","CountryName":"Afghanistan"}
//not using
struct HotelCityStruct{
    var cityCode : String!
    var cityName : String!
    var countryCode : String!
    var countryName : String!
}

/*
{
    "ID": null,
    "Country": "Portugal",
    "AirportName": null,
    "CityName": "Coimbra",
    "CitySk": "554",
    "CountryCode": null,
    "City": "Coimbra",
    "CityCode": null,
    "ctype": "City",
    "Address": "the centre of Portugal, Portugal"
} */
struct HotelCityStructNew{
    var ID : String!
    var AirportName : String!
    var Country : String?
    var CityName : String?
    var CitySk : String?
    var ctype : String?
    var CountryCode : String!
    var City : String!
    var CityCode : String!
    var Address : String!  
}

struct HotelNationalityStruct{
    var CountryName : String!
    var CountryCode : String!
}

//{"AirportCode":"CJB","CityName":"Coimbatore(CJB)","Country_sK":1.0,"CountryName":"India"}
struct AirportStruct : Equatable {
    var airportCode : String!
    var cityName : String!
    var countrySK : String!
    var countryName : String!
    
//    static func == (lhs : AirportStruct,rhs : AirportStruct) -> Bool {
//        return lhs.airportCode == rhs.airportCode
//    }
}

/*
struct Car: Equatable {
    
    var modelName = String()
    var manufacturer = String()
    
    init(modelName: String, manufacturer: String) {
        self.modelName = modelName
        self.manufacturer = manufacturer
    }
    
    static func == (lhs: Car, rhs: Car) -> Bool {
        return lhs.modelName == rhs.modelName
    }
} */

struct FlightResultAndDetailStruct {

    var wayType : String!
    
    //for going
    
    var flightID : String!
    
    var faretype : String!
    var departureDate : String!
    var arrivalDate :String!
    
    var flightImgName : String!
    var flightImgData : Data?
    var flightName : String!
    var departureTime : String!
    var departureAirportCode : String!
    var duration : String!
    var stopDetails : String!
    var noOfStops : String!
    var arrivalTime : String!
    var arrivalAirportCode : String!
    var amount : String!
  
    var APIAmount : String!
    var BaseFare : String!
    var TotalFare : String!
    var Markup : String!
    var Discount : String!
    var TaxAmt : String!
    
    var dairportall : String!
    var flightnoall : String!
    var marketingall : String!
    var durationall : String!
    var ddateall : String!
    var adateall : String!
    var dtimeall : String!
    var atimeall : String!
 
    var aairportall : String!
    var operatingAirlineall : String!
    var equipmentTypeall : String!
    var bookingCodeall : String!
    var index : String!
    var filename : String!
    var Arrivaldatetimeall : String!
    var Departdatetimetall : String!

//aairportall operatingAirlineall equipmentTypeall flightNumberall bookingCodeall index filename
    var CabinBaggage:String!
    var CheckInBaggage:String!
    
    var isMultiAirlineAvailable : Bool!
    var detailArrWithFlightDetailStruct = [FlightDetailStruct]()
    
    
    //for returning
//    var returnFlightID : String!
    var returnDepartureDate : String!
    var returnArrivalDate : String!
    
    var returnFlightImgName : String!
    var returnFlightImgData : Data!
    var returnFlightName : String!
    var returnDepartureTime : String!
    var returnDepartureAirportCode : String!
    var returnDuration : String!
    var returnNoofStops : String!
    var returnArrivalTime :String!
    var returnArrivalAirportCode : String!
    
    var isReturnMultiAirlineAvailable : Bool!
   
    
    ///For MultiCity
    //for returning
    //    var returnFlightID : String!
    var multiDepartureDate : String!
    var multiArrivalDate : String!
    
    var multiFlightImgName : String!
    var multiFlightImgData : Data!
    var multiFlightName : String!
    var multiDepartureTime : String!
    var multiDepartureAirportCode : String!
    var multiDuration : String!
    var multiNoofStops : String!
    var multiArrivalTime :String!
    var multiArrivalAirportCode : String!
    
    var isMulticityMultiAirlineAvailable : Bool!
     var returnDetailArrWithFlightDetailStruct = [FlightDetailStruct]()
    var multiDetailArrWithFlightDetailStruct = [FlightDetailStruct]()
    var isSelected : Bool = false // This flag is for Filter Operation
    
}
struct FlightDetailStruct {
    var flightImgName : String!
    var flightImgData : Data!
    var flightNumber : String!
    var departureDate : String!
    var departureTime : String!
    var arrivalDate : String!
    var arrivalTime : String!
    
    var marketing : String!
    var operating : String!
    var duration : String!
    var fromAirportName : String!
    var toAirportName : String!
    
    var departureDateTime : String!
    var arrivalDateTime : String!
    
//    var flightName : String!
    var stop : String!
    var fromCity : String!
    var toCity : String!
}

struct FinalStruct {  //: Equatable {
    
    var CabinBaggage : String!
    var CheckInBaggage : String!
    
    var departureDate : String!
    var arrivalDate : String!
    
    var flightImgName : String!
    var flightImgData : Data?
    var flightName : String!
    var departureTime : String!
    var departureAirportCode : String!
    var duration : String!
    var stop : String!
    var arrivalTime : String!
    var arrivalAirportCode : String!
    
    var TripDetailsArr = [FlightDetailStruct]()
    
//    static func == (lhs : FinalStruct,rhs : FinalStruct) -> Bool {
//        return lhs.flightName == rhs.flightName
//    }
}
extension FinalStruct {
//    var structExtension : String!
    
}

//rekha created
struct passengerDetailsStruct {
    var Adult : String!
    var Child : String!
    var Infant : String!
    var cabinClass : String!
    
}
//Not Required
struct RoomStruct1 {
    var roomNo : String!
    var noOfAdult : String!
    var noOfChildren : String!
    var ageArr = [ChildrenAgeStruct2]()
}
//Not Required
struct ChildrenAgeStruct2 {
    var age : String!
}

struct RoomStruct {
    var roomNo : Int!
    var noOfAdult : Int!
    var noOfChildren : Int!
    var ageArr = [ChildrenAgeStruct]()
}
struct ChildrenAgeStruct {
    var childNo : Int!
    var age : Int!
}



// Hotel

struct HotelStruct {
    
    var HotelUniqueKey : String!
    var processId : String?
    var RoomcategoryCode : String!
    var APIType : String!
    
    var NoOfRooms : String!
    var NoOfNights : String!
    var CheckInDate : String!
    var CheckOutDate : String!
    var HotelName : String!
    var ThumbNailImage : String!
    var Address : String!
    var StarRating : String!
    var RatingImage : String!
    var DispTotalAmount : String!
    var RoomDetailArr = [RoomDetailStruct]()
    
    var city : String?
    var country : String?
    var hotelImgData : Data?
    
    var APIAMT : String!
    var MarkupAll : String!
    var paxstr : String?
    var Currency : String?
}

struct RoomDetailStruct {
    var RoomDescription : String!
    var inclusions : String!
    var TotalAmount : String!
    var Cancellationpolicy : String!
    
    var NoOfNights : String!
    
    var APIType : String!
    var APIAMT : String!
    var MarkupAll : String!
    var TotalTaxCharges : String!
    var Discount : String!
    var BaseFareAmount : String!
    var TotalAmountMarkupWithTax : String!
    var RoomTypeCode : String!
    var RateType : String!
    var RoomBookingCode : String!
    var rateComments_Id : String!
    
    var isFareChanged : Bool = false
    var NewAPIAMT : String!
    var NewMarkupAll : String!
    var NewTotalTaxCharges : String!
    var NewDiscount : String!
    var NewBaseFareAmount : String!
    var NewTotalAmountMarkupWithTax : String!
    
    var bbPrice : String?
    var RatePlanCode : String!
    
    //    var RoomDetailTotalTaxCharges : String!
    /*
     //PricingDetails
     self.priceingDictToConvert["APIAmt"] = Double(self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].APIAMT)
     self.priceingDictToConvert["Markup"] = Double(self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].MarkupAll)
     self.priceingDictToConvert["TotalTaxAmount"] = Double(self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].TotalTaxCharges)
     self.priceingDictToConvert["Discount"] = Double(self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].Discount)
     self.priceingDictToConvert["NoofChild"] = self.inputDict["Child"] //total number child
     
     let bFare = Float(self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].BaseFareAmount)
     let mUp = Float(self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].MarkupAll)
     self.priceingDictToConvert["Basefare"] = Float(bFare! - mUp!)
     
     self.priceingDictToConvert["TotalAmount"] = self.theSelectedHotelStruct.RoomDetailArr[selectedRoomIndex].TotalAmountMarkupWithTax
     self.priceingDictToConvert["NoofAdult"] = self.inputDict["Adult"]*/
}



struct HoteltlStruct{
    var hotel_name : String!
    var Address : String!
    var city : String!
    var state : String!
    var country : String!
    var zip : String!
    var locality : String!
    var ContactNumber : String!
    
    var checkin : String!
    var checkout : String!
    var numberofrooms : String!
    var numberoffloors : String!
    var Rating : String!
    var amenity_text : String!
    var roomtype : String!
    var bedtype : String!
    var noofbeds : String!
    var noofpax : String!
    var latitude : String!
    var longitude : String!
    var description : String!
    
    var overview : String!
}

struct FacilitytlStruct {
    var amenity_text : String!
    
    var Facility : String!
    var FacilityType : String!
}
struct GallerytlStruct{
    var thumb_nail_image_Url : String!
    var wide_angle_Image_Url : String!
    
    var imagepath : String!
}
struct ReviewtlStruct {
    
}
    

//HotelFaciltyGalleryContainerStruct
struct HFGContainerStruct {
    var HoteltlArr = [HoteltlStruct]()
    var FaciltytlArr = [FacilitytlStruct]()
    var GallerytlArr = [GallerytlStruct]()
}

struct FlightUserSelectedFiltersStruct {
    var preferredAirlinesArr : [String]
    var isNonStop : Bool! // = false
    var isOneStop : Bool! //= false
    var isTwoPlusStops : Bool! //= false
    
    var beforeElevenAM : Bool = false
    var elevenAMToFivePM : Bool = false
    var fivePMToNinePM : Bool = false
    var afterNinePM : Bool = false
    
    
//    var isReturnMultiAirlineAvailable : Bool!
}

struct HotelFilterStruct {
    var hotelName : String!
    var isSelectedAh : Bool!
//    mutating func setIsSelected(x:Bool){
//        self.isSelected = x
//    }
}
struct HotelUserSelectedFiltersStruct {
    var isUpto999 : Bool!
    var is1000To2999 : Bool!
    var is3000To4999 : Bool!
    var is5000To9999 : Bool!
    var is10000Plus : Bool!
    
    var isOneStar : Bool! // = false
    var isTwoStar : Bool! //= false
    var isThreeStar : Bool! //= false
    var isFourStar : Bool!
    var isFiveStar : Bool!
}

struct PassengerStruct {
    var firstName : String!
    var lastName : String!
    var title : String!
    var roomNo : String!
    
    var age : String!
}
/*
struct FlightFilterStruct {
    var flightName : String!
    var flightImgData : Data!
    var isSelected : Bool!
}*/

struct LoginResponse {
    var UserSK : String!
    var AddressSK : String!
    var Name : String!
    var PhoneNo:String!
}
struct LoginDetails {
    var Email:String!
    var Password:String!
}
struct FlightAPIBookingTransactionDetails {
    var BookingId:String!
    var BookingPNR:String!
    var PriceVariationAmount:String!
}
struct NotificationStruct {
    static let LogOutNotif = NSNotification.Name(rawValue: "LogoutNotif")
}
struct MyFlightTicketsStruct {
    var Waytype : String!
    var AirlineName : String!
    var cabinclass : String!
    var DepartTime : String!
    var ArrivesTime : String!
    var Duration : String!
    var Stop : String!
    var DepartDate : String!
    var FromAirportCode : String!
    var ToAirportCode : String!
    var FromCode : String!
    var ToCode : String!
    var Logo : String!
    var FlightNo : String!
    
}
struct MyHotelTicketsStruct {
    var HotelName : String!
    var HotelAddress : String!
    var Rating : String!
    var DepartDate : String!
    var ArrivesDate : String!
    var TripID : String!
    var PNRNo : String!
    var NoofAdult : String!
    var RoomName : String!
    var RoomNo : String!
    var BaseFare : String!
    var TaxAmt : String!
    var ServiceFee : String!
    var Discount : String!
    var totalamt : String!
    
}
struct MyHotelTicketsContactStruct {
    var ContactName : String!
    var Email : String!
    var Mobile : String!
    
}
struct MyFlightTicketsPassengerStruct {
    var Title : String!
    var FirstName : String!
    var LastName : String!
    var TravType : String!
    var PassportNo : String!
    var TicketNo : String!
 
}
struct MyFlightTicketsContactStruct {
    var ContactName : String!
    var Email : String!
    var Mobile : String!
    var FirstName : String!
    var LastName : String!
    var TripId : String!
    var PNRNo : String!
    var BOOKINGSTATUS : String!
    var BookingDate : String!
    
}//FirstName LastName TripId PNRNo BOOKINGSTATUS BookingDate
struct MyFlightTicketsFareDetailsStruct {
    var BaseFare : String!
    var TaxAmt : String!
    var ServiceFee : String!
    var TotalAmount : String!

}
struct MyHotelTicketsPassengerStruct {
    var Title : String!
    var FirstName : String!
    var LastName : String!
    var TravType : String!
    var roomno : String!
    
}
struct MyTripsStruct {
    var Rownumber : String!
    var Booking_sk : String!
    var BookingNo : String!
    var Booking_Date : String!
    var Departure : String!
    var Arrival : String!
    var PNRNo : String!
    var Module_sk : String!
    var TotalAmt : String!
    var ProviderName : String!
    var BookingStatus : String!
    var Module : String!
    
    var From_AirportCode : String!
    var To_AirportCode : String!
    var AirlineNo : String!
    var HotelName : String!
    var DepartsDate : String!
    var ArrivesDate : String!
    
    
//    var HotelCity : String!
//    var DomainType : String!
}
struct FlightDateSelectedStruct {
    
    var departDate : Date!
    var arrivalDate : Date!
    var departDate1 : Date!
    var departDate2 : Date!
    var departDate3 : Date!
    
}
struct DateSelectedStruct {

    var checkInDate : Date!
    var checkOutDate : Date!
    var checkInDateStr : String!
    var checkOutDateStr : String!
    var noOfNightsStr : String!
    var noOfNightsInt : Int!
}
struct BookerInfoStruct {
    var firstName : String!
//    var lastName :String!
//    var gender : String!
    var mobileNo : String!
    var email : String!
}
struct DragonPayCredentials {
    
    /*
    //Test
    static let MID = "UNIORIENT"
    static let MPwd = "Kw72hVsnfowuwe"
    static let MName = "UNI ORIENT TRAVEL INC"
    static let PaymentURL = "https://test.dragonpay.ph/Pay.aspx?"
    static let RedirectURL = "http://pranasonline.com/Demo/Uniorient_Payment/frmResponseHandling.aspx?" */

    
    //Live
    static let MID = "UNIORIENT"
    static let MPwd = "8Z1vJuZCsd7h5gs"
    static let MName = "UNI ORIENT TRAVEL INC"
    static let PaymentURL = "https://gw.dragonpay.ph/Pay.aspx?"
    static let RedirectURL = "http://pranasonline.com/Demo/Uniorient_Payment/frmResponseHandling.aspx?"
}
struct PaymentStruct {
    var transactionId : String!
    var referenceNo : String!
    var status : String!
    var message : String!
    var digest : String!
}
