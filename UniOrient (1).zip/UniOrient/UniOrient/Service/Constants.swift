//
//  Constants.swift
//  TripArcher
//
//  Created by APPLE on 19/11/18.
//  Copyright © 2018 APPLE. All rights reserved.
//

import UIKit


struct WebServicesUrl{
    
    //----------Flight ---------
    //Colour Code
    static  let appColor1 = UIColor(red: 22/255.0, green: 19/255.0, blue: 124/255.0, alpha: 1.0)
    static let appColor2 = UIColor(red: 237/255.0, green: 36/255.0, blue: 36/255.0, alpha: 1.0)
    
    static let appGrayColor = UIColor(red: 124/255.0, green: 124/255.0, blue: 124/255.0, alpha: 1.0)
    
    static let appVioletColor = UIColor(red: 41/255.0, green: 38/255.0, blue: 111/255.0, alpha: 1.0)
    
  
    //"http://180.87.49.238/Airline_Images/"
    
    //"https://www.shioktrip.com/Airline_Images/"

    
    /*
    //-------Flight Local
//    static let FlightServiceUrl = "http://192.168.1.3:2325/FlightService.asmx"
  
    //-------Flight Live
    static let FlightServiceUrl = "http://180.87.49.238/FlightService.asmx"
  
    static let TermsandCond = "https://www.uniorient.com/about/Misc_Termsandcondition.aspx"
  
    static let PrivacyPolicy = "https://www.uniorient.com/about/Misc_Termsandcondition.aspx"
  
    

    static let TermsandCond = "http://192.168.1.3:2281/about/Misc_Termsandcondition.aspx"
    static let PrivacyPolicy = "http://192.168.1.3:2281/about/Misc_Termsandcondition.aspx"
 */
    //--------Flight end
    
    
  //  ----------Profile Live
//    static let MainURL  = "http://180.87.49.238/Profile.asmx"
//    static let Login    = "Login"
//    static let Register = "UserRegistration"

   // ---------MyBookings Live
//    static let MyBookingURL = "http://180.87.49.238/myaccountlistservice.asmx"
//    static let MyTrips = "GetBookingList"
//    static let MyTicketsURL = "http://180.87.49.238/BookingListService.asmx"
  
    
    
    
    /*
    //Hotel
//     static let HotelServiceUrl = "http://192.168.1.3:2325/HotelService.asmx"
    static let HotelServiceUrl = "http://180.87.49.238/HotelService.asmx"
    
    static let HotelServiceUrlTest = "http://192.168.1.3:2325/HotelService.asmx"
    static let HotelServiceUrlLive = "http://180.87.49.238/HotelService.asmx"
 */
 
    static let HotelResult = "GetHotelResult"
    static let HotelDetails = "GetHotelDetails"
    static let GetDestinationList = "GetDestinationList"
    static let GetNationality = "GetNationality"
    static let APIBookingTransaction = "APIBookingTransaction"
    static let HotelBedsCheckrates = "HotelBedsCheckrates"
    static let HotelBedsRateComments = "HotelBedsratecomments"
    static let HotelbedsFinalbooking = "HotelbedsFinalbooking"
    static let MikiFinalbooking = "MikiFinalbooking"
    static let HotelExtranetFinalbooking = "HotelExtranetFinalbooking"
    static let PaymentInfo = "PaymentInfo"

//----------------Flight
    static let FlightResult = "FlightResult"
    static let FlightMultiResult = "FlightResultMultiWay"
    static let FlightImgURL = "https://www.shioktrip.com/Airline_Images/"
    
    static let Login    = "Login"
    static let Register = "UserRegistration"
    static let MyTrips = "GetBookingList"
    
    
    /*
    //-------Profile Local
    static let MainURL = "http://192.168.1.3:2325/Profile.asmx"
    static let Login = "Login"
    static let Register = "UserRegistration"
    //-------MyBookings Local
    static let MyBookingURL = "http://192.168.1.3:2325/myaccountlistservice.asmx"
    static let MyTrips = "GetBookingList"
    static let MyTicketsURL = "http://192.168.1.3:2325/BookingListService.asmx" */
    
    
    /*
    //Test
    static let HotelServiceUrl = "http://192.168.1.3:2325/HotelService.asmx"
    static let FlightServiceUrl = "http://192.168.1.3:2325/FlightService.asmx"
    
    static let TermsandCond = "http://192.168.1.3:2281/about/Misc_Termsandcondition.aspx"
    static let PrivacyPolicy = "http://192.168.1.3:2281/about/Misc_Termsandcondition.aspx"
    
    static let MainURL = "http://192.168.1.3:2325/Profile.asmx"
    static let MyBookingURL = "http://192.168.1.3:2325/myaccountlistservice.asmx"
    static let MyTicketsURL = "http://192.168.1.3:2325/BookingListService.asmx" */
    
    
    //Live
    static let HotelServiceUrl = "http://180.87.49.238/HotelService.asmx"
    static let FlightServiceUrl = "http://180.87.49.238/FlightService.asmx"
    
    static let TermsandCond = "https://www.uniorient.com/about/Misc_Termsandcondition.aspx"
    static let PrivacyPolicy = "https://www.uniorient.com/about/Misc_Termsandcondition.aspx"
    
    static let MainURL  = "http://180.87.49.238/Profile.asmx"
    static let MyBookingURL = "http://180.87.49.238/myaccountlistservice.asmx"
    static let MyTicketsURL = "http://180.87.49.238/BookingListService.asmx"
    
 
}
