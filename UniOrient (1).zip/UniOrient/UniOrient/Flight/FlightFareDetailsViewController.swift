//
//  FlightFareDetailsViewController.swift
//  UniOrient
//
//  Created by Pranas on 14/05/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

class FlightFareDetailsViewController: UIViewController {
  var selectedStruct : FlightResultAndDetailStruct!
    var baseFare : String!
    var taxFare : String!
    var totalFare : String!
    var isfareChanged : String!
    override func viewDidLoad() {
        super.viewDidLoad()

        if isfareChanged == "true"
        {
            self.lblBaseFare.text = "PHP " + self.baseFare
            self.lblTaxFare.text = "PHP " + self.taxFare
            self.lblDiscount.text = "- PHP " + self.selectedStruct.Discount
            self.lblMarkUp.text = "- PHP " + "0"
            self.lblTotalFare.text = "PHP " + self.totalFare
        }
        else
        {
            let myString = self.selectedStruct!.BaseFare!
            let myFloat = (myString as NSString).floatValue
            let formatted = String(format: "%.2f", myFloat)
            self.lblBaseFare.text = "PHP " + formatted
            
            let myString1 = self.selectedStruct.TaxAmt!
            let myFloat1 = (myString1 as NSString).floatValue
            let formatted1 = String(format: "%.2f", myFloat1)
            self.lblTaxFare.text = "PHP " + formatted1
            
            let myString2 = self.selectedStruct.Discount!
            let myFloat2 = (myString2 as NSString).floatValue
            let formatted2 = String(format: "%.2f", myFloat2)
            self.lblDiscount.text = "- PHP " + formatted2
            
            self.lblMarkUp.text = "- PHP " + "0.00"
            
            let myString3 = self.selectedStruct.TotalFare!
            let myFloat3 = (myString3 as NSString).floatValue
            let formatted3 = String(format: "%.2f", myFloat3)
            self.lblTotalFare.text = "PHP " + formatted3
        }
      
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
    @IBOutlet weak var lblMarkUp: UILabel!
    @IBOutlet weak var lblDiscount: UILabel!
    @IBOutlet weak var lblTotalFare: UILabel!
    @IBOutlet weak var lblTaxFare: UILabel!
    @IBOutlet weak var lblBaseFare: UILabel!
 
    @IBAction func closeBtnTapped(_ sender: UIButton)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
