//
//  FlightPaymentViewController.swift
//  UniOrient
//
//  Created by Pranas on 20/05/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit

class FlightPaymentViewController: UIViewController {
    var providedInputDict = [String:String]()
    var DictInput = Dictionary<String, String>()
    var selectedStruct : FlightResultAndDetailStruct!
    var FlightTripID : String = String()
    var Booking_SK : String = String()
    var FlightMobileNo : String = String()
    var FlightEmailID : String = String()
    var PassengerArr = [TravellerDetailStruct]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
    @IBAction func backBtnTapped(_ sender: Any)
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func continueBtnTapped(_ sender: Any)
    {
       FlightFinalBooking ()
      /*  let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "bookingSummaryVC") as! BookingSummaryViewController
        ctrl.selectedStruct = self.selectedStruct
        ctrl.providedInputDict = self.providedInputDict
        ctrl.PassengerArr = self.PassengerArr
        self.navigationController?.pushViewController(ctrl, animated: true)*/
        
    }
 func FlightFinalBooking()
 {
   
    let strdata = "way=" + "\(self.providedInputDict["WayType"]!)" + "&wayIdentifier=" + "0" + "&adult="
        + "\(self.providedInputDict["AdultCount"]!)" + "&child=" + "\(self.providedInputDict["ChildCount"]!)" + "&infant=" + "\(self.providedInputDict["InfantCount"]!)"
        
        + "&departAirportall=" + "\(self.selectedStruct.dairportall!)" + "&arrivalAirportall=" + "\(self.selectedStruct.aairportall!)" + "&operatingAirlineall=" + "\(self.selectedStruct.operatingAirlineall!)"
         + "&departdatetimetall=" + "\(self.selectedStruct.Departdatetimetall!)" + "&arrivaldatetimeall=" + "\(self.selectedStruct.Arrivaldatetimeall!)" + "&equipmentTypeall=" + "\(self.selectedStruct.equipmentTypeall!)"
         + "&flightNumberall=" + "\(self.selectedStruct.flightnoall!)" + "&marketingAirlineall=" + "\(self.selectedStruct.marketingall!)" + "&bookingCodeall=" + "\(self.selectedStruct.bookingCodeall!)"
         + "&index=0" + "&filename=" + "\(self.selectedStruct.filename!)" + "&booking_SK=" + "\(self.Booking_SK)"
          + "&tripID=" + "\(self.FlightTripID)" + "&email=" + "\(self.FlightEmailID)" + "&mobile=" + "\(self.FlightMobileNo)"
         +  "&ModuleId=" + "\(self.providedInputDict["ModuleId"]!)"
         + "&FromCityName=" + "\(self.providedInputDict["Origin"]!)"  + "&ToCityName=" + "\(self.providedInputDict["Destination"]!)" + "&sessionid=0"  + "&AccountId=" + "IXCRAJ042" + "&api_sk=" + "20" + "&ISLCC=" + "false"
    
    print(strdata)
    
    print(WebServicesUrl.FlightServiceUrl)
    if (Reachability()?.isReachable)!
    {
        WebService().HTTP_POST_FlightBookingTransaction(mainURL: WebServicesUrl.FlightServiceUrl, suffix: "FlightBooking", parameterDict: strdata) { (ResponseDict, success) in
            
            if success {
                print("Service call success ..........")
                let fullResponse = ResponseDict as! [String:String]
                print(fullResponse)
                
                if (fullResponse["Result"]?.contains("/"))!
                {
                    let arr = fullResponse["Result"]?.components(separatedBy: "/")
                    var aLoginResponseStruct = FlightAPIBookingTransactionDetails()
                    aLoginResponseStruct.BookingId = arr![0]
                    aLoginResponseStruct.BookingPNR = arr![1]
                    UserDefaults.standard.set(arr![0], forKey: "flightbookingpnr")
                    UserDefaults.standard.set(arr![1], forKey: "flightbookingid")
                 
                    let alert = UIAlertController(title: "UniOrient Info", message: "Flight Booking Successfully",         preferredStyle: UIAlertController.Style.alert)
                    
                    //flightbookingpnr
                    alert.addAction(UIAlertAction(title: "Ok",
                                                  style: UIAlertAction.Style.default,
                                                  handler: {(_: UIAlertAction!) in
                                                    
                                                    let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "bookingSummaryVC") as! BookingSummaryViewController
                                                    ctrl.selectedStruct = self.selectedStruct
                                                    ctrl.providedInputDict = self.providedInputDict
                                                    ctrl.PassengerArr = self.PassengerArr
                                                    self.navigationController?.pushViewController(ctrl, animated: true)
                    }))
                    self.present(alert, animated: true, completion: nil)
                    
                }
 
            }
            else
            {
                print("Failure",ResponseDict)
            }
        }
    }
    }
    
    

}
