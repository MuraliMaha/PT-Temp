//
//  CustomCalenderViewController.swift
//  TakeMyTravel
//
//  Created by apple1 on 07/01/19.
//  Copyright © 2019 pranas. All rights reserved.
//

import UIKit

class CustomCalenderViewController: UIViewController, FSCalendarDataSource, FSCalendarDelegate {
    var button1HasBeenPressed = false
    var button2HasBeenPressed = false
    var button3HasBeenPressed = false
    var selectedDepartDate : String = String()
    var selectedArrivDate : String = String()
    var selectedDepart1 : String = String()
    var selectedDepart2 : String = String()
    var selectedDepart3 : String = String()
    @IBOutlet weak var calendar: FSCalendar!
    @IBOutlet weak var calendarHeightConstraint: NSLayoutConstraint!
    
    var dateDisplayFormat = DateFormatter()
    var firstDate: Date?
    var middleDate: Date?
    var lastDate: Date?
    var datesRange: [Date]?
    var flightSelectedData : FlightDateSelectedStruct!
    var selectableDate : String = String()
    var selectdDate1 : String = String()
    var selectdDate2 : String = String()
    var selectdDate3 : String = String()
    var selectedIndex : String = String()
     var defaults = UserDefaults.standard
    // MARK: - Properties
    @IBOutlet weak var calendarView: CVCalendarView!
    @IBOutlet weak var menuView: CVCalendarMenuView!
    @IBOutlet weak var monthLabel: UILabel!
    @IBOutlet weak var daysOutSwitch: UISwitch!
    
    @IBOutlet weak var onewayView: UIView!
    @IBOutlet weak var twowayView: UIView!
    @IBOutlet weak var twowayDepartDate: UILabel!
    
    @IBOutlet weak var twowayDepartDay: UILabel!
    @IBOutlet weak var twowayArrivDate: UILabel!
    @IBOutlet weak var twowayArrivDay: UILabel!
    
    @IBOutlet weak var multicityView: UIView!
    @IBOutlet weak var onewayDepartDay: UILabel!
    @IBOutlet weak var onewayDaprtDate: UILabel!
    
    @IBOutlet weak var depart1Date: UILabel!
    
    @IBOutlet weak var depart1Day: UILabel!
    
    @IBOutlet weak var depart2Date: UILabel!
    
    @IBOutlet weak var depart2day: UILabel!
    
    @IBOutlet weak var depart3Date: UILabel!
    
    @IBOutlet weak var depart3Day: UILabel!
    var selctdDepartDate : Date!
    var selctdArrivalDate : Date!
    var strdepart1 : String!
    var strdepart2 : String!
    var strdepart3 : String!
    
    var wayType : String = String()
    var strCheck : String = String()
    private var randomNumberOfDotMarkersForDay = [Int]()
    private var shouldShowDaysOut = true
    private var animationFinished = true
    private var selectedDay: DayView!
    private var currentCalendar: Calendar?
    
    override func awakeFromNib() {
        let timeZoneBias = 480 // (UTC+08:00)
        currentCalendar = Calendar(identifier: .gregorian)
        currentCalendar?.locale = Locale(identifier: "fr_FR")
        if let timeZone = TimeZone(secondsFromGMT: -timeZoneBias * 60) {
            currentCalendar?.timeZone = timeZone
        }
    }
    
    // MARK: - Life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        dateDisplayFormat.dateFormat = "E, d MMM, yyyy"
        calendar.scrollDirection = FSCalendarScrollDirection.vertical
        print(self.flightSelectedData)
        //----------------- new code for selected date
        
        self.calendar.delegate = self
        self.calendar.dataSource = self
        
        //----------------- end new code for selected date
        
        wayType = defaults.value(forKey: "wayType") as! String
        if (wayType == "one")
        {
            firstDate = self.flightSelectedData.departDate
            let range = [firstDate]
            for d in range {
                calendar.select(d)
            }
            self.onewayView .isHidden = false
            self.twowayView.isHidden = true
            self.multicityView.isHidden = true
            calendar.allowsMultipleSelection = false
            
            self.onewayDaprtDate.textColor = UIColor.white
            self.onewayDaprtDate.text = removeYear(dateDisplayFormat.string(from: (firstDate!)))
        }
        else if (wayType == "two")
        {
            firstDate = self.flightSelectedData.departDate
            lastDate  = self.flightSelectedData.arrivalDate
            
            print("firstDate",firstDate!)
            print("lastDate",lastDate!)
            
            self.calendar.allowsMultipleSelection = true
            self.calendar.scrollDirection = .vertical
            let range = [firstDate,lastDate]
            for d in range {
                calendar.select(d)
            }
            
            self.twowayDepartDate.textColor = UIColor.white
            self.twowayArrivDate.textColor = UIColor.white
            
            self.twowayDepartDate.text = removeYear(dateDisplayFormat.string(from: (firstDate!)))
         
            self.twowayArrivDate.text = removeYear(dateDisplayFormat.string(from: (lastDate!)))
            
            datesRange = range as? [Date]
            firstDate = range.first as? Date
            lastDate = range.last as? Date
            self.onewayView .isHidden = true
            self.twowayView.isHidden = false
            self.multicityView.isHidden = true
            
        }
        else{
            firstDate = self.flightSelectedData.departDate1
            middleDate  = self.flightSelectedData.departDate2
            lastDate = self.flightSelectedData.departDate3
            
            self.depart1Date.textColor = UIColor.white
            self.depart2Date.textColor = UIColor.white
            self.depart3Date.textColor = UIColor.white
            
            self.depart1Date.text = removeYear(dateDisplayFormat.string(from: (firstDate!)))
            self.depart2Date.text = removeYear(dateDisplayFormat.string(from: (middleDate!)))
            self.depart3Date.text = removeYear(dateDisplayFormat.string(from: (lastDate!)))
            
            self.calendar.allowsMultipleSelection = true
            self.calendar.scrollDirection = .vertical
            let range = [firstDate,middleDate,lastDate]
            for d in range {
                calendar.select(d)
            }
            self.onewayView .isHidden = true
            self.twowayView.isHidden = true
            self.multicityView.isHidden = false
            
        }
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
    @IBAction func backBtn(_ sender: Any)
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func doneBtn(_ sender: Any)
    {
        if wayType == "one"
        {
            if firstDate == nil
            {
                String().alert(view: self, title: "UniOrient Info", message: "Choose Departure Date")
            }
            else
            {
                defaults.set(onewayDaprtDate.text, forKey: "selectedDeptDate")
                self.navigationController?.popViewController(animated: true)
            }
            
        }
        else if wayType == "two"
        {
            if firstDate == nil
            {
                String().alert(view: self, title: "UniOrient Info", message: "Choose Departure Date")
            }
            else if lastDate == nil
            {
                String().alert(view: self, title: "UniOrient Info", message: "Choose Arrival Date")
            }
            else
            {
               defaults.set(twowayDepartDate.text, forKey: "selectedDeptDate")
                defaults.set(twowayArrivDate.text, forKey: "selectedArrDate")
                self.navigationController?.popViewController(animated: true)
            }
            
        }else{
            if firstDate == nil
            {
                String().alert(view: self, title: "UniOrient Info", message: "Choose Departure1 Date")
            }
            else if middleDate == nil
            {
                String().alert(view: self, title: "UniOrient Info", message: "Choose Departure2 Date")
            }
            else if lastDate == nil
            {
                String().alert(view: self, title: "UniOrient Info", message: "Choose Departure3 Date")
            }
            else
            {
                defaults.set(depart1Date.text, forKey: "selectedDeptDate1")
                defaults.set(depart2Date.text, forKey: "selectedDeptDate2")
                defaults.set(depart3Date.text, forKey: "selectedDeptDate3")
                self.navigationController?.popViewController(animated: true)
            }
            
        }
        
    }
    func convertDateFormater(_ date: String) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "E, d MMM, yyyy"
        let date = dateFormatter.date(from: date)
        dateFormatter.dateFormat = "yyyy-MM-dd"
        return  dateFormatter.string(from: date!)
        
    }
    func removeYear(_ somedateString: String) -> String
    {
        var arrDate = somedateString .components(separatedBy: ",")
        print(arrDate)
        return arrDate[0] + ", " + arrDate[1]
    }
    func removeSpace(_ somedateString: String) -> String
    {
        var arrDate = somedateString .components(separatedBy: " ")
        print(arrDate)
        return arrDate[0]
    }
}
extension CustomCalenderViewController : FSCalendarDelegateAppearance {
    func minimumDate(for calendar: FSCalendar) -> Date {
        
        /*
         else{
         if calendarFlagHotel == "checkinCalender" {
         return Date()
         }else{
         return self.selectedCheckinDate.addingTimeInterval(oneDay)
         }
         } */
        
        return Date()
    }
  
    func calendar(_ calendar: FSCalendar, willDisplay cell: FSCalendarCell, for date: Date, at monthPosition: FSCalendarMonthPosition) {
        calendar.appearance.titleTodayColor = UIColor.red
    }
    
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition)
    {
        if (wayType == "one")
        {
            firstDate = date
            datesRange = [firstDate!]
           defaults.set(dateDisplayFormat.string(from: (firstDate!)), forKey: "selectedDepartDate1")
            print("datesRange contains: \(datesRange!)")
            strCheck = "yes"
            self.onewayDaprtDate.textColor = UIColor.white
            self.onewayDaprtDate.text = removeYear(dateDisplayFormat.string(from: (datesRange?[0])!))
        }
        else if (wayType == "two"){
            // nothing selected:
            if firstDate == nil {
                firstDate = date
                datesRange = [firstDate!]
                defaults.set(dateDisplayFormat.string(from: (firstDate!)), forKey: "selectedDepartDate1")
                print("datesRange contains1: \(datesRange!)")
                strCheck = "yes"
                self.onewayDaprtDate.text = removeYear(dateDisplayFormat.string(from: (datesRange?[0])!))
                self.twowayDepartDate.text = removeYear(dateDisplayFormat.string(from: (datesRange?[0])!))
                self.onewayDaprtDate.textColor = UIColor.white
                self.twowayDepartDate.textColor = UIColor.white
                self.twowayArrivDate.textColor = UIColor.lightGray
                return
            }
            
            // only first date is selected:
            if firstDate != nil && lastDate == nil {
                // handle the case of if the last date is less than the first date:
                if date <= firstDate! {
                    calendar.deselect(firstDate!)
                    firstDate = date
                    datesRange = [firstDate!]
                    defaults.set(dateDisplayFormat.string(from: (firstDate!)), forKey: "selectedDepartDate1")
                    print("datesRange contains2: \(datesRange!)")
                    
                    self.twowayDepartDate.text = removeYear(dateDisplayFormat.string(from: firstDate!))
                    self.twowayDepartDate.textColor = UIColor.white
                    self.twowayArrivDate.textColor = UIColor.lightGray
                    return
                }
                
                let range = datesRange(from: firstDate!, to: date)
                lastDate = range.last
                
                for d in range {
                    calendar.select(d)
                }
                
                datesRange = range
                defaults.set(dateDisplayFormat.string(from: (lastDate!)), forKey: "selectedArrivalDate1")
                print("datesRange contains3: \(datesRange!)")
                self.twowayArrivDate.text = removeYear(dateDisplayFormat.string(from: lastDate!))
                self.twowayArrivDate.textColor = UIColor.white
                return
            }
            
            // both are selected:
            if firstDate != nil && lastDate != nil {
                for d in calendar.selectedDates {
                    calendar.deselect(d)
                    self.twowayArrivDate.textColor = UIColor.lightGray
                }
                
                lastDate = nil
                firstDate = date
                
                datesRange = [firstDate!]
                calendar.select(firstDate!)
                
                defaults.set(dateDisplayFormat.string(from: (firstDate!)), forKey: "selectedDepartDate1")
                defaults.set(dateDisplayFormat.string(from: (firstDate!)), forKey: "selectedArrivalDate1")
                
                self.twowayDepartDate.text = removeYear(dateDisplayFormat.string(from: firstDate!))
                self.twowayArrivDate.text = removeYear(dateDisplayFormat.string(from: firstDate!))
                //                self.twowayDepartDate.textColor = UIColor.white
                //                self.twowayArrivDate.textColor = UIColor.white
                print("datesRange contains4: \(datesRange!)")
                
            }
        }
        else
        {
            print("selectedDatesRange:",calendar.selectedDates)
            
            // nothing selected:
            if firstDate == nil {
                firstDate = date
                datesRange = [firstDate!]
               defaults.set(dateDisplayFormat.string(from: (firstDate!)), forKey: "sDepartDate1")
                print("datesRange contains11: \(datesRange!)")
                strCheck = "yes"
                self.depart1Date.text = removeYear(dateDisplayFormat.string(from: (datesRange?[0])!))
                self.depart1Date.textColor = UIColor.white
                self.depart2Date.textColor = UIColor.lightGray
                self.depart3Date.textColor = UIColor.lightGray
                return
            }
            
            // only first date is selected:
            if firstDate != nil && middleDate == nil {
                // handle the case of if the last date is less than the first date:
                if date <= firstDate! {
                    calendar.deselect(firstDate!)
                    firstDate = date
                    datesRange = [firstDate!]
                    defaults.set(dateDisplayFormat.string(from: (firstDate!)), forKey: "sDepartDate1")
                    print("datesRange contains22: \(datesRange!)")
                    
                    self.depart1Date.text = removeYear(dateDisplayFormat.string(from: firstDate!))
                    self.depart1Date.textColor = UIColor.white
                    self.depart2Date.textColor = UIColor.lightGray
                    self.depart3Date.textColor = UIColor.lightGray
                    return
                }
                
                let range = datesRange(from: firstDate!, to: date)
                middleDate = date//range.last
                
                datesRange = range
                defaults.set(dateDisplayFormat.string(from: (middleDate!)), forKey: "sDepartDate2")
                print("datesRange contains33: \(datesRange!)")
                self.depart2Date.text = removeYear( dateDisplayFormat.string(from: middleDate!))
                self.depart2Date.textColor = UIColor.white
                self.depart3Date.textColor = UIColor.lightGray
                return
            }
            // only first date is selected:
            if firstDate != nil && middleDate != nil && lastDate == nil {
                // handle the case of if the last date is less than the first date:
                if date <= firstDate! {
                    calendar.deselect(firstDate!)
                    firstDate = date
                    datesRange = [firstDate!]
                    
                    print("datesRange contains2: \(datesRange!)")
                    defaults.set(dateDisplayFormat.string(from: (firstDate!)), forKey: "sDepartDate1")
                    self.depart1Date.text = removeYear(dateDisplayFormat.string(from: firstDate!))
                    self.depart1Date.textColor = UIColor.white
                    self.depart2Date.textColor = UIColor.lightGray
                    self.depart3Date.textColor = UIColor.lightGray
                    return
                }
                if date <= middleDate! {
                    calendar.deselect(middleDate!)
                    middleDate = date
                    datesRange = [middleDate!]
                    defaults.set(dateDisplayFormat.string(from: (middleDate!)), forKey: "sDepartDate2")
                    print("datesRange contains2: \(datesRange!)")
                    
                    self.depart2Date.text = removeYear(dateDisplayFormat.string(from: middleDate!))
                    self.depart2Date.textColor = UIColor.white
                    self.depart3Date.textColor = UIColor.lightGray
                    return
                }
                let range = datesRange(from: middleDate!, to: date)
                lastDate = date
                
                datesRange = range
                defaults.set(dateDisplayFormat.string(from: (lastDate!)), forKey: "sDepartDate3")
                print("datesRange contains333: \(datesRange!)")
                self.depart3Date.text = removeYear( dateDisplayFormat.string(from: lastDate!))
                self.depart3Date.textColor = UIColor.white
                return
            }
            // both are selected:
            if firstDate != nil && middleDate != nil && lastDate != nil {
                for d in calendar.selectedDates {
                    calendar.deselect(d)
                    self.depart1Date.textColor = UIColor.lightGray
                    self.depart2Date.textColor = UIColor.lightGray
                    self.depart3Date.textColor = UIColor.lightGray
                }
                
                lastDate = nil
                middleDate = nil
                firstDate = date
                
                datesRange = [firstDate!]
                calendar.select(firstDate!)
                defaults.set(dateDisplayFormat.string(from: (firstDate!)), forKey: "sDepartDate1")
                self.depart1Date.text = removeYear(dateDisplayFormat.string(from: firstDate!))
                self.depart1Date.textColor = UIColor.white
                print("datesRange contains4: \(datesRange!)")
                
            }
        }
        
    }
    
    func calendar(_ calendar: FSCalendar, didDeselect date: Date, at monthPosition: FSCalendarMonthPosition) {
        // both are selected:
        if wayType == "multi"
        {
            
        }
        else
        {
            if firstDate != nil && lastDate != nil {
                for d in calendar.selectedDates {
                    calendar.deselect(d)
                }
                
                lastDate = nil
                firstDate = nil
                datesRange = []
                print("datesRange contains: \(datesRange!)")
                
            }
        }
        
    }
    func datesRange(from: Date, to: Date) -> [Date] {
        // in case of the "from" date is more than "to" date,
        // it should returns an empty array:
        if from > to { return [Date]() }
        
        var tempDate = from
        var array = [tempDate]
        
        while tempDate < to {
            tempDate = Calendar.current.date(byAdding: .day, value: 1, to: tempDate)!
            array.append(tempDate)
        }
        
        return array
    }
    
    
}
