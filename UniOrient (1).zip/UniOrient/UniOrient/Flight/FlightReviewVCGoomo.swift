//
//  FlightReviewVCGoomo.swift
//  TripArcher
//
//  Created by APPLE on 14/03/19.
//  Copyright © 2019 APPLE. All rights reserved.
//

import UIKit
import SDWebImage

class FlightReviewVCGoomo: UIViewController {
    
    @IBOutlet weak var continueBtn: UIButton!
    
    @IBOutlet weak var farecheckGifImgView: UIImageView!
    @IBOutlet weak var acitvityIndView: UIActivityIndicatorView!
    @IBOutlet weak var loadingView: UIView!
    @IBOutlet weak var noofPassenger: UILabel!
    
    @IBOutlet weak var totalBtn: UIButton!
    @IBOutlet weak var checkinBaggage: UILabel!
    @IBOutlet weak var cabinBaggage: UILabel!
    @IBOutlet weak var txtTotalAmt: UILabel!
    @IBOutlet weak var lblTaxAmt: UILabel!
    @IBOutlet weak var lblFareAmount: UILabel!
    @IBOutlet var bottomView: UIView!
    var selectedStruct : FlightResultAndDetailStruct!
    var providedInputDict = [String:String]()
    @IBOutlet weak var tripDetaillbl: UILabel!
    @IBOutlet weak var tvContainerView: UIView!
    @IBOutlet weak var myTV: UITableView!
    @IBOutlet weak var detailView: UIView!
    @IBOutlet weak var amountLbl: UILabel!
    var detailsArr = [FlightDetailStruct]()
    var returnDetailsArr = [FlightDetailStruct]()
    var multiDetailsArr = [FlightDetailStruct]()
    var isFarecheckPriceChanged : String!
    var fareCheckBaseFare : String!
    var fareCheckTotalFare : String!
    var fareCheckTaxFare : String!
    var myArray : [FinalStruct?]?
    var myArray1 : [FinalStruct?]?
    var myArray2 : [FinalStruct?]?
    
    var adultCount : Int!
    var childCount : Int!
    var infantCount : Int!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.farecheckGifImgView.image = UIImage (named: "loading_green.gif")
        self.acitvityIndView.startAnimating()
     
        adultCount = Int(self.providedInputDict["AdultCount"]!)
        childCount = Int(self.providedInputDict["ChildCount"]!)
        infantCount = Int(self.providedInputDict["InfantCount"]!)
        
        noofPassenger.text = "\(adultCount!)" + " Adult, " + "\(childCount!)" + " Child, " + "\(infantCount!)" + " Infant"
        
        //         cabinBaggage.text = self.selectedStruct.CabinBaggage
        //         checkinBaggage.text = self.selectedStruct.CheckInBaggage
        
        tripDetaillbl.text = UserDefaults .standard .value(forKey: "toplbl") as! String
        print("selected Struct = ",self.selectedStruct)
        self.lblFareAmount.text = "PHP " + self.selectedStruct.amount
        self.txtTotalAmt.text = "PHP " + self.selectedStruct.amount
     
        let myString = self.selectedStruct!.TotalFare!
        let myFloat = (myString as NSString).floatValue
        let formatted = String(format: "%.2f", myFloat)
        
        totalBtn .setTitle("PHP " + formatted, for: UIControl.State.normal)
        let fStr = NSMutableAttributedString()
        let attribute1 = [NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 14)]
        let xyz = NSAttributedString(string: self.selectedStruct.amount,attributes:attribute1)
        
        let attribute2 = [NSAttributedString.Key.foregroundColor : hexStringToUIColor(hex: "#338EDF"),NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: 18)]
        let abc = NSAttributedString(string: "PHP ", attributes: attribute2)
        
        fStr.append(abc)
        //        fStr.append(NSAttributedString(string: "\n"))
        fStr.append(xyz)
        // self.amountLbl.attributedText = fStr
        
        self.navigationController?.navigationBar.isHidden = false
        
        self.detailsArr = selectedStruct.detailArrWithFlightDetailStruct
        let detailStructFinal =  FinalStruct.init(CabinBaggage: selectedStruct.CabinBaggage, CheckInBaggage: selectedStruct.CheckInBaggage, departureDate: selectedStruct.departureDate, arrivalDate: selectedStruct.arrivalDate,flightImgName:selectedStruct.flightImgName,flightImgData:selectedStruct.flightImgData, flightName: selectedStruct.flightName, departureTime: selectedStruct.departureTime, departureAirportCode: selectedStruct.departureAirportCode, duration: selectedStruct.duration, stop: selectedStruct.noOfStops, arrivalTime: selectedStruct.arrivalTime, arrivalAirportCode: selectedStruct.arrivalAirportCode,TripDetailsArr: detailsArr)
        
        self.myArray = [detailStructFinal]
        if selectedStruct.wayType == "two" {
            
            self.returnDetailsArr = selectedStruct.returnDetailArrWithFlightDetailStruct
            let returnDetailStructFinal = FinalStruct.init(CabinBaggage: "Nothing from DB", CheckInBaggage: "Nothing from DB",departureDate:selectedStruct.returnDepartureDate,arrivalDate:selectedStruct.returnArrivalDate,flightImgName:selectedStruct.returnFlightImgName,flightImgData:nil, flightName: selectedStruct.returnFlightName, departureTime: selectedStruct.returnDepartureTime, departureAirportCode: selectedStruct.returnDepartureAirportCode, duration: selectedStruct.returnDuration, stop: selectedStruct.returnNoofStops, arrivalTime: selectedStruct.returnArrivalTime, arrivalAirportCode: selectedStruct.returnArrivalAirportCode,TripDetailsArr: returnDetailsArr)
            
            //  self.myArray?.append(returnDetailStructFinal)
            self.myArray1 = [returnDetailStructFinal]
        }
        if selectedStruct.wayType == "multi" {
            
            ////Return Details
            self.returnDetailsArr = selectedStruct.returnDetailArrWithFlightDetailStruct
            let returnDetailStructFinal = FinalStruct.init(CabinBaggage: "Nothing from DB", CheckInBaggage: "Nothing from DB",departureDate:selectedStruct.returnDepartureDate,arrivalDate:selectedStruct.returnArrivalDate,flightImgName:selectedStruct.returnFlightImgName,flightImgData:nil, flightName: selectedStruct.returnFlightName, departureTime: selectedStruct.returnDepartureTime, departureAirportCode: selectedStruct.returnDepartureAirportCode, duration: selectedStruct.returnDuration, stop: selectedStruct.returnNoofStops, arrivalTime: selectedStruct.returnArrivalTime, arrivalAirportCode: selectedStruct.returnArrivalAirportCode,TripDetailsArr: returnDetailsArr)
            
            //  self.myArray?.append(returnDetailStructFinal)
            self.myArray1 = [returnDetailStructFinal]
            
            ////Multi Details
            self.multiDetailsArr = selectedStruct.multiDetailArrWithFlightDetailStruct
            let multiDetailStructFinal = FinalStruct.init(CabinBaggage: "Nothing from DB", CheckInBaggage: "Nothing from DB",departureDate:selectedStruct.multiDepartureDate,arrivalDate:selectedStruct.multiArrivalDate,flightImgName:selectedStruct.multiFlightImgName,flightImgData:nil, flightName: selectedStruct.multiFlightName, departureTime: selectedStruct.multiDepartureTime, departureAirportCode: selectedStruct.multiDepartureAirportCode, duration: selectedStruct.multiDuration, stop: selectedStruct.multiNoofStops, arrivalTime: selectedStruct.multiArrivalTime, arrivalAirportCode: selectedStruct.multiArrivalAirportCode,TripDetailsArr: multiDetailsArr)
            
            //  self.myArray?.append(returnDetailStructFinal)
            self.myArray2 = [multiDetailStructFinal]
        }
        self.myTV.delegate = self
        self.myTV.dataSource = self
        print("detailC",self.detailsArr)
        print("ReturndetailC",self.returnDetailsArr)
        
      //  self.myTV.tableFooterView = bottomView
        flightFareCheck ()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
//    override func viewWillDisappear(_ animated: Bool) {
//        super.viewWillDisappear(animated)
//        navigationController?.setNavigationBarHidden(false, animated: false)
//    }
    @IBAction func backBtn(_ sender: Any)
    {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func backBtnTapped(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func continueAsGuestBtnTapped(_ sender: UIButton) {
//        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "bookingSummaryVC") as! BookingSummaryViewController
//        ctrl.selectedStruct = self.selectedStruct
//        ctrl.providedInputDict = self.providedInputDict
//        self.navigationController?.pushViewController(ctrl, animated: true)
//        
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "TravellerDetailVCGoomoSBID") as! TravellerDetailVCGoomo
        ctrl.selectedStruct = self.selectedStruct
        ctrl.providedInputDict = self.providedInputDict
        self.navigationController?.pushViewController(ctrl, animated: true)
    }
    
    @IBAction func continueBtnTapped(_ sender: UIButton) {
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "TravellerDetailVCGoomoSBID") as! TravellerDetailVCGoomo
        ctrl.selectedStruct = self.selectedStruct
        ctrl.providedInputDict = self.providedInputDict
        self.navigationController?.pushViewController(ctrl, animated: true)
    }
    
    @IBAction func totalBtnTapped(_ sender: UIButton)
    {
        let ctrl = self.storyboard?.instantiateViewController(withIdentifier: "fareDetailVC") as! FlightFareDetailsViewController
            ctrl.selectedStruct = self.selectedStruct
         ctrl.isfareChanged = self.isFarecheckPriceChanged
         ctrl.baseFare = self.fareCheckBaseFare
         ctrl.taxFare = self.fareCheckTaxFare
         ctrl.totalFare = self.fareCheckTotalFare
         self.navigationController?.present(ctrl, animated: true, completion: nil)
    }
   
    func flightFareCheck()
    {
        let myString = self.selectedStruct!.TotalFare!
        let myFloat = (myString as NSString).floatValue
        let formatted = String(format: "%.2f", myFloat)
        let strdata : String!
         if selectedStruct.wayType == "multi"
         {
           strdata = "TotalAmount=" +  "\(formatted)" + "&adult="
                + "\(self.providedInputDict["AdultCount"]!)" + "&child=" + "\(self.providedInputDict["ChildCount"]!)" + "&infant=" + "\(self.providedInputDict["InfantCount"]!)"
                + "&departAirportall=" + "\(self.selectedStruct.dairportall!)" + "&arrivalAirportall=" + "\(self.selectedStruct.aairportall!)" + "&operatingAirlineall=" + "\(self.selectedStruct.operatingAirlineall!)"
                + "&departdatetimetall=" + "\(self.selectedStruct.Departdatetimetall!)" + "&arrivaldatetimeall=" + "\(self.selectedStruct.Arrivaldatetimeall!)" + "&equipmentTypeall=" + "\(self.selectedStruct.equipmentTypeall!)"
                + "&flightNumberall=" + "\(self.selectedStruct.flightnoall!)" + "&marketingAirlineall=" + "\(self.selectedStruct.marketingall!)" + "&bookingCodeall=" + "\(self.selectedStruct.bookingCodeall!)"
                
                + "&FromCity=" + "\(self.providedInputDict["Origin1"]!)"  + "&ToCity=" + "\(self.providedInputDict["Destination3"]!)"
        }else
         {
           strdata = "TotalAmount=" +  "\(formatted)" + "&adult="
                + "\(self.providedInputDict["AdultCount"]!)" + "&child=" + "\(self.providedInputDict["ChildCount"]!)" + "&infant=" + "\(self.providedInputDict["InfantCount"]!)"
                
                + "&departAirportall=" + "\(self.selectedStruct.dairportall!)" + "&arrivalAirportall=" + "\(self.selectedStruct.aairportall!)" + "&operatingAirlineall=" + "\(self.selectedStruct.operatingAirlineall!)"
                + "&departdatetimetall=" + "\(self.selectedStruct.Departdatetimetall!)" + "&arrivaldatetimeall=" + "\(self.selectedStruct.Arrivaldatetimeall!)" + "&equipmentTypeall=" + "\(self.selectedStruct.equipmentTypeall!)"
                + "&flightNumberall=" + "\(self.selectedStruct.flightnoall!)" + "&marketingAirlineall=" + "\(self.selectedStruct.marketingall!)" + "&bookingCodeall=" + "\(self.selectedStruct.bookingCodeall!)"
                
                + "&FromCity=" + "\(self.providedInputDict["Origin"]!)"  + "&ToCity=" + "\(self.providedInputDict["Destination"]!)"
        }
       
        
        print(strdata)
        
        print(WebServicesUrl.FlightServiceUrl)
        if (Reachability()?.isReachable)!
        {
            WebService().HTTP_POST_FlightBookingTransaction(mainURL: WebServicesUrl.FlightServiceUrl, suffix: "FareQuoteCheck", parameterDict: strdata) { (ResponseDict, success) in
                
                if success {
                    let fullResponse = ResponseDict as! [String:String]
                    print(fullResponse)
                    if (fullResponse["Result"]?.contains("~"))!
                    {
                     
                        let arr = fullResponse["Result"]?.components(separatedBy: "~")
                        let arr1 = arr![0].components(separatedBy: "=")
                        self.isFarecheckPriceChanged = arr1[1]
                        if self.isFarecheckPriceChanged == "true"
                        {
                            let arr2 = arr![1].components(separatedBy: "=")
                            self.fareCheckBaseFare = arr2[1]
                            
                            let arr3 = arr![2].components(separatedBy: "=")
                            self.fareCheckTaxFare = arr3[1]
                            
                            let arr4 = arr![3].components(separatedBy: "=")
                            self.fareCheckTotalFare = arr4[1]
                            self.totalBtn .setTitle("PHP " + self.fareCheckTotalFare, for: UIControl.State.normal)
                        }
                        
                    }
                    else  if (fullResponse["Result"]?.contains(""))!
                    {
                    }
                    else{
                         String().alert(view: self, title: "UniOrient Info", message: fullResponse["Result"]!)
                    }
                    
                    self.loadingView.isHidden = true
                    self.acitvityIndView.stopAnimating()
//                    let helloWorldTimer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(FlightReviewVCGoomo.sayHello), userInfo: nil, repeats: true)
         
                    print("Service call success ..........")
                 
              
                }
                else
                {
                    print("Failure",ResponseDict)
                }
            }
        }
    }
    
    @objc func sayHello()
    {
        self.loadingView.isHidden = true
        self.acitvityIndView.stopAnimating()
    }
}
extension FlightReviewVCGoomo : UITableViewDelegate , UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        if selectedStruct.wayType == "one" {
            return 1
        }
        else if selectedStruct.wayType == "two" {
            return 2
        }
        else
        {
            return  3
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 65.0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let result = tableView.dequeueReusableCell(withIdentifier: "MainCellIDGoomo") as! MainCellClassGoomo
        
        if(section == 0)
        {
            if let rowData = myArray?[0] {
                result.depAirportCodeLbl.text = rowData.departureAirportCode
                
                result.toAIrportName.text = rowData.arrivalAirportCode
                
                result.stopDetailsLbl.text = rowData.stop
                result.departureDateLbl.text = rowData.departureDate + " - " + rowData.arrivalDate
                
                print(rowData.CabinBaggage)
                print(rowData.CheckInBaggage)
                
                //  result.cabbinBaggage.text = rowData.CabinBaggage + " Cabbin Baggage, " + rowData.CheckInBaggage + " CheckIn Baggage"
                return result
            }
        }
        else if(section == 1){
            if let rowData = myArray1?[0]
            {
                result.depAirportCodeLbl.text = rowData.departureAirportCode
                result.toAIrportName.text = rowData.arrivalAirportCode
                result.stopDetailsLbl.text = rowData.stop
                result.departureDateLbl.text = rowData.departureDate + " - " + rowData.arrivalDate
                
                print(rowData.CabinBaggage)
                print(rowData.CheckInBaggage)
                
                //    result.cabbinBaggage.text = rowData.CabinBaggage + " Cabbin Baggage" + rowData.CheckInBaggage + " CheckIn Baggage"
                return result
            }
        }
        else if(section == 2){
            if let rowData = myArray2?[0]
            {
                print(rowData)
                result.depAirportCodeLbl.text = rowData.departureAirportCode
                result.toAIrportName.text = rowData.arrivalAirportCode
                result.stopDetailsLbl.text = rowData.stop
                result.departureDateLbl.text = rowData.departureDate + " - " + rowData.arrivalDate
                //   result.cabbinBaggage.text = rowData.CabinBaggage + " Cabbin Baggage" + rowData.CheckInBaggage + " CheckIn Baggage"
                return result
            }
        }
        return result
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(section == 0)
        {
            return self.detailsArr.count
        }
        else if(section == 1)
        {
            return self.returnDetailsArr.count
        }
        else
        {
            return self.multiDetailsArr.count
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let result = tableView.dequeueReusableCell(withIdentifier: "SubCellIDGoomo", for: indexPath) as! SubCellClassGoomo
        if (indexPath.section == 0)
        {
            result.flightNameLbl.text = self.detailsArr [indexPath.row].operating
            result.depAirportCodeLbl.text = self.detailsArr [indexPath.row].fromAirportName
            // result.stopDetailsLbl.text = self.detailsArr [indexPath.row].marketing
            result.arrivalAirportCodeLbl.text = self.detailsArr [indexPath.row].toAirportName
            result.departureDateLbl.text = self.detailsArr [indexPath.row].departureDate //+ " - " + self.detailsArr [indexPath.row].arrivalDate
        //    result.arrivalDateLbl.text = self.detailsArr [indexPath.row].arrivalDate
            
            
            result.depTimeLbl.text = self.detailsArr [indexPath.row].departureTime
            let tempfromAirportCodeStr = self.detailsArr [indexPath.row].fromAirportName
            let startInd = tempfromAirportCodeStr?.index(after: (tempfromAirportCodeStr?.lastIndex(of: "("))!)
            let endInd = tempfromAirportCodeStr?.lastIndex(of: ")")
            let formattedFromStr = tempfromAirportCodeStr![startInd!..<endInd!]
            result.depAirportCodeLbl.text = self.detailsArr [indexPath.row].fromAirportName//String(formattedFromStr)
            
            result.durationLbl.text = self.detailsArr [indexPath.row].duration
            //  result.stopDetailsLbl.text = self.detailsArr [indexPath.row].stop
            result.arrivalTimeLbl.text = self.detailsArr [indexPath.row].arrivalTime
            
            let tempToAirportCodeStr = self.detailsArr [indexPath.row].toAirportName
            let startInde = tempToAirportCodeStr?.index(after: (tempToAirportCodeStr?.lastIndex(of: "("))!)
            let endInde = tempToAirportCodeStr?.lastIndex(of: ")")
            let formattedToStr = tempToAirportCodeStr![startInde!..<endInde!]
            result.arrivalAirportCodeLbl.text = self.detailsArr [indexPath.row].toAirportName//String(formattedToStr)
            
            let tempDepDateArr = self.detailsArr [indexPath.row].departureDate.components(separatedBy: ",")
         
            let tempArrivalDateArr = self.detailsArr [indexPath.row].arrivalDate.components(separatedBy: ",")
          //  result.arrivalDateLbl.text = tempArrivalDateArr[1]
            
             result.departureDateLbl.text = tempDepDateArr[1]
            //Image
            let flightImgURL = WebServicesUrl.FlightImgURL + self.detailsArr [indexPath.row].marketing + ".gif"
            result.flightImgView.sd_setImage(with: URL(string: flightImgURL), placeholderImage: UIImage(named: "placeholder.png"),options: SDWebImageOptions(rawValue: 0), completed: { downloadedImage, error, cacheType, imageURL in
                if error == nil{
                    print("Image downloaded without error......")
                }else{
                    print("Error from SBWebImage Block = ",error!)
                }
                
            })
            
            return result
        }
        else if (indexPath.section == 1)
        {
            result.flightNameLbl.text = self.returnDetailsArr [indexPath.row].operating
            result.depAirportCodeLbl.text = self.returnDetailsArr [indexPath.row].fromAirportName
            //    result.stopDetailsLbl.text = self.returnDetailsArr [indexPath.row].marketing
            result.arrivalAirportCodeLbl.text = self.returnDetailsArr [indexPath.row].toAirportName
            result.departureDateLbl.text = self.returnDetailsArr [indexPath.row].departureDate
           // result.arrivalDateLbl.text = self.returnDetailsArr [indexPath.row].arrivalDate
            
            result.depTimeLbl.text = self.returnDetailsArr [indexPath.row].departureTime
            let tempfromAirportCodeStr = self.returnDetailsArr [indexPath.row].fromAirportName
            let startInd = tempfromAirportCodeStr?.index(after: (tempfromAirportCodeStr?.lastIndex(of: "("))!)
            let endInd = tempfromAirportCodeStr?.lastIndex(of: ")")
            let formattedFromStr = tempfromAirportCodeStr![startInd!..<endInd!]
            result.depAirportCodeLbl.text = self.returnDetailsArr [indexPath.row].fromAirportName//String(formattedFromStr)
            
            result.durationLbl.text = self.returnDetailsArr [indexPath.row].duration
            // result.stopDetailsLbl.text = self.returnDetailsArr [indexPath.row].stop
            result.arrivalTimeLbl.text = self.returnDetailsArr [indexPath.row].arrivalTime
            
            let tempToAirportCodeStr = self.returnDetailsArr [indexPath.row].toAirportName
            let startInde = tempToAirportCodeStr?.index(after: (tempToAirportCodeStr?.lastIndex(of: "("))!)
            let endInde = tempToAirportCodeStr?.lastIndex(of: ")")
            let formattedToStr = tempToAirportCodeStr![startInde!..<endInde!]
            result.arrivalAirportCodeLbl.text = self.returnDetailsArr [indexPath.row].toAirportName//String(formattedToStr)
            
            let tempDepDateArr = self.returnDetailsArr [indexPath.row].departureDate.components(separatedBy: ",")
            result.departureDateLbl.text = tempDepDateArr[1]
            let tempArrivalDateArr = self.returnDetailsArr [indexPath.row].arrivalDate.components(separatedBy: ",")
          //  result.arrivalDateLbl.text = tempArrivalDateArr[1]
            
            
            //Image
            let flightImgURL = WebServicesUrl.FlightImgURL + self.returnDetailsArr [indexPath.row].marketing + ".gif"
            result.flightImgView.sd_setImage(with: URL(string: flightImgURL), placeholderImage: UIImage(named: "placeholder.png"),options: SDWebImageOptions(rawValue: 0), completed: { downloadedImage, error, cacheType, imageURL in
                if error == nil{
                    print("Image downloaded without error......")
                }else{
                    print("Error from SBWebImage Block = ",error!)
                }
                
            })
            
            return result
        }
        else if (indexPath.section == 2)
        {
            result.flightNameLbl.text = self.multiDetailsArr [indexPath.row].operating
            result.depAirportCodeLbl.text = self.multiDetailsArr [indexPath.row].fromAirportName
            //    result.stopDetailsLbl.text = self.returnDetailsArr [indexPath.row].marketing
            result.arrivalAirportCodeLbl.text = self.multiDetailsArr [indexPath.row].toAirportName
            result.departureDateLbl.text = self.multiDetailsArr [indexPath.row].departureDate
         //   result.arrivalDateLbl.text = self.multiDetailsArr [indexPath.row].arrivalDate
            
            result.depTimeLbl.text = self.multiDetailsArr [indexPath.row].departureTime
            let tempfromAirportCodeStr = self.multiDetailsArr [indexPath.row].fromAirportName
            let startInd = tempfromAirportCodeStr?.index(after: (tempfromAirportCodeStr?.lastIndex(of: "("))!)
            let endInd = tempfromAirportCodeStr?.lastIndex(of: ")")
            let formattedFromStr = tempfromAirportCodeStr![startInd!..<endInd!]
            result.depAirportCodeLbl.text = self.multiDetailsArr [indexPath.row].fromAirportName//String(formattedFromStr)
            
            result.durationLbl.text = self.multiDetailsArr [indexPath.row].duration
            // result.stopDetailsLbl.text = self.returnDetailsArr [indexPath.row].stop
            result.arrivalTimeLbl.text = self.multiDetailsArr [indexPath.row].arrivalTime
            
            let tempToAirportCodeStr = self.multiDetailsArr [indexPath.row].toAirportName
            let startInde = tempToAirportCodeStr?.index(after: (tempToAirportCodeStr?.lastIndex(of: "("))!)
            let endInde = tempToAirportCodeStr?.lastIndex(of: ")")
            let formattedToStr = tempToAirportCodeStr![startInde!..<endInde!]
            result.arrivalAirportCodeLbl.text = self.multiDetailsArr [indexPath.row].toAirportName//String(formattedToStr)
            
            let tempDepDateArr = self.multiDetailsArr [indexPath.row].departureDate.components(separatedBy: ",")
            result.departureDateLbl.text = tempDepDateArr[1]
            let tempArrivalDateArr = self.multiDetailsArr [indexPath.row].arrivalDate.components(separatedBy: ",")
        //    result.arrivalDateLbl.text = tempArrivalDateArr[1]
            
            
            //Image
            let flightImgURL = WebServicesUrl.FlightImgURL + self.multiDetailsArr [indexPath.row].marketing + ".gif"
            result.flightImgView.sd_setImage(with: URL(string: flightImgURL), placeholderImage: UIImage(named: "placeholder.png"),options: SDWebImageOptions(rawValue: 0), completed: { downloadedImage, error, cacheType, imageURL in
                if error == nil{
                    print("Image downloaded without error......")
                }else{
                    print("Error from SBWebImage Block = ",error!)
                }
                
            })
            
            return result
        }
        return UITableViewCell()
        
    }
    private func getParentCellIndex(expansionIndex: Int) -> Int {
        
        var selectedCell: FinalStruct?
        var selectedCellIndex = expansionIndex
        
        while(selectedCell == nil && selectedCellIndex >= 0) {
            selectedCellIndex -= 1
            selectedCell = myArray?[selectedCellIndex]
        }
        
        return selectedCellIndex
    }
    
    //    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    //        tableView.deselectRow(at: indexPath, animated: true)
    //        //        if let data = myArray?[indexPath.row] {
    //
    //        if (myArray?[indexPath.row]) != nil {
    //
    //            // If user clicked last cell, do not try to access cell+1 (out of range)
    //            if(indexPath.row + 1 >= (myArray?.count)!) {
    //                if myArray?[indexPath.row]?.stop != "0 stop" {
    //                    expandCell(tableView: tableView, index: indexPath.row)
    //                }else{
    //                    print("0 stop..so dont expand...lastcell")
    //                }
    //
    //            }
    //            else {
    //                // If next cell is not nil, then cell is not expanded
    //                if(myArray?[indexPath.row+1] != nil) {
    //                    if myArray?[indexPath.row]?.stop != "0 stop" {
    //                        expandCell(tableView: tableView, index: indexPath.row)
    //                    }else{
    //                        print("0 stop..so dont expand...ReturnTrip")
    //                    }
    //
    //                    // Close Cell (remove ExpansionCells)
    //                } else {
    //                    contractCell(tableView: tableView, index: indexPath.row)
    //
    //                }
    //            }
    //        }
    //    }
    /*  Expand cell at given index  */
    private func expandCell(tableView: UITableView, index: Int) {
        // Expand Cell (add ExpansionCells
        
        /*
         if let flights = destinationData?[index]?.TripDetailsArr {
         for i in 1...flights.count {
         destinationData?.insert(nil, at: index + i)
         tableView.insertRows(at: [NSIndexPath(row: index + i, section: 0) as IndexPath] , with: .top)
         }
         }*/
        
        if let fli = myArray?[index]?.TripDetailsArr {
            for i in 1...fli.count {
                myArray?.insert(nil, at: index + i)
                tableView.insertRows(at: [NSIndexPath(row: index + i, section: 0) as IndexPath] , with: .top)
            }
        }
    }
    /*  Contract cell at given index    */
    private func contractCell(tableView: UITableView, index: Int) {
        
        if let flig = myArray?[index]?.TripDetailsArr {
            for _ in 1...flig.count {
                myArray?.remove(at: index+1)
                tableView.deleteRows(at: [NSIndexPath(row: index+1, section: 0) as IndexPath], with: .top)
                
            }
        }
    }
}

class MainCellClassGoomo : UITableViewCell{
    @IBOutlet weak var flightImgView: UIImageView?
    @IBOutlet weak var flightNameLbl: UILabel!
    @IBOutlet weak var depTimeLbl: UILabel!
    @IBOutlet weak var depAirportCodeLbl: UILabel!
    @IBOutlet weak var durationLbl: UILabel!
    @IBOutlet weak var stopDetailsLbl: UILabel!
    @IBOutlet weak var arrivalTimeLbl: UILabel!
    @IBOutlet weak var arrivalAirportCodeLbl: UILabel!
    @IBOutlet weak var amountLbl: UILabel!
    
    @IBOutlet weak var toAIrportName: UILabel!
    @IBOutlet weak var refundOrNonRefundLbl: UILabel!
    @IBOutlet weak var lineDesignVIew: UIView!
    @IBOutlet weak var detailLbl: UILabel!
    
    @IBOutlet weak var classTypeLbl: DesignableLabel!
    @IBOutlet weak var departureDateLbl: UILabel!
    @IBOutlet weak var arrivalDateLbl: UILabel!
    
    @IBOutlet weak var cabbinBaggage: UILabel!
}
class SubCellClassGoomo : UITableViewCell{
    @IBOutlet weak var flightImgView: UIImageView!
    @IBOutlet weak var flightNameLbl: UILabel!
    @IBOutlet weak var depTimeLbl: UILabel!
    @IBOutlet weak var depAirportCodeLbl: UILabel!
    @IBOutlet weak var durationLbl: UILabel!
    @IBOutlet weak var stopDetailsLbl: UILabel!
    @IBOutlet weak var arrivalTimeLbl: UILabel!
    @IBOutlet weak var arrivalAirportCodeLbl: UILabel!
    @IBOutlet weak var amountLbl: UILabel!
    
    @IBOutlet weak var refundOrNonRefundLbl: UILabel!
    @IBOutlet weak var lineDesignVIew: UIView!
    @IBOutlet weak var detailLbl: UILabel!
    
    @IBOutlet weak var departureDateLbl: UILabel!
    @IBOutlet weak var arrivalDateLbl: UILabel!
}

//MARK: - }
