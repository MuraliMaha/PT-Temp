//
//  CVCalendar.h
//  CVCalendar
//
//  Created by Guilherme Moura on 1/20/16.
//  Copyright © 2016 GameApp. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CVCalendar.
FOUNDATION_EXPORT double CVCalendarVersionNumber;

//! Project version string for CVCalendar.
FOUNDATION_EXPORT const unsigned char CVCalendarVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CVCalendar/PublicHeader.h>


