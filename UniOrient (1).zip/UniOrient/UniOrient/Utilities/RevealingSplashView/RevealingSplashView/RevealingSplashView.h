//
//  RevealingSplashView.h
//  RevealingSplashView
//
//  Created by Chris Jimenez on 2/25/16.
//  Copyright © 2016 Chris Jimenez. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for RevealingSplashView.
FOUNDATION_EXPORT double RevealingSplashViewVersionNumber;

//! Project version string for RevealingSplashView.
FOUNDATION_EXPORT const unsigned char RevealingSplashViewVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <RevealingSplashView/PublicHeader.h>


